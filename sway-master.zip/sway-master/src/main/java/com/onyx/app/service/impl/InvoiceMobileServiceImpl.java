package com.onyx.app.service.impl;

import com.onyx.app.service.InvoiceMobileService;
import com.onyx.app.domain.InvoiceMobile;
import com.onyx.app.repository.InvoiceMobileRepository;
import com.onyx.app.service.dto.InvoiceMobileDTO;
import com.onyx.app.service.mapper.InvoiceMobileMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.stereotype.Service;

import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Service Implementation for managing InvoiceMobile.
 */
@Service
public class InvoiceMobileServiceImpl implements InvoiceMobileService {

    private final Logger log = LoggerFactory.getLogger(InvoiceMobileServiceImpl.class);

    private final InvoiceMobileRepository invoiceMobileRepository;

    private final InvoiceMobileMapper invoiceMobileMapper;

    public InvoiceMobileServiceImpl(InvoiceMobileRepository invoiceMobileRepository, InvoiceMobileMapper invoiceMobileMapper) {
        this.invoiceMobileRepository = invoiceMobileRepository;
        this.invoiceMobileMapper = invoiceMobileMapper;
    }

    /**
     * Save a invoiceMobile.
     *
     * @param invoiceMobileDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public InvoiceMobileDTO save(InvoiceMobileDTO invoiceMobileDTO) {
        log.debug("Request to save InvoiceMobile : {}", invoiceMobileDTO);
        InvoiceMobile invoiceMobile = invoiceMobileMapper.toEntity(invoiceMobileDTO);
        invoiceMobile = invoiceMobileRepository.save(invoiceMobile);
        return invoiceMobileMapper.toDto(invoiceMobile);
    }

    /**
     * Get all the invoiceMobiles.
     *
     * @return the list of entities
     */
    @Override
    public List<InvoiceMobileDTO> findAll() {
        log.debug("Request to get all InvoiceMobiles");
        return invoiceMobileRepository.findAll().stream()
            .map(invoiceMobileMapper::toDto)
            .collect(Collectors.toCollection(LinkedList::new));
    }


    /**
     * Get one invoiceMobile by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    public Optional<InvoiceMobileDTO> findOne(String id) {
        log.debug("Request to get InvoiceMobile : {}", id);
        return invoiceMobileRepository.findById(id)
            .map(invoiceMobileMapper::toDto);
    }

    /**
     * Delete the invoiceMobile by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(String id) {
        log.debug("Request to delete InvoiceMobile : {}", id);
        invoiceMobileRepository.deleteById(id);
    }
}
