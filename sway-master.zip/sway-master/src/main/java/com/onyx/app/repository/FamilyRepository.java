package com.onyx.app.repository;

import com.onyx.app.domain.Family;
import org.springframework.stereotype.Repository;

/**
 * Spring Data Couchbase repository for the Family entity.
 */
@SuppressWarnings("unused")
@Repository
public interface FamilyRepository extends N1qlCouchbaseRepository<Family, String> {

}
