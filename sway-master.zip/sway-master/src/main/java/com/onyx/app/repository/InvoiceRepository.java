package com.onyx.app.repository;

import com.onyx.app.domain.Invoice;
import org.springframework.stereotype.Repository;

/**
 * Spring Data Couchbase repository for the Invoice entity.
 */
@SuppressWarnings("unused")
@Repository
public interface InvoiceRepository extends N1qlCouchbaseRepository<Invoice, String> {

}
