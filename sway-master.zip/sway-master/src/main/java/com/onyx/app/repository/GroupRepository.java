package com.onyx.app.repository;

import org.springframework.stereotype.Repository;

import com.onyx.app.domain.Group;

/**
 * Spring Data MongoDB repository for the Group entity.
 */
@SuppressWarnings("unused")
@Repository
public interface GroupRepository extends N1qlCouchbaseRepository<Group, String> {

}
