package com.onyx.app.service.util;

import java.util.stream.Stream;
import java.util.stream.StreamSupport;

public class StreamUtil {


    public static Stream toStream (Iterable source)     {
        return StreamSupport.stream(source.spliterator(), false);
    }
}
