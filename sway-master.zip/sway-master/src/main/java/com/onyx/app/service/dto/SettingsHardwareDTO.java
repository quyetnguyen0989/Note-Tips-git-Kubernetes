package com.onyx.app.service.dto;

import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.Objects;
import com.onyx.app.domain.enumeration.HardwarePoleType;
import com.onyx.app.domain.enumeration.HardwarePolePort;
import com.onyx.app.domain.enumeration.HardwareMsrPort;
import com.onyx.app.domain.enumeration.HardwarePrinterType;
import com.onyx.app.domain.enumeration.HardwarePrinterPort;
import com.onyx.app.domain.enumeration.HardwareScannerPort;
import com.onyx.app.domain.enumeration.HardwareMediaType;
import com.onyx.app.domain.enumeration.KitchenType;
import com.onyx.app.domain.enumeration.KitchenPort;
import com.onyx.app.domain.enumeration.HardwarePinpadType;

/**
 * A DTO for the SettingsHardware entity.
 */
public class SettingsHardwareDTO implements Serializable {

    private String id;

    @NotNull
    private Integer storeId;

    private Boolean poleDisplay;

    private HardwarePoleType poleDisplayType;

    private HardwarePolePort poleDisplayPort;

    private Boolean msr;

    private HardwareMsrPort msrPort;

    private Boolean printer;

    private HardwarePrinterType printerType;

    private HardwarePrinterPort printerPort;

    private Boolean scanner;

    private HardwareScannerPort scannerPort;

    private Boolean mediaDisplay;

    private HardwareMediaType mediaDisplayType;

    private Boolean kitchenPrinter;

    private KitchenType kitchenPrinterType;

    private KitchenPort kitchenPrinterPort;

    private Boolean pinpad;

    private HardwarePinpadType pinpadType;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getStoreId() {
        return storeId;
    }

    public void setStoreId(Integer storeId) {
        this.storeId = storeId;
    }

    public Boolean isPoleDisplay() {
        return poleDisplay;
    }

    public void setPoleDisplay(Boolean poleDisplay) {
        this.poleDisplay = poleDisplay;
    }

    public HardwarePoleType getPoleDisplayType() {
        return poleDisplayType;
    }

    public void setPoleDisplayType(HardwarePoleType poleDisplayType) {
        this.poleDisplayType = poleDisplayType;
    }

    public HardwarePolePort getPoleDisplayPort() {
        return poleDisplayPort;
    }

    public void setPoleDisplayPort(HardwarePolePort poleDisplayPort) {
        this.poleDisplayPort = poleDisplayPort;
    }

    public Boolean isMsr() {
        return msr;
    }

    public void setMsr(Boolean msr) {
        this.msr = msr;
    }

    public HardwareMsrPort getMsrPort() {
        return msrPort;
    }

    public void setMsrPort(HardwareMsrPort msrPort) {
        this.msrPort = msrPort;
    }

    public Boolean isPrinter() {
        return printer;
    }

    public void setPrinter(Boolean printer) {
        this.printer = printer;
    }

    public HardwarePrinterType getPrinterType() {
        return printerType;
    }

    public void setPrinterType(HardwarePrinterType printerType) {
        this.printerType = printerType;
    }

    public HardwarePrinterPort getPrinterPort() {
        return printerPort;
    }

    public void setPrinterPort(HardwarePrinterPort printerPort) {
        this.printerPort = printerPort;
    }

    public Boolean isScanner() {
        return scanner;
    }

    public void setScanner(Boolean scanner) {
        this.scanner = scanner;
    }

    public HardwareScannerPort getScannerPort() {
        return scannerPort;
    }

    public void setScannerPort(HardwareScannerPort scannerPort) {
        this.scannerPort = scannerPort;
    }

    public Boolean isMediaDisplay() {
        return mediaDisplay;
    }

    public void setMediaDisplay(Boolean mediaDisplay) {
        this.mediaDisplay = mediaDisplay;
    }

    public HardwareMediaType getMediaDisplayType() {
        return mediaDisplayType;
    }

    public void setMediaDisplayType(HardwareMediaType mediaDisplayType) {
        this.mediaDisplayType = mediaDisplayType;
    }

    public Boolean isKitchenPrinter() {
        return kitchenPrinter;
    }

    public void setKitchenPrinter(Boolean kitchenPrinter) {
        this.kitchenPrinter = kitchenPrinter;
    }

    public KitchenType getKitchenPrinterType() {
        return kitchenPrinterType;
    }

    public void setKitchenPrinterType(KitchenType kitchenPrinterType) {
        this.kitchenPrinterType = kitchenPrinterType;
    }

    public KitchenPort getKitchenPrinterPort() {
        return kitchenPrinterPort;
    }

    public void setKitchenPrinterPort(KitchenPort kitchenPrinterPort) {
        this.kitchenPrinterPort = kitchenPrinterPort;
    }

    public Boolean isPinpad() {
        return pinpad;
    }

    public void setPinpad(Boolean pinpad) {
        this.pinpad = pinpad;
    }

    public HardwarePinpadType getPinpadType() {
        return pinpadType;
    }

    public void setPinpadType(HardwarePinpadType pinpadType) {
        this.pinpadType = pinpadType;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        SettingsHardwareDTO settingsHardwareDTO = (SettingsHardwareDTO) o;
        if (settingsHardwareDTO.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), settingsHardwareDTO.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "SettingsHardwareDTO{" +
            "id=" + getId() +
            ", storeId=" + getStoreId() +
            ", poleDisplay='" + isPoleDisplay() + "'" +
            ", poleDisplayType='" + getPoleDisplayType() + "'" +
            ", poleDisplayPort='" + getPoleDisplayPort() + "'" +
            ", msr='" + isMsr() + "'" +
            ", msrPort='" + getMsrPort() + "'" +
            ", printer='" + isPrinter() + "'" +
            ", printerType='" + getPrinterType() + "'" +
            ", printerPort='" + getPrinterPort() + "'" +
            ", scanner='" + isScanner() + "'" +
            ", scannerPort='" + getScannerPort() + "'" +
            ", mediaDisplay='" + isMediaDisplay() + "'" +
            ", mediaDisplayType='" + getMediaDisplayType() + "'" +
            ", kitchenPrinter='" + isKitchenPrinter() + "'" +
            ", kitchenPrinterType='" + getKitchenPrinterType() + "'" +
            ", kitchenPrinterPort='" + getKitchenPrinterPort() + "'" +
            ", pinpad='" + isPinpad() + "'" +
            ", pinpadType='" + getPinpadType() + "'" +
            "}";
    }
}
