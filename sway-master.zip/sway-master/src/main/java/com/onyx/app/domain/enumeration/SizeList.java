package com.onyx.app.domain.enumeration;

/**
 * The SizeList enumeration.
 */
public enum SizeList {
    S750ML,  S1L,  S375ML,  S200ML,  S100ML,  KILO
}
