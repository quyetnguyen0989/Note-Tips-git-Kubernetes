package com.onyx.app.repository;

import com.onyx.app.domain.StoreTime;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface StoreTimeRepository extends N1qlCouchbaseRepository<StoreTime , String>{

    StoreTime findByStoreId(Integer storeId);

    List<StoreTime> findAllByStoreId(Integer storeId);
}
