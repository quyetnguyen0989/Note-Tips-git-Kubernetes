package com.onyx.app.service.dto;
import java.time.Instant;
import java.time.LocalDate;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.Objects;

/**
 * A DTO for the Invoice entity.
 */
public class InvoiceDTO implements Serializable {

    private String id;

    private Integer itemnum;

    @Size(max = 50)
    private String itemname;

    private Integer storeid;

    private Long custNum;

    private Integer invnum;

    private Instant invtime;

    @NotNull
    private Double itemprice;

    private LocalDate invdate;

    private Double totalCost;

    private Double discount;

    private Double totalPrice;

    private Double totalTax1;

    private Double totalTax2;

    private Double totalTax3;

    private Double grandTotal;

    private Double amtTendered;

    private Double amtChange;

    @Size(max = 200)
    private String notes;

    private String status;

    private Integer cashierid;

    private String cashiername;

    private Integer stationid;

    private String paymentMethod;

    private Double taxed1;

    private Double taxedSales;

    private Double nonTaxedsales;

    private Double taxexemptsales;

    private Double caamount;

    private Double ccamount;

    private Double oaamount;

    private Double dcamount;

    private Double tipamount;

    private Double fsamount;

    private String taxrateid;

    private Double taxrate1percent;

    private String layaway;

    private Double amtdeposit;

    private Double layawayamount;

    private Integer onlineorderid;

    private String orderSource;

    private String modifieddate;

    private String createdate;

    private String kioskid;

    private Integer modifierID;

    private String modifierName;

    private Long modifierNum;


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getItemnum() {
        return itemnum;
    }

    public void setItemnum(Integer itemnum) {
        this.itemnum = itemnum;
    }

    public String getItemname() {
        return itemname;
    }

    public void setItemname(String itemname) {
        this.itemname = itemname;
    }

    public Integer getStoreid() {
        return storeid;
    }

    public void setStoreid(Integer storeid) {
        this.storeid = storeid;
    }

    public Long getCustNum() {
        return custNum;
    }

    public void setCustNum(Long custNum) {
        this.custNum = custNum;
    }

    public Integer getInvnum() {
        return invnum;
    }

    public void setInvnum(Integer invnum) {
        this.invnum = invnum;
    }

    public Instant getInvtime() {
        return invtime;
    }

    public void setInvtime(Instant invtime) {
        this.invtime = invtime;
    }

    public Double getItemprice() {
        return itemprice;
    }

    public void setItemprice(Double itemprice) {
        this.itemprice = itemprice;
    }

    public LocalDate getInvdate() {
        return invdate;
    }

    public void setInvdate(LocalDate invdate) {
        this.invdate = invdate;
    }

    public Double getTotalCost() {
        return totalCost;
    }

    public void setTotalCost(Double totalCost) {
        this.totalCost = totalCost;
    }

    public Double getDiscount() {
        return discount;
    }

    public void setDiscount(Double discount) {
        this.discount = discount;
    }

    public Double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(Double totalPrice) {
        this.totalPrice = totalPrice;
    }

    public Double getTotalTax1() {
        return totalTax1;
    }

    public void setTotalTax1(Double totalTax1) {
        this.totalTax1 = totalTax1;
    }

    public Double getTotalTax2() {
        return totalTax2;
    }

    public void setTotalTax2(Double totalTax2) {
        this.totalTax2 = totalTax2;
    }

    public Double getTotalTax3() {
        return totalTax3;
    }

    public void setTotalTax3(Double totalTax3) {
        this.totalTax3 = totalTax3;
    }

    public Double getGrandTotal() {
        return grandTotal;
    }

    public void setGrandTotal(Double grandTotal) {
        this.grandTotal = grandTotal;
    }

    public Double getAmtTendered() {
        return amtTendered;
    }

    public void setAmtTendered(Double amtTendered) {
        this.amtTendered = amtTendered;
    }

    public Double getAmtChange() {
        return amtChange;
    }

    public void setAmtChange(Double amtChange) {
        this.amtChange = amtChange;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Integer getCashierid() {
        return cashierid;
    }

    public void setCashierid(Integer cashierid) {
        this.cashierid = cashierid;
    }

    public String getCashiername() {
        return cashiername;
    }

    public void setCashiername(String cashiername) {
        this.cashiername = cashiername;
    }

    public Integer getStationid() {
        return stationid;
    }

    public void setStationid(Integer stationid) {
        this.stationid = stationid;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public Double getTaxed1() {
        return taxed1;
    }

    public void setTaxed1(Double taxed1) {
        this.taxed1 = taxed1;
    }

    public Double getTaxedSales() {
        return taxedSales;
    }

    public void setTaxedSales(Double taxedSales) {
        this.taxedSales = taxedSales;
    }

    public Double getNonTaxedsales() {
        return nonTaxedsales;
    }

    public void setNonTaxedsales(Double nonTaxedsales) {
        this.nonTaxedsales = nonTaxedsales;
    }

    public Double getTaxexemptsales() {
        return taxexemptsales;
    }

    public void setTaxexemptsales(Double taxexemptsales) {
        this.taxexemptsales = taxexemptsales;
    }

    public Double getCaamount() {
        return caamount;
    }

    public void setCaamount(Double caamount) {
        this.caamount = caamount;
    }

    public Double getCcamount() {
        return ccamount;
    }

    public void setCcamount(Double ccamount) {
        this.ccamount = ccamount;
    }

    public Double getOaamount() {
        return oaamount;
    }

    public void setOaamount(Double oaamount) {
        this.oaamount = oaamount;
    }

    public Double getDcamount() {
        return dcamount;
    }

    public void setDcamount(Double dcamount) {
        this.dcamount = dcamount;
    }

    public Double getTipamount() {
        return tipamount;
    }

    public void setTipamount(Double tipamount) {
        this.tipamount = tipamount;
    }

    public Double getFsamount() {
        return fsamount;
    }

    public void setFsamount(Double fsamount) {
        this.fsamount = fsamount;
    }

    public String getTaxrateid() {
        return taxrateid;
    }

    public void setTaxrateid(String taxrateid) {
        this.taxrateid = taxrateid;
    }

    public Double getTaxrate1percent() {
        return taxrate1percent;
    }

    public void setTaxrate1percent(Double taxrate1percent) {
        this.taxrate1percent = taxrate1percent;
    }

    public String getLayaway() {
        return layaway;
    }

    public void setLayaway(String layaway) {
        this.layaway = layaway;
    }

    public Double getAmtdeposit() {
        return amtdeposit;
    }

    public void setAmtdeposit(Double amtdeposit) {
        this.amtdeposit = amtdeposit;
    }

    public Double getLayawayamount() {
        return layawayamount;
    }

    public void setLayawayamount(Double layawayamount) {
        this.layawayamount = layawayamount;
    }

    public Integer getOnlineorderid() {
        return onlineorderid;
    }

    public void setOnlineorderid(Integer onlineorderid) {
        this.onlineorderid = onlineorderid;
    }

    public String getOrderSource() {
        return orderSource;
    }

    public void setOrderSource(String orderSource) {
        this.orderSource = orderSource;
    }

    public String getModifieddate() {
        return modifieddate;
    }

    public void setModifieddate(String modifieddate) {
        this.modifieddate = modifieddate;
    }

    public String getCreatedate() {
        return createdate;
    }

    public void setCreatedate(String createdate) {
        this.createdate = createdate;
    }

    public String getKioskid() {
        return kioskid;
    }

    public void setKioskid(String kioskid) {
        this.kioskid = kioskid;
    }

    public Integer getModifierID() {
        return modifierID;
    }

    public void setModifierID(Integer modifierID) {
        this.modifierID = modifierID;
    }

    public String getModifierName() {
        return modifierName;
    }

    public void setModifierName(String modifierName) {
        this.modifierName = modifierName;
    }

    public Long getModifierNum() {
        return modifierNum;
    }

    public void setModifierNum(Long modifierNum) {
        this.modifierNum = modifierNum;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        InvoiceDTO invoiceDTO = (InvoiceDTO) o;
        if (invoiceDTO.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), invoiceDTO.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "InvoiceDTO{" +
            "id=" + getId() +
            ", itemnum=" + getItemnum() +
            ", itemname='" + getItemname() + "'" +
            ", storeid=" + getStoreid() +
            ", custNum=" + getCustNum() +
            ", invnum=" + getInvnum() +
            ", invtime='" + getInvtime() + "'" +
            ", itemprice=" + getItemprice() +
            ", invdate='" + getInvdate() + "'" +
            ", totalCost=" + getTotalCost() +
            ", discount=" + getDiscount() +
            ", totalPrice=" + getTotalPrice() +
            ", totalTax1=" + getTotalTax1() +
            ", totalTax2=" + getTotalTax2() +
            ", totalTax3=" + getTotalTax3() +
            ", grandTotal=" + getGrandTotal() +
            ", amtTendered=" + getAmtTendered() +
            ", amtChange=" + getAmtChange() +
            ", notes='" + getNotes() + "'" +
            ", status='" + getStatus() + "'" +
            ", cashierid=" + getCashierid() +
            ", cashiername='" + getCashiername() + "'" +
            ", stationid=" + getStationid() +
            ", paymentMethod='" + getPaymentMethod() + "'" +
            ", taxed1=" + getTaxed1() +
            ", taxedSales=" + getTaxedSales() +
            ", nonTaxedsales=" + getNonTaxedsales() +
            ", taxexemptsales=" + getTaxexemptsales() +
            ", caamount=" + getCaamount() +
            ", ccamount=" + getCcamount() +
            ", oaamount=" + getOaamount() +
            ", dcamount=" + getDcamount() +
            ", tipamount=" + getTipamount() +
            ", fsamount=" + getFsamount() +
            ", taxrateid='" + getTaxrateid() + "'" +
            ", taxrate1percent=" + getTaxrate1percent() +
            ", layaway='" + getLayaway() + "'" +
            ", amtdeposit=" + getAmtdeposit() +
            ", layawayamount=" + getLayawayamount() +
            ", onlineorderid=" + getOnlineorderid() +
            ", orderSource='" + getOrderSource() + "'" +
            ", modifieddate='" + getModifieddate() + "'" +
            ", createdate='" + getCreatedate() + "'" +
            ", kioskid='" + getKioskid() + "'" +
            ", modifierID=" + getModifierID() +
            ", modifierName='" + getModifierName() + "'" +
            ", modifierNum=" + getModifierNum() +
            "}";
    }
}
