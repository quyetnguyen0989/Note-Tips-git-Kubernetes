package com.onyx.app.web.rest;

import com.codahale.metrics.annotation.Timed;
import com.onyx.app.service.InvoiceKioskService;
import com.onyx.app.web.rest.errors.BadRequestAlertException;
import com.onyx.app.web.rest.util.HeaderUtil;
import com.onyx.app.service.dto.InvoiceKioskDTO;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;

import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing InvoiceKiosk.
 */
@RestController
@RequestMapping("/api")
public class InvoiceKioskResource {

    private final Logger log = LoggerFactory.getLogger(InvoiceKioskResource.class);

    private static final String ENTITY_NAME = "invoiceKiosk";

    private final InvoiceKioskService invoiceKioskService;

    public InvoiceKioskResource(InvoiceKioskService invoiceKioskService) {
        this.invoiceKioskService = invoiceKioskService;
    }

    /**
     * POST  /invoice-kiosks : Create a new invoiceKiosk.
     *
     * @param invoiceKioskDTO the invoiceKioskDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new invoiceKioskDTO, or with status 400 (Bad Request) if the invoiceKiosk has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/invoice-kiosks")
    @Timed
    public ResponseEntity<InvoiceKioskDTO> createInvoiceKiosk(@Valid @RequestBody InvoiceKioskDTO invoiceKioskDTO) throws URISyntaxException {
        log.debug("REST request to save InvoiceKiosk : {}", invoiceKioskDTO);
        if (invoiceKioskDTO.getId() != null) {
            throw new BadRequestAlertException("A new invoiceKiosk cannot already have an ID", ENTITY_NAME, "idexists");
        }
        InvoiceKioskDTO result = invoiceKioskService.save(invoiceKioskDTO);
        return ResponseEntity.created(new URI("/api/invoice-kiosks/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /invoice-kiosks : Updates an existing invoiceKiosk.
     *
     * @param invoiceKioskDTO the invoiceKioskDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated invoiceKioskDTO,
     * or with status 400 (Bad Request) if the invoiceKioskDTO is not valid,
     * or with status 500 (Internal Server Error) if the invoiceKioskDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/invoice-kiosks")
    @Timed
    public ResponseEntity<InvoiceKioskDTO> updateInvoiceKiosk(@Valid @RequestBody InvoiceKioskDTO invoiceKioskDTO) throws URISyntaxException {
        log.debug("REST request to update InvoiceKiosk : {}", invoiceKioskDTO);
        if (invoiceKioskDTO.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        InvoiceKioskDTO result = invoiceKioskService.save(invoiceKioskDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, invoiceKioskDTO.getId().toString()))
            .body(result);
    }

    /**
     * GET  /invoice-kiosks : get all the invoiceKiosks.
     *
     * @return the ResponseEntity with status 200 (OK) and the list of invoiceKiosks in body
     */
    @GetMapping("/invoice-kiosks")
    @Timed
    public List<InvoiceKioskDTO> getAllInvoiceKiosks() {
        log.debug("REST request to get all InvoiceKiosks");
        return invoiceKioskService.findAll();
    }

    /**
     * GET  /invoice-kiosks/:id : get the "id" invoiceKiosk.
     *
     * @param id the id of the invoiceKioskDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the invoiceKioskDTO, or with status 404 (Not Found)
     */
    @GetMapping("/invoice-kiosks/{id}")
    @Timed
    public ResponseEntity<InvoiceKioskDTO> getInvoiceKiosk(@PathVariable String id) {
        log.debug("REST request to get InvoiceKiosk : {}", id);
        Optional<InvoiceKioskDTO> invoiceKioskDTO = invoiceKioskService.findOne(id);
        return ResponseUtil.wrapOrNotFound(invoiceKioskDTO);
    }

    /**
     * DELETE  /invoice-kiosks/:id : delete the "id" invoiceKiosk.
     *
     * @param id the id of the invoiceKioskDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/invoice-kiosks/{id}")
    @Timed
    public ResponseEntity<Void> deleteInvoiceKiosk(@PathVariable String id) {
        log.debug("REST request to delete InvoiceKiosk : {}", id);
        invoiceKioskService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id)).build();
    }
}
