package com.onyx.app.web.rest;

import com.codahale.metrics.annotation.Timed;
import com.onyx.app.service.CustomerInfoService;
import com.onyx.app.web.rest.errors.BadRequestAlertException;
import com.onyx.app.web.rest.util.HeaderUtil;
import com.onyx.app.service.dto.CustomerInfoDTO;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;

import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing CustomerInfo.
 */
@RestController
@RequestMapping("/api")
public class CustomerInfoResource {

    private final Logger log = LoggerFactory.getLogger(CustomerInfoResource.class);

    private static final String ENTITY_NAME = "customerInfo";

    private final CustomerInfoService customerInfoService;

    public CustomerInfoResource(CustomerInfoService customerInfoService) {
        this.customerInfoService = customerInfoService;
    }

    /**
     * POST  /customer-infos : Create a new customerInfo.
     *
     * @param customerInfoDTO the customerInfoDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new customerInfoDTO, or with status 400 (Bad Request) if the customerInfo has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/customer-infos")
    @Timed
    public ResponseEntity<CustomerInfoDTO> createCustomerInfo(@Valid @RequestBody CustomerInfoDTO customerInfoDTO) throws URISyntaxException {
        log.debug("REST request to save CustomerInfo : {}", customerInfoDTO);
        if (customerInfoDTO.getId() != null) {
            throw new BadRequestAlertException("A new customerInfo cannot already have an ID", ENTITY_NAME, "idexists");
        }
        CustomerInfoDTO result = customerInfoService.save(customerInfoDTO);
        return ResponseEntity.created(new URI("/api/customer-infos/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /customer-infos : Updates an existing customerInfo.
     *
     * @param customerInfoDTO the customerInfoDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated customerInfoDTO,
     * or with status 400 (Bad Request) if the customerInfoDTO is not valid,
     * or with status 500 (Internal Server Error) if the customerInfoDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/customer-infos")
    @Timed
    public ResponseEntity<CustomerInfoDTO> updateCustomerInfo(@Valid @RequestBody CustomerInfoDTO customerInfoDTO) throws URISyntaxException {
        log.debug("REST request to update CustomerInfo : {}", customerInfoDTO);
        if (customerInfoDTO.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        CustomerInfoDTO result = customerInfoService.save(customerInfoDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, customerInfoDTO.getId().toString()))
            .body(result);
    }

    /**
     * GET  /customer-infos : get all the customerInfos.
     *
     * @return the ResponseEntity with status 200 (OK) and the list of customerInfos in body
     */
    @GetMapping("/customer-infos")
    @Timed
    public List<CustomerInfoDTO> getAllCustomerInfos() {
        log.debug("REST request to get all CustomerInfos");
        return customerInfoService.findAll();
    }

    /**
     * GET  /customer-infos/:id : get the "id" customerInfo.
     *
     * @param id the id of the customerInfoDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the customerInfoDTO, or with status 404 (Not Found)
     */
    @GetMapping("/customer-infos/{id}")
    @Timed
    public ResponseEntity<CustomerInfoDTO> getCustomerInfo(@PathVariable String id) {
        log.debug("REST request to get CustomerInfo : {}", id);
        Optional<CustomerInfoDTO> customerInfoDTO = customerInfoService.findOne(id);
        return ResponseUtil.wrapOrNotFound(customerInfoDTO);
    }

    /**
     * DELETE  /customer-infos/:id : delete the "id" customerInfo.
     *
     * @param id the id of the customerInfoDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/customer-infos/{id}")
    @Timed
    public ResponseEntity<Void> deleteCustomerInfo(@PathVariable String id) {
        log.debug("REST request to delete CustomerInfo : {}", id);
        customerInfoService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id)).build();
    }
}
