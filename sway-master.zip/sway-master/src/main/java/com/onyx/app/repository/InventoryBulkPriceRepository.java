package com.onyx.app.repository;

import com.onyx.app.domain.InventoryBulkPrice;
import org.springframework.stereotype.Repository;

/**
 * Spring Data Couchbase repository for the InventoryBulkPrice entity.
 */
@SuppressWarnings("unused")
@Repository
public interface InventoryBulkPriceRepository extends N1qlCouchbaseRepository<InventoryBulkPrice, String> {

}
