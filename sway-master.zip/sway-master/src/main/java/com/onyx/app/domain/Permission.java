package com.onyx.app.domain;

import org.springframework.data.annotation.Id;
import com.couchbase.client.java.repository.annotation.Field;
import org.springframework.data.couchbase.core.mapping.Document;
import org.springframework.data.couchbase.core.mapping.id.GeneratedValue;
import org.springframework.data.couchbase.core.mapping.id.GenerationStrategy;

import javax.validation.constraints.*;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * A Permission.
 */
@Document
public class Permission implements Serializable {

	private static final long serialVersionUID = 6738685224678981116L;

	@Id
	@GeneratedValue(strategy = GenerationStrategy.UNIQUE)
    private String id;

    @NotNull
    @Field("setup_access")
    private Boolean setupAccess;

    @NotNull
    @Field("inventory")
    private Boolean inventory;

    @NotNull
    @Field("vendors")
    private Boolean vendors;

    @NotNull
    @Field("depts_add")
    private Boolean deptsAdd;

    @NotNull
    @Field("custmors_account")
    private Boolean custmorsAccount;

    @NotNull
    @Field("reports_1")
    private Boolean reports1;

    @NotNull
    @Field("reports_2")
    private Boolean reports2;

    @NotNull
    @Field("invoice_discount")
    private Boolean invoiceDiscount;

    @NotNull
    @Field("invoice_pricechange")
    private Boolean invoicePricechange;

    @NotNull
    @Field("invoice_deleteitems")
    private Boolean invoiceDeleteitems;

    @NotNull
    @Field("invoice_void")
    private Boolean invoiceVoid;

    @NotNull
    @Field("refund_item")
    private Boolean refundItem;

    @NotNull
    @Field("transfer_table")
    private Boolean transferTable;

    @NotNull
    @Field("add_cc_tips")
    private Boolean addCcTips;

    @NotNull
    @Field("disabled")
    private Boolean disabled;

    @NotNull
    @Field("print_hold")
    private Boolean printHold;

    @NotNull
    @Field("open_cash_drawer")
    private Boolean openCashDrawer;

    @NotNull
    @Field("required_clockin")
    private Boolean requiredClockin;

    @NotNull
    @Field("split_checks")
    private Boolean splitChecks;

    @NotNull
    @Field("transfer_tables")
    private Boolean transferTables;

    @NotNull
    @Field("extra_item")
    private Boolean extraItem;

    @NotNull
    @Field("tax_exempt")
    private Boolean taxExempt;

    @NotNull
    @Field("gc_sell")
    private Boolean gcSell;

    @NotNull
    @Field("gc_redeem")
    private Boolean gcRedeem;

    @NotNull
    @Field("sell_special_item")
    private Boolean sellSpecialItem;

    @NotNull
    @Field("vendor_payout")
    private Boolean vendorPayout;

    @NotNull
    @Field("apply_gratuity")
    private Boolean applyGratuity;

    @Field("picture")
    private Boolean picture;

    @NotNull
    @Field("current_cash")
    private Boolean currentCash;

    @NotNull
    @Field("cash_alerts")
    private Boolean cashAlerts;

    @NotNull
    @Field("cash_pickup")
    private Boolean cashPickup;

    @NotNull
    @Field("issue_credit_slip")
    private Boolean issueCreditSlip;

    @NotNull
    @Field("redeem_credit_slip")
    private Boolean redeemCreditSlip;

    @NotNull
    @Field("drawer_transfer")
    private Boolean drawerTransfer;

    @NotNull
    @Field("approve_cashcount")
    private Boolean approveCashcount;

    @NotNull
    @Field("time_worked_this_period")
    private Boolean timeWorkedThisPeriod;

    @NotNull
    @Field("overtime_threshold")
    private Boolean overtimeThreshold;

    @NotNull
    @Field("pullback_invoice")
    private Boolean pullbackInvoice;

    @NotNull
    @Field("perform_endofday")
    private Boolean performEndofday;

    @NotNull
    @Field("invoice_deletesent")
    private Boolean invoiceDeletesent;

    @NotNull
    @Field("inventory_access_1")
    private Boolean inventoryAccess1;

    @NotNull
    @Field("inventory_access_2")
    private Boolean inventoryAccess2;

    @NotNull
    @Field("comp")
    private Boolean comp;

    @NotNull
    @Field("des_config")
    private Boolean desConfig;

    @NotNull
    @Field("transfer_server")
    private Boolean transferServer;

    @NotNull
    @Field("kitchen_reprint")
    private Boolean kitchenReprint;

    @NotNull
    @Field("setup_receipt_notes")
    private Boolean setupReceiptNotes;

    @NotNull
    @Field("setup_employees")
    private Boolean setupEmployees;

    @NotNull
    @Field("inventory_promotions")
    private Boolean inventoryPromotions;

    @NotNull
    @Field("invoice_discounts_limit")
    private Boolean invoiceDiscountsLimit;

    @NotNull
    @Field("emp_time_scheduler")
    private Boolean empTimeScheduler;

    @NotNull
    @Field("negative_price_change")
    private Boolean negativePriceChange;

    @NotNull
    @Field("close_shift")
    private Boolean closeShift;

    @NotNull
    @Field("reprint_receipt")
    private Boolean reprintReceipt;

    @Field("is_admin")
    private Boolean isAdmin;

    @Field("is_manager")
    private Boolean isManager;

    @NotNull
    @Size(max = 8)
    @Field("pin_code")
    private String pinCode;
    
    private String accessLevel;
	
	private String accessLevelId;
	
	private List<String> employees = new ArrayList<>();

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Boolean isSetupAccess() {
        return setupAccess;
    }

    public Permission setupAccess(Boolean setupAccess) {
        this.setupAccess = setupAccess;
        return this;
    }

    public void setSetupAccess(Boolean setupAccess) {
        this.setupAccess = setupAccess;
    }

    public Boolean isInventory() {
        return inventory;
    }

    public Permission inventory(Boolean inventory) {
        this.inventory = inventory;
        return this;
    }

    public void setInventory(Boolean inventory) {
        this.inventory = inventory;
    }

    public Boolean isVendors() {
        return vendors;
    }

    public Permission vendors(Boolean vendors) {
        this.vendors = vendors;
        return this;
    }

    public void setVendors(Boolean vendors) {
        this.vendors = vendors;
    }

    public Boolean isDeptsAdd() {
        return deptsAdd;
    }

    public Permission deptsAdd(Boolean deptsAdd) {
        this.deptsAdd = deptsAdd;
        return this;
    }

    public void setDeptsAdd(Boolean deptsAdd) {
        this.deptsAdd = deptsAdd;
    }

    public Boolean isCustmorsAccount() {
        return custmorsAccount;
    }

    public Permission custmorsAccount(Boolean custmorsAccount) {
        this.custmorsAccount = custmorsAccount;
        return this;
    }

    public void setCustmorsAccount(Boolean custmorsAccount) {
        this.custmorsAccount = custmorsAccount;
    }

    public Boolean isReports1() {
        return reports1;
    }

    public Permission reports1(Boolean reports1) {
        this.reports1 = reports1;
        return this;
    }

    public void setReports1(Boolean reports1) {
        this.reports1 = reports1;
    }

    public Boolean isReports2() {
        return reports2;
    }

    public Permission reports2(Boolean reports2) {
        this.reports2 = reports2;
        return this;
    }

    public void setReports2(Boolean reports2) {
        this.reports2 = reports2;
    }

    public Boolean isInvoiceDiscount() {
        return invoiceDiscount;
    }

    public Permission invoiceDiscount(Boolean invoiceDiscount) {
        this.invoiceDiscount = invoiceDiscount;
        return this;
    }

    public void setInvoiceDiscount(Boolean invoiceDiscount) {
        this.invoiceDiscount = invoiceDiscount;
    }

    public Boolean isInvoicePricechange() {
        return invoicePricechange;
    }

    public Permission invoicePricechange(Boolean invoicePricechange) {
        this.invoicePricechange = invoicePricechange;
        return this;
    }

    public void setInvoicePricechange(Boolean invoicePricechange) {
        this.invoicePricechange = invoicePricechange;
    }

    public Boolean isInvoiceDeleteitems() {
        return invoiceDeleteitems;
    }

    public Permission invoiceDeleteitems(Boolean invoiceDeleteitems) {
        this.invoiceDeleteitems = invoiceDeleteitems;
        return this;
    }

    public void setInvoiceDeleteitems(Boolean invoiceDeleteitems) {
        this.invoiceDeleteitems = invoiceDeleteitems;
    }

    public Boolean isInvoiceVoid() {
        return invoiceVoid;
    }

    public Permission invoiceVoid(Boolean invoiceVoid) {
        this.invoiceVoid = invoiceVoid;
        return this;
    }

    public void setInvoiceVoid(Boolean invoiceVoid) {
        this.invoiceVoid = invoiceVoid;
    }

    public Boolean isRefundItem() {
        return refundItem;
    }

    public Permission refundItem(Boolean refundItem) {
        this.refundItem = refundItem;
        return this;
    }

    public void setRefundItem(Boolean refundItem) {
        this.refundItem = refundItem;
    }

    public Boolean isTransferTable() {
        return transferTable;
    }

    public Permission transferTable(Boolean transferTable) {
        this.transferTable = transferTable;
        return this;
    }

    public void setTransferTable(Boolean transferTable) {
        this.transferTable = transferTable;
    }

    public Boolean isAddCcTips() {
        return addCcTips;
    }

    public Permission addCcTips(Boolean addCcTips) {
        this.addCcTips = addCcTips;
        return this;
    }

    public void setAddCcTips(Boolean addCcTips) {
        this.addCcTips = addCcTips;
    }

    public Boolean isDisabled() {
        return disabled;
    }

    public Permission disabled(Boolean disabled) {
        this.disabled = disabled;
        return this;
    }

    public void setDisabled(Boolean disabled) {
        this.disabled = disabled;
    }

    public Boolean isPrintHold() {
        return printHold;
    }

    public Permission printHold(Boolean printHold) {
        this.printHold = printHold;
        return this;
    }

    public void setPrintHold(Boolean printHold) {
        this.printHold = printHold;
    }

    public Boolean isOpenCashDrawer() {
        return openCashDrawer;
    }

    public Permission openCashDrawer(Boolean openCashDrawer) {
        this.openCashDrawer = openCashDrawer;
        return this;
    }

    public void setOpenCashDrawer(Boolean openCashDrawer) {
        this.openCashDrawer = openCashDrawer;
    }

    public Boolean isRequiredClockin() {
        return requiredClockin;
    }

    public Permission requiredClockin(Boolean requiredClockin) {
        this.requiredClockin = requiredClockin;
        return this;
    }

    public void setRequiredClockin(Boolean requiredClockin) {
        this.requiredClockin = requiredClockin;
    }

    public Boolean isSplitChecks() {
        return splitChecks;
    }

    public Permission splitChecks(Boolean splitChecks) {
        this.splitChecks = splitChecks;
        return this;
    }

    public void setSplitChecks(Boolean splitChecks) {
        this.splitChecks = splitChecks;
    }

    public Boolean isTransferTables() {
        return transferTables;
    }

    public Permission transferTables(Boolean transferTables) {
        this.transferTables = transferTables;
        return this;
    }

    public void setTransferTables(Boolean transferTables) {
        this.transferTables = transferTables;
    }

    public Boolean isExtraItem() {
        return extraItem;
    }

    public Permission extraItem(Boolean extraItem) {
        this.extraItem = extraItem;
        return this;
    }

    public void setExtraItem(Boolean extraItem) {
        this.extraItem = extraItem;
    }

    public Boolean isTaxExempt() {
        return taxExempt;
    }

    public Permission taxExempt(Boolean taxExempt) {
        this.taxExempt = taxExempt;
        return this;
    }

    public void setTaxExempt(Boolean taxExempt) {
        this.taxExempt = taxExempt;
    }

    public Boolean isGcSell() {
        return gcSell;
    }

    public Permission gcSell(Boolean gcSell) {
        this.gcSell = gcSell;
        return this;
    }

    public void setGcSell(Boolean gcSell) {
        this.gcSell = gcSell;
    }

    public Boolean isGcRedeem() {
        return gcRedeem;
    }

    public Permission gcRedeem(Boolean gcRedeem) {
        this.gcRedeem = gcRedeem;
        return this;
    }

    public void setGcRedeem(Boolean gcRedeem) {
        this.gcRedeem = gcRedeem;
    }

    public Boolean isSellSpecialItem() {
        return sellSpecialItem;
    }

    public Permission sellSpecialItem(Boolean sellSpecialItem) {
        this.sellSpecialItem = sellSpecialItem;
        return this;
    }

    public void setSellSpecialItem(Boolean sellSpecialItem) {
        this.sellSpecialItem = sellSpecialItem;
    }

    public Boolean isVendorPayout() {
        return vendorPayout;
    }

    public Permission vendorPayout(Boolean vendorPayout) {
        this.vendorPayout = vendorPayout;
        return this;
    }

    public void setVendorPayout(Boolean vendorPayout) {
        this.vendorPayout = vendorPayout;
    }

    public Boolean isApplyGratuity() {
        return applyGratuity;
    }

    public Permission applyGratuity(Boolean applyGratuity) {
        this.applyGratuity = applyGratuity;
        return this;
    }

    public void setApplyGratuity(Boolean applyGratuity) {
        this.applyGratuity = applyGratuity;
    }

    public Boolean isPicture() {
        return picture;
    }

    public Permission picture(Boolean picture) {
        this.picture = picture;
        return this;
    }

    public void setPicture(Boolean picture) {
        this.picture = picture;
    }

    public Boolean isCurrentCash() {
        return currentCash;
    }

    public Permission currentCash(Boolean currentCash) {
        this.currentCash = currentCash;
        return this;
    }

    public void setCurrentCash(Boolean currentCash) {
        this.currentCash = currentCash;
    }

    public Boolean isCashAlerts() {
        return cashAlerts;
    }

    public Permission cashAlerts(Boolean cashAlerts) {
        this.cashAlerts = cashAlerts;
        return this;
    }

    public void setCashAlerts(Boolean cashAlerts) {
        this.cashAlerts = cashAlerts;
    }

    public Boolean isCashPickup() {
        return cashPickup;
    }

    public Permission cashPickup(Boolean cashPickup) {
        this.cashPickup = cashPickup;
        return this;
    }

    public void setCashPickup(Boolean cashPickup) {
        this.cashPickup = cashPickup;
    }

    public Boolean isIssueCreditSlip() {
        return issueCreditSlip;
    }

    public Permission issueCreditSlip(Boolean issueCreditSlip) {
        this.issueCreditSlip = issueCreditSlip;
        return this;
    }

    public void setIssueCreditSlip(Boolean issueCreditSlip) {
        this.issueCreditSlip = issueCreditSlip;
    }

    public Boolean isRedeemCreditSlip() {
        return redeemCreditSlip;
    }

    public Permission redeemCreditSlip(Boolean redeemCreditSlip) {
        this.redeemCreditSlip = redeemCreditSlip;
        return this;
    }

    public void setRedeemCreditSlip(Boolean redeemCreditSlip) {
        this.redeemCreditSlip = redeemCreditSlip;
    }

    public Boolean isDrawerTransfer() {
        return drawerTransfer;
    }

    public Permission drawerTransfer(Boolean drawerTransfer) {
        this.drawerTransfer = drawerTransfer;
        return this;
    }

    public void setDrawerTransfer(Boolean drawerTransfer) {
        this.drawerTransfer = drawerTransfer;
    }

    public Boolean isApproveCashcount() {
        return approveCashcount;
    }

    public Permission approveCashcount(Boolean approveCashcount) {
        this.approveCashcount = approveCashcount;
        return this;
    }

    public void setApproveCashcount(Boolean approveCashcount) {
        this.approveCashcount = approveCashcount;
    }

    public Boolean isTimeWorkedThisPeriod() {
        return timeWorkedThisPeriod;
    }

    public Permission timeWorkedThisPeriod(Boolean timeWorkedThisPeriod) {
        this.timeWorkedThisPeriod = timeWorkedThisPeriod;
        return this;
    }

    public void setTimeWorkedThisPeriod(Boolean timeWorkedThisPeriod) {
        this.timeWorkedThisPeriod = timeWorkedThisPeriod;
    }

    public Boolean isOvertimeThreshold() {
        return overtimeThreshold;
    }

    public Permission overtimeThreshold(Boolean overtimeThreshold) {
        this.overtimeThreshold = overtimeThreshold;
        return this;
    }

    public void setOvertimeThreshold(Boolean overtimeThreshold) {
        this.overtimeThreshold = overtimeThreshold;
    }

    public Boolean isPullbackInvoice() {
        return pullbackInvoice;
    }

    public Permission pullbackInvoice(Boolean pullbackInvoice) {
        this.pullbackInvoice = pullbackInvoice;
        return this;
    }

    public void setPullbackInvoice(Boolean pullbackInvoice) {
        this.pullbackInvoice = pullbackInvoice;
    }

    public Boolean isPerformEndofday() {
        return performEndofday;
    }

    public Permission performEndofday(Boolean performEndofday) {
        this.performEndofday = performEndofday;
        return this;
    }

    public void setPerformEndofday(Boolean performEndofday) {
        this.performEndofday = performEndofday;
    }

    public Boolean isInvoiceDeletesent() {
        return invoiceDeletesent;
    }

    public Permission invoiceDeletesent(Boolean invoiceDeletesent) {
        this.invoiceDeletesent = invoiceDeletesent;
        return this;
    }

    public void setInvoiceDeletesent(Boolean invoiceDeletesent) {
        this.invoiceDeletesent = invoiceDeletesent;
    }

    public Boolean isInventoryAccess1() {
        return inventoryAccess1;
    }

    public Permission inventoryAccess1(Boolean inventoryAccess1) {
        this.inventoryAccess1 = inventoryAccess1;
        return this;
    }

    public void setInventoryAccess1(Boolean inventoryAccess1) {
        this.inventoryAccess1 = inventoryAccess1;
    }

    public Boolean isInventoryAccess2() {
        return inventoryAccess2;
    }

    public Permission inventoryAccess2(Boolean inventoryAccess2) {
        this.inventoryAccess2 = inventoryAccess2;
        return this;
    }

    public void setInventoryAccess2(Boolean inventoryAccess2) {
        this.inventoryAccess2 = inventoryAccess2;
    }

    public Boolean isComp() {
        return comp;
    }

    public Permission comp(Boolean comp) {
        this.comp = comp;
        return this;
    }

    public void setComp(Boolean comp) {
        this.comp = comp;
    }

    public Boolean isDesConfig() {
        return desConfig;
    }

    public Permission desConfig(Boolean desConfig) {
        this.desConfig = desConfig;
        return this;
    }

    public void setDesConfig(Boolean desConfig) {
        this.desConfig = desConfig;
    }

    public Boolean isTransferServer() {
        return transferServer;
    }

    public Permission transferServer(Boolean transferServer) {
        this.transferServer = transferServer;
        return this;
    }

    public void setTransferServer(Boolean transferServer) {
        this.transferServer = transferServer;
    }

    public Boolean isKitchenReprint() {
        return kitchenReprint;
    }

    public Permission kitchenReprint(Boolean kitchenReprint) {
        this.kitchenReprint = kitchenReprint;
        return this;
    }

    public void setKitchenReprint(Boolean kitchenReprint) {
        this.kitchenReprint = kitchenReprint;
    }

    public Boolean isSetupReceiptNotes() {
        return setupReceiptNotes;
    }

    public Permission setupReceiptNotes(Boolean setupReceiptNotes) {
        this.setupReceiptNotes = setupReceiptNotes;
        return this;
    }

    public void setSetupReceiptNotes(Boolean setupReceiptNotes) {
        this.setupReceiptNotes = setupReceiptNotes;
    }

    public Boolean isSetupEmployees() {
        return setupEmployees;
    }

    public Permission setupEmployees(Boolean setupEmployees) {
        this.setupEmployees = setupEmployees;
        return this;
    }

    public void setSetupEmployees(Boolean setupEmployees) {
        this.setupEmployees = setupEmployees;
    }

    public Boolean isInventoryPromotions() {
        return inventoryPromotions;
    }

    public Permission inventoryPromotions(Boolean inventoryPromotions) {
        this.inventoryPromotions = inventoryPromotions;
        return this;
    }

    public void setInventoryPromotions(Boolean inventoryPromotions) {
        this.inventoryPromotions = inventoryPromotions;
    }

    public Boolean isInvoiceDiscountsLimit() {
        return invoiceDiscountsLimit;
    }

    public Permission invoiceDiscountsLimit(Boolean invoiceDiscountsLimit) {
        this.invoiceDiscountsLimit = invoiceDiscountsLimit;
        return this;
    }

    public void setInvoiceDiscountsLimit(Boolean invoiceDiscountsLimit) {
        this.invoiceDiscountsLimit = invoiceDiscountsLimit;
    }

    public Boolean isEmpTimeScheduler() {
        return empTimeScheduler;
    }

    public Permission empTimeScheduler(Boolean empTimeScheduler) {
        this.empTimeScheduler = empTimeScheduler;
        return this;
    }

    public void setEmpTimeScheduler(Boolean empTimeScheduler) {
        this.empTimeScheduler = empTimeScheduler;
    }

    public Boolean isNegativePriceChange() {
        return negativePriceChange;
    }

    public Permission negativePriceChange(Boolean negativePriceChange) {
        this.negativePriceChange = negativePriceChange;
        return this;
    }

    public void setNegativePriceChange(Boolean negativePriceChange) {
        this.negativePriceChange = negativePriceChange;
    }

    public Boolean isCloseShift() {
        return closeShift;
    }

    public Permission closeShift(Boolean closeShift) {
        this.closeShift = closeShift;
        return this;
    }

    public void setCloseShift(Boolean closeShift) {
        this.closeShift = closeShift;
    }

    public Boolean isReprintReceipt() {
        return reprintReceipt;
    }

    public Permission reprintReceipt(Boolean reprintReceipt) {
        this.reprintReceipt = reprintReceipt;
        return this;
    }

    public void setReprintReceipt(Boolean reprintReceipt) {
        this.reprintReceipt = reprintReceipt;
    }

    public Boolean isIsAdmin() {
        return isAdmin;
    }

    public Permission isAdmin(Boolean isAdmin) {
        this.isAdmin = isAdmin;
        return this;
    }

    public void setIsAdmin(Boolean isAdmin) {
        this.isAdmin = isAdmin;
    }

    public Boolean isIsManager() {
        return isManager;
    }

    public Permission isManager(Boolean isManager) {
        this.isManager = isManager;
        return this;
    }

    public void setIsManager(Boolean isManager) {
        this.isManager = isManager;
    }

    public String getPinCode() {
        return pinCode;
    }

    public Permission pinCode(String pinCode) {
        this.pinCode = pinCode;
        return this;
    }

    public void setPinCode(String pinCode) {
        this.pinCode = pinCode;
    }
    
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    public String getAccessLevel() {
		return accessLevel;
	}

	public void setAccessLevel(String accessLevel) {
		this.accessLevel = accessLevel;
	}

	public String getAccessLevelId() {
		return accessLevelId;
	}

	public void setAccessLevelId(String accessLevelId) {
		this.accessLevelId = accessLevelId;
	}

	public List<String> getEmployees() {
		return employees;
	}

	public void setEmployees(List<String> employees) {
		this.employees = employees;
	}

	@Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Permission employee = (Permission) o;
        if (employee.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), employee.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "Employee{" +
            "id=" + getId() +
            ", setupAccess='" + isSetupAccess() + "'" +
            ", inventory='" + isInventory() + "'" +
            ", vendors='" + isVendors() + "'" +
            ", deptsAdd='" + isDeptsAdd() + "'" +
            ", custmorsAccount='" + isCustmorsAccount() + "'" +
            ", reports1='" + isReports1() + "'" +
            ", reports2='" + isReports2() + "'" +
            ", invoiceDiscount='" + isInvoiceDiscount() + "'" +
            ", invoicePricechange='" + isInvoicePricechange() + "'" +
            ", invoiceDeleteitems='" + isInvoiceDeleteitems() + "'" +
            ", invoiceVoid='" + isInvoiceVoid() + "'" +
            ", refundItem='" + isRefundItem() + "'" +
            ", transferTable='" + isTransferTable() + "'" +
            ", addCcTips='" + isAddCcTips() + "'" +
            ", disabled='" + isDisabled() + "'" +
            ", printHold='" + isPrintHold() + "'" +
            ", openCashDrawer='" + isOpenCashDrawer() + "'" +
            ", requiredClockin='" + isRequiredClockin() + "'" +
            ", splitChecks='" + isSplitChecks() + "'" +
            ", transferTables='" + isTransferTables() + "'" +
            ", extraItem='" + isExtraItem() + "'" +
            ", taxExempt='" + isTaxExempt() + "'" +
            ", gcSell='" + isGcSell() + "'" +
            ", gcRedeem='" + isGcRedeem() + "'" +
            ", sellSpecialItem='" + isSellSpecialItem() + "'" +
            ", vendorPayout='" + isVendorPayout() + "'" +
            ", applyGratuity='" + isApplyGratuity() + "'" +
            ", picture='" + isPicture() + "'" +
            ", currentCash='" + isCurrentCash() + "'" +
            ", cashAlerts='" + isCashAlerts() + "'" +
            ", cashPickup='" + isCashPickup() + "'" +
            ", issueCreditSlip='" + isIssueCreditSlip() + "'" +
            ", redeemCreditSlip='" + isRedeemCreditSlip() + "'" +
            ", drawerTransfer='" + isDrawerTransfer() + "'" +
            ", approveCashcount='" + isApproveCashcount() + "'" +
            ", timeWorkedThisPeriod='" + isTimeWorkedThisPeriod() + "'" +
            ", overtimeThreshold='" + isOvertimeThreshold() + "'" +
            ", pullbackInvoice='" + isPullbackInvoice() + "'" +
            ", performEndofday='" + isPerformEndofday() + "'" +
            ", invoiceDeletesent='" + isInvoiceDeletesent() + "'" +
            ", inventoryAccess1='" + isInventoryAccess1() + "'" +
            ", inventoryAccess2='" + isInventoryAccess2() + "'" +
            ", comp='" + isComp() + "'" +
            ", desConfig='" + isDesConfig() + "'" +
            ", transferServer='" + isTransferServer() + "'" +
            ", kitchenReprint='" + isKitchenReprint() + "'" +
            ", setupReceiptNotes='" + isSetupReceiptNotes() + "'" +
            ", setupEmployees='" + isSetupEmployees() + "'" +
            ", inventoryPromotions='" + isInventoryPromotions() + "'" +
            ", invoiceDiscountsLimit='" + isInvoiceDiscountsLimit() + "'" +
            ", empTimeScheduler='" + isEmpTimeScheduler() + "'" +
            ", negativePriceChange='" + isNegativePriceChange() + "'" +
            ", closeShift='" + isCloseShift() + "'" +
            ", reprintReceipt='" + isReprintReceipt() + "'" +
            ", isAdmin='" + isIsAdmin() + "'" +
            ", isManager='" + isIsManager() + "'" +
            ", pinCode='" + getPinCode() + "'" +
            "}";
    }
}
