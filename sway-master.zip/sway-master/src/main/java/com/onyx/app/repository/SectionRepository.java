package com.onyx.app.repository;

import com.onyx.app.domain.Section;
import org.springframework.stereotype.Repository;

/**
 * Spring Data Couchbase repository for the Section entity.
 */
@SuppressWarnings("unused")
@Repository
public interface SectionRepository extends N1qlCouchbaseRepository<Section, String> {

}
