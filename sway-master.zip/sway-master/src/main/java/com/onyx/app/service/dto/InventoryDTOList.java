package com.onyx.app.service.dto;

import java.io.Serializable;
import java.util.List;

/**
 * A DTO for the Inventory entity.
 */
public class InventoryDTOList implements Serializable {

    private Long currentListCount;
    private Long totalCount;
    private List list;

    public InventoryDTOList(Long currentListCount, Long totalCount, List list) {
        this.currentListCount = currentListCount;
        this.totalCount = totalCount;
        this.list = list;
    }

    public Long getCurrentListCount() {
        return currentListCount;
    }

    public void setCurrentListCount(Long currentListCount) {
        this.currentListCount = currentListCount;
    }

    public Long getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(Long totalCount) {
        this.totalCount = totalCount;
    }

    public List<InventoryQuick> getList() {
        return list;
    }

    public void setList(List<InventoryQuick> list) {
        this.list = list;
    }
}
