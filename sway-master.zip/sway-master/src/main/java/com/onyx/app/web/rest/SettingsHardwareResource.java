package com.onyx.app.web.rest;

import com.codahale.metrics.annotation.Timed;
import com.onyx.app.service.SettingsHardwareService;
import com.onyx.app.web.rest.errors.BadRequestAlertException;
import com.onyx.app.web.rest.util.HeaderUtil;
import com.onyx.app.service.dto.SettingsHardwareDTO;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;

import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing SettingsHardware.
 */
@RestController
@RequestMapping("/api")
public class SettingsHardwareResource {

    private final Logger log = LoggerFactory.getLogger(SettingsHardwareResource.class);

    private static final String ENTITY_NAME = "settingsHardware";

    private final SettingsHardwareService settingsHardwareService;

    public SettingsHardwareResource(SettingsHardwareService settingsHardwareService) {
        this.settingsHardwareService = settingsHardwareService;
    }

    /**
     * POST  /settings-hardwares : Create a new settingsHardware.
     *
     * @param settingsHardwareDTO the settingsHardwareDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new settingsHardwareDTO, or with status 400 (Bad Request) if the settingsHardware has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/settings-hardwares")
    @Timed
    public ResponseEntity<SettingsHardwareDTO> createSettingsHardware(@Valid @RequestBody SettingsHardwareDTO settingsHardwareDTO) throws URISyntaxException {
        log.debug("REST request to save SettingsHardware : {}", settingsHardwareDTO);
        if (settingsHardwareDTO.getId() != null) {
            throw new BadRequestAlertException("A new settingsHardware cannot already have an ID", ENTITY_NAME, "idexists");
        }
        SettingsHardwareDTO result = settingsHardwareService.save(settingsHardwareDTO);
        return ResponseEntity.created(new URI("/api/settings-hardwares/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /settings-hardwares : Updates an existing settingsHardware.
     *
     * @param settingsHardwareDTO the settingsHardwareDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated settingsHardwareDTO,
     * or with status 400 (Bad Request) if the settingsHardwareDTO is not valid,
     * or with status 500 (Internal Server Error) if the settingsHardwareDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/settings-hardwares")
    @Timed
    public ResponseEntity<SettingsHardwareDTO> updateSettingsHardware(@Valid @RequestBody SettingsHardwareDTO settingsHardwareDTO) throws URISyntaxException {
        log.debug("REST request to update SettingsHardware : {}", settingsHardwareDTO);
        if (settingsHardwareDTO.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        SettingsHardwareDTO result = settingsHardwareService.save(settingsHardwareDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, settingsHardwareDTO.getId().toString()))
            .body(result);
    }

    /**
     * GET  /settings-hardwares : get all the settingsHardwares.
     *
     * @return the ResponseEntity with status 200 (OK) and the list of settingsHardwares in body
     */
    @GetMapping("/settings-hardwares")
    @Timed
    public List<SettingsHardwareDTO> getAllSettingsHardwares() {
        log.debug("REST request to get all SettingsHardwares");
        return settingsHardwareService.findAll();
    }

    /**
     * GET  /settings-hardwares/:id : get the "id" settingsHardware.
     *
     * @param id the id of the settingsHardwareDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the settingsHardwareDTO, or with status 404 (Not Found)
     */
    @GetMapping("/settings-hardwares/{id}")
    @Timed
    public ResponseEntity<SettingsHardwareDTO> getSettingsHardware(@PathVariable String id) {
        log.debug("REST request to get SettingsHardware : {}", id);
        Optional<SettingsHardwareDTO> settingsHardwareDTO = settingsHardwareService.findOne(id);
        return ResponseUtil.wrapOrNotFound(settingsHardwareDTO);
    }

    /**
     * DELETE  /settings-hardwares/:id : delete the "id" settingsHardware.
     *
     * @param id the id of the settingsHardwareDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/settings-hardwares/{id}")
    @Timed
    public ResponseEntity<Void> deleteSettingsHardware(@PathVariable String id) {
        log.debug("REST request to delete SettingsHardware : {}", id);
        settingsHardwareService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id)).build();
    }
}
