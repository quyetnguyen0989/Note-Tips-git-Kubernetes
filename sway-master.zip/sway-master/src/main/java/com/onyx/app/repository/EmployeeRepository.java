package com.onyx.app.repository;

import org.springframework.stereotype.Repository;

import com.onyx.app.domain.Employee;

@Repository
public interface EmployeeRepository extends N1qlCouchbaseRepository<Employee, String>{

}
