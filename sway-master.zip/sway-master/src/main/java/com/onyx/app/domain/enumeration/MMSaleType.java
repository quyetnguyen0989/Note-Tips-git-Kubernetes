package com.onyx.app.domain.enumeration;

/**
 * The MMSaleType enumeration.
 */
public enum MMSaleType {
    PERCENT, AMOUNT
}
