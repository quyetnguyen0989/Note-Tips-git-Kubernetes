package com.onyx.app.domain;

import org.springframework.data.annotation.Id;
import com.couchbase.client.java.repository.annotation.Field;
import org.springframework.data.couchbase.core.mapping.Document;
import javax.validation.constraints.*;

import java.io.Serializable;
import java.util.Objects;

/**
 * A InvoiceDetails.
 */
@Document
public class InvoiceDetails implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    private String id;

    @Field("item_num")
    private String itemNum;

    @Field("inv_num")
    private String invNum;

    @NotNull
    @Size(max = 10)
    @Field("item_price")
    private String itemPrice;

    @Field("invoice_line_num")
    private Double invoiceLineNum;

    @Field("invoice_time_and_date")
    private String invoiceTimeAndDate;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getItemNum() {
        return itemNum;
    }

    public InvoiceDetails itemNum(String itemNum) {
        this.itemNum = itemNum;
        return this;
    }

    public void setItemNum(String itemNum) {
        this.itemNum = itemNum;
    }

    public String getInvNum() {
        return invNum;
    }

    public InvoiceDetails invNum(String invNum) {
        this.invNum = invNum;
        return this;
    }

    public void setInvNum(String invNum) {
        this.invNum = invNum;
    }

    public String getItemPrice() {
        return itemPrice;
    }

    public InvoiceDetails itemPrice(String itemPrice) {
        this.itemPrice = itemPrice;
        return this;
    }

    public void setItemPrice(String itemPrice) {
        this.itemPrice = itemPrice;
    }

    public Double getInvoiceLineNum() {
        return invoiceLineNum;
    }

    public InvoiceDetails invoiceLineNum(Double invoiceLineNum) {
        this.invoiceLineNum = invoiceLineNum;
        return this;
    }

    public void setInvoiceLineNum(Double invoiceLineNum) {
        this.invoiceLineNum = invoiceLineNum;
    }

    public String getInvoiceTimeAndDate() {
        return invoiceTimeAndDate;
    }

    public InvoiceDetails invoiceTimeAndDate(String invoiceTimeAndDate) {
        this.invoiceTimeAndDate = invoiceTimeAndDate;
        return this;
    }

    public void setInvoiceTimeAndDate(String invoiceTimeAndDate) {
        this.invoiceTimeAndDate = invoiceTimeAndDate;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        InvoiceDetails invoiceDetails = (InvoiceDetails) o;
        if (invoiceDetails.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), invoiceDetails.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "InvoiceDetails{" +
            "id=" + getId() +
            ", itemNum='" + getItemNum() + "'" +
            ", invNum='" + getInvNum() + "'" +
            ", itemPrice='" + getItemPrice() + "'" +
            ", invoiceLineNum=" + getInvoiceLineNum() +
            ", invoiceTimeAndDate='" + getInvoiceTimeAndDate() + "'" +
            "}";
    }
}
