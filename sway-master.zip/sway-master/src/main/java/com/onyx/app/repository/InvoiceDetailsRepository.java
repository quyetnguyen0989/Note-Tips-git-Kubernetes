package com.onyx.app.repository;

import org.springframework.stereotype.Repository;

import com.onyx.app.domain.InvoiceDetails;

/**
 * Spring Data MongoDB repository for the InvoiceDetails entity.
 */
@SuppressWarnings("unused")
@Repository
public interface InvoiceDetailsRepository extends N1qlCouchbaseRepository<InvoiceDetails, String> {

}
