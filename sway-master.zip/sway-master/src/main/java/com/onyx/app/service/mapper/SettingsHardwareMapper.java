package com.onyx.app.service.mapper;

import com.onyx.app.domain.*;
import com.onyx.app.service.dto.SettingsHardwareDTO;

import org.mapstruct.*;

/**
 * Mapper for the entity SettingsHardware and its DTO SettingsHardwareDTO.
 */
@Mapper(componentModel = "spring", uses = {})
public interface SettingsHardwareMapper extends EntityMapper<SettingsHardwareDTO, SettingsHardware> {


}
