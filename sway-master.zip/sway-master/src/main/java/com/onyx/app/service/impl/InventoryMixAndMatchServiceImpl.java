package com.onyx.app.service.impl;

import com.onyx.app.service.InventoryMixAndMatchService;
import com.onyx.app.domain.InventoryMixAndMatch;
import com.onyx.app.repository.InventoryMixAndMatchRepository;
import com.onyx.app.service.dto.InventoryMixAndMatchDTO;
import com.onyx.app.service.mapper.InventoryMixAndMatchMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.stereotype.Service;

import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
/**
 * Service Implementation for managing InventoryMixAndMatch.
 */
@Service
public class InventoryMixAndMatchServiceImpl implements InventoryMixAndMatchService {

    private final Logger log = LoggerFactory.getLogger(InventoryMixAndMatchServiceImpl.class);

    private final InventoryMixAndMatchRepository inventoryMixAndMatchRepository;

    private final InventoryMixAndMatchMapper inventoryMixAndMatchMapper;

    public InventoryMixAndMatchServiceImpl(InventoryMixAndMatchRepository inventoryMixAndMatchRepository, InventoryMixAndMatchMapper inventoryMixAndMatchMapper) {
        this.inventoryMixAndMatchRepository = inventoryMixAndMatchRepository;
        this.inventoryMixAndMatchMapper = inventoryMixAndMatchMapper;
    }

    /**
     * Save a inventoryMixAndMatch.
     *
     * @param inventoryMixAndMatchDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public InventoryMixAndMatchDTO save(InventoryMixAndMatchDTO inventoryMixAndMatchDTO) {
        log.debug("Request to save InventoryMixAndMatch : {}", inventoryMixAndMatchDTO);
        InventoryMixAndMatch inventoryMixAndMatch = inventoryMixAndMatchMapper.toEntity(inventoryMixAndMatchDTO);
        inventoryMixAndMatch = inventoryMixAndMatchRepository.save(inventoryMixAndMatch);
        return inventoryMixAndMatchMapper.toDto(inventoryMixAndMatch);
    }

    /**
     * Get all the inventoryMixAndMatches.
     *
     * @return the list of entities
     */
    @Override
    public List<InventoryMixAndMatchDTO> findAll() {
        log.debug("Request to get all InventoryMixAndMatches");
        return inventoryMixAndMatchRepository.findAll().stream()
            .map(inventoryMixAndMatchMapper::toDto)
            .collect(Collectors.toCollection(LinkedList::new));
    }


    /**
     * Get one inventoryMixAndMatch by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    public Optional<InventoryMixAndMatchDTO> findOne(String id) {
        log.debug("Request to get InventoryMixAndMatch : {}", id);
        return inventoryMixAndMatchRepository.findById(id)
            .map(inventoryMixAndMatchMapper::toDto);
    }

    /**
     * Delete the inventoryMixAndMatch by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(String id) {
        log.debug("Request to delete InventoryMixAndMatch : {}", id);
        inventoryMixAndMatchRepository.deleteById(id);
    }
}
