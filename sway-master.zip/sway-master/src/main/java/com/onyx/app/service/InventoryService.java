package com.onyx.app.service;

import com.onyx.app.service.dto.InventoryDTO;

import java.util.List;
import java.util.Optional;

/**
 * Service Interface for managing Inventory.
 */
public interface InventoryService {

    /**
     * Save a inventory.
     *
     * @param inventoryDTO the entity to save
     * @return the persisted entity
     * @throws Exception 
     */
    InventoryDTO save(InventoryDTO inventoryDTO) throws Exception;

    /**
     * Get all the inventories.
     *
     * @return the list of entities
     */
    List<InventoryDTO> findAll();


    /**
     * Get the "id" inventory.
     *
     * @param id the id of the entity
     * @return the entity
     */
    Optional<InventoryDTO> findOne(String id);

    /**
     * Delete the "id" inventory.
     *
     * @param id the id of the entity
     */
    void delete(String id);
}
