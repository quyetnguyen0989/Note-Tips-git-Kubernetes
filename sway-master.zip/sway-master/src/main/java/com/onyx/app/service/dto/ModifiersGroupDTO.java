package com.onyx.app.service.dto;

import java.io.Serializable;
import java.util.List;
import java.util.Objects;

import com.onyx.app.domain.Modifier;

/**
 * A DTO for the ModifiersGroup entity.
 */
public class ModifiersGroupDTO implements Serializable {

	private static final long serialVersionUID = 3018943208531173183L;

	private String id;

	private Integer storeid;

	private Integer modifierGroupID;

	private String modifierGroupName;

	private List<Modifier> modifiers;

	// private String modifierName;
	//
	// private Integer modifierID;
	//
	// private Long modifierNum;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Integer getStoreid() {
		return storeid;
	}

	public void setStoreid(Integer storeid) {
		this.storeid = storeid;
	}

	public Integer getModifierGroupID() {
		return modifierGroupID;
	}

	public void setModifierGroupID(Integer modifierGroupID) {
		this.modifierGroupID = modifierGroupID;
	}

	// public String getModifierName() {
	// return modifierName;
	// }
	//
	// public void setModifierName(String modifierName) {
	// this.modifierName = modifierName;
	// }
	//
	// public Integer getModifierID() {
	// return modifierID;
	// }
	//
	// public void setModifierID(Integer modifierID) {
	// this.modifierID = modifierID;
	// }
	//
	// public Long getModifierNum() {
	// return modifierNum;
	// }
	//
	// public void setModifierNum(Long modifierNum) {
	// this.modifierNum = modifierNum;
	// }

	public String getModifierGroupName() {
		return modifierGroupName;
	}

	public void setModifierGroupName(String modifierGroupName) {
		this.modifierGroupName = modifierGroupName;
	}

	public List<Modifier> getModifiers() {
		return modifiers;
	}

	public void setModifiers(List<Modifier> modifiers) {
		this.modifiers = modifiers;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}

		ModifiersGroupDTO modifiersGroupDTO = (ModifiersGroupDTO) o;
		if (modifiersGroupDTO.getId() == null || getId() == null) {
			return false;
		}
		return Objects.equals(getId(), modifiersGroupDTO.getId());
	}

	@Override
	public int hashCode() {
		return Objects.hashCode(getId());
	}

	@Override
	public String toString() {
		return "ModifiersGroupDTO [id=" + id + ", storeid=" + storeid + ", modifierGroupID=" + modifierGroupID
				+ ", modifierGroupName=" + modifierGroupName + ", modifiers=" + modifiers + "]";
	}

}
