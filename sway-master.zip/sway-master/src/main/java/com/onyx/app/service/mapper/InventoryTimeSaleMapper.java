package com.onyx.app.service.mapper;

import com.onyx.app.domain.*;
import com.onyx.app.service.dto.InventoryTimeSaleDTO;

import org.mapstruct.*;

/**
 * Mapper for the entity InventoryTimeSale and its DTO InventoryTimeSaleDTO.
 */
@Mapper(componentModel = "spring", uses = {})
public interface InventoryTimeSaleMapper extends EntityMapper<InventoryTimeSaleDTO, InventoryTimeSale> {


}
