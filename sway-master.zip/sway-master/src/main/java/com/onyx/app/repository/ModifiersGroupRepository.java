package com.onyx.app.repository;

import com.onyx.app.domain.ModifiersGroup;
import org.springframework.stereotype.Repository;

/**
 * Spring Data Couchbase repository for the ModifiersGroup entity.
 */
@SuppressWarnings("unused")
@Repository
public interface ModifiersGroupRepository extends N1qlCouchbaseRepository<ModifiersGroup, String> {

}
