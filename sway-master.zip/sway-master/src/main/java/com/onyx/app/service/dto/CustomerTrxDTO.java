package com.onyx.app.service.dto;

import java.io.Serializable;
import java.util.Objects;

/**
 * A DTO for the CustomerTrx entity.
 */
public class CustomerTrxDTO implements Serializable {

    private String id;

    private Integer custNum;

    private Integer invNum;

    private Integer storeId;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getCustNum() {
        return custNum;
    }

    public void setCustNum(Integer custNum) {
        this.custNum = custNum;
    }

    public Integer getInvNum() {
        return invNum;
    }

    public void setInvNum(Integer invNum) {
        this.invNum = invNum;
    }

    public Integer getStoreId() {
        return storeId;
    }

    public void setStoreId(Integer storeId) {
        this.storeId = storeId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        CustomerTrxDTO customerTrxDTO = (CustomerTrxDTO) o;
        if (customerTrxDTO.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), customerTrxDTO.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "CustomerTrxDTO{" +
            "id=" + getId() +
            ", custNum=" + getCustNum() +
            ", invNum=" + getInvNum() +
            ", storeId=" + getStoreId() +
            "}";
    }
}
