package com.onyx.app.service.mapper;

import com.onyx.app.domain.*;
import com.onyx.app.service.dto.CustomertrxDTO;

import org.mapstruct.*;

/**
 * Mapper for the entity Customertrx and its DTO CustomertrxDTO.
 */
@Mapper(componentModel = "spring", uses = {})
public interface CustomertrxMapper extends EntityMapper<CustomertrxDTO, Customertrx> {


}
