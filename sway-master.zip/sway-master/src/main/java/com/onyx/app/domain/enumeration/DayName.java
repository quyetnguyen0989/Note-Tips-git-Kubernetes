package com.onyx.app.domain.enumeration;

public enum DayName {
    SATURDAY,SUNDAY,MONDAY,TUESDAY,WEDNESDAY,THURSDAY,FRIDAY
}
