package com.onyx.app.domain;


import org.springframework.data.annotation.Id;
import com.couchbase.client.java.repository.annotation.Field;
import org.springframework.data.couchbase.core.mapping.Document;
import org.springframework.data.couchbase.core.mapping.id.GeneratedValue;
import org.springframework.data.couchbase.core.mapping.id.IdPrefix;
import javax.validation.constraints.*;

import java.io.Serializable;
import java.util.Objects;

import static com.onyx.app.config.Constants.ID_DELIMITER;
import static org.springframework.data.couchbase.core.mapping.id.GenerationStrategy.UNIQUE;

/**
 * A StoreLocal.
 */
@Document
public class StoreLocal implements Serializable {

    private static final long serialVersionUID = 1L;
    public static final String PREFIX = "storelocal";

    @SuppressWarnings("unused")
    @IdPrefix
    private String prefix = PREFIX;

    @Id
    @GeneratedValue(strategy = UNIQUE, delimiter = ID_DELIMITER)
    private String id;

    @NotNull
    @Field("store_id")
    private Integer storeId;

    @Field("company_id")
    private Integer companyId;

    @Field("num_stations")
    private Integer numStations;

    @NotNull
    @Size(max = 50)
    @Field("company_name")
    private String companyName;

    @Size(max = 50)
    @Field("company_address")
    private String companyAddress;

    @Size(max = 50)
    @Field("company_city")
    private String companyCity;

    @Size(max = 20)
    @Field("company_state")
    private String companyState;

    @Field("company_zip")
    private Integer companyZip;

    @Field("company_phone")
    private String companyPhone;

    @Size(max = 50)
    @Field("invoice_notes")
    private String invoiceNotes;

    @Size(max = 50)
    @Field("logo_location")
    private String logoLocation;

    @Field("tax_id")
    private Integer taxId;

    @Size(max = 50)
    @Field("store_email")
    private String storeEmail;

    @Field("tax_rate")
    private Integer taxRate;

    @Field("open")
    private Boolean open;

    @Field("time-text")
    private String timeText;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getStoreId() {
        return storeId;
    }

    public StoreLocal storeId(Integer storeId) {
        this.storeId = storeId;
        return this;
    }

    public void setStoreId(Integer storeId) {
        this.storeId = storeId;
    }

    public Integer getCompanyId() {
        return companyId;
    }

    public StoreLocal companyId(Integer companyId) {
        this.companyId = companyId;
        return this;
    }

    public void setCompanyId(Integer companyId) {
        this.companyId = companyId;
    }

    public Integer getNumStations() {
        return numStations;
    }

    public StoreLocal numStations(Integer numStations) {
        this.numStations = numStations;
        return this;
    }

    public void setNumStations(Integer numStations) {
        this.numStations = numStations;
    }

    public String getCompanyName() {
        return companyName;
    }

    public StoreLocal companyName(String companyName) {
        this.companyName = companyName;
        return this;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getCompanyAddress() {
        return companyAddress;
    }

    public StoreLocal companyAddress(String companyAddress) {
        this.companyAddress = companyAddress;
        return this;
    }

    public void setCompanyAddress(String companyAddress) {
        this.companyAddress = companyAddress;
    }

    public String getCompanyCity() {
        return companyCity;
    }

    public StoreLocal companyCity(String companyCity) {
        this.companyCity = companyCity;
        return this;
    }

    public void setCompanyCity(String companyCity) {
        this.companyCity = companyCity;
    }

    public String getCompanyState() {
        return companyState;
    }

    public StoreLocal companyState(String companyState) {
        this.companyState = companyState;
        return this;
    }

    public void setCompanyState(String companyState) {
        this.companyState = companyState;
    }

    public Integer getCompanyZip() {
        return companyZip;
    }

    public StoreLocal companyZip(Integer companyZip) {
        this.companyZip = companyZip;
        return this;
    }

    public void setCompanyZip(Integer companyZip) {
        this.companyZip = companyZip;
    }

    public String getCompanyPhone() {
        return companyPhone;
    }

    public StoreLocal companyPhone(String companyPhone) {
        this.companyPhone = companyPhone;
        return this;
    }

    public void setCompanyPhone(String companyPhone) {
        this.companyPhone = companyPhone;
    }

    public String getInvoiceNotes() {
        return invoiceNotes;
    }

    public StoreLocal invoiceNotes(String invoiceNotes) {
        this.invoiceNotes = invoiceNotes;
        return this;
    }

    public void setInvoiceNotes(String invoiceNotes) {
        this.invoiceNotes = invoiceNotes;
    }

    public String getLogoLocation() {
        return logoLocation;
    }

    public StoreLocal logoLocation(String logoLocation) {
        this.logoLocation = logoLocation;
        return this;
    }

    public void setLogoLocation(String logoLocation) {
        this.logoLocation = logoLocation;
    }

    public Integer getTaxId() {
        return taxId;
    }

    public StoreLocal taxId(Integer taxId) {
        this.taxId = taxId;
        return this;
    }

    public void setTaxId(Integer taxId) {
        this.taxId = taxId;
    }

    public String getStoreEmail() {
        return storeEmail;
    }

    public StoreLocal storeEmail(String storeEmail) {
        this.storeEmail = storeEmail;
        return this;
    }

    public void setStoreEmail(String storeEmail) {
        this.storeEmail = storeEmail;
    }

    public Integer getTaxRate() {
        return taxRate;
    }

    public StoreLocal taxRate(Integer taxRate) {
        this.taxRate = taxRate;
        return this;
    }

    public void setTaxRate(Integer taxRate) {
        this.taxRate = taxRate;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove


    public Boolean getOpen() {
        return open;
    }

    public void setOpen(Boolean open) {
        this.open = open;
    }

    public String getTimeText() {
        return timeText;
    }

    public void setTimeText(String timeText) {
        this.timeText = timeText;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        StoreLocal storeLocal = (StoreLocal) o;
        if (storeLocal.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), storeLocal.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "StoreLocal{" +
            "id=" + getId() +
            ", storeId=" + getStoreId() +
            ", companyId=" + getCompanyId() +
            ", numStations=" + getNumStations() +
            ", companyName='" + getCompanyName() + "'" +
            ", companyAddress='" + getCompanyAddress() + "'" +
            ", companyCity='" + getCompanyCity() + "'" +
            ", companyState='" + getCompanyState() + "'" +
            ", companyZip=" + getCompanyZip() +
            ", companyPhone='" + getCompanyPhone() + "'" +
            ", invoiceNotes='" + getInvoiceNotes() + "'" +
            ", logoLocation='" + getLogoLocation() + "'" +
            ", taxId=" + getTaxId() +
            ", storeEmail='" + getStoreEmail() + "'" +
            ", taxRate=" + getTaxRate() +
            "}";
    }
}
