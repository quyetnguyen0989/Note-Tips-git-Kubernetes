package com.onyx.app.response;


public class ModifierResponse {

	private String id;
	
	private String modifierName;

	private Integer modifierID;

	private Long modifierNum;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getModifierName() {
		return modifierName;
	}

	public void setModifierName(String modifierName) {
		this.modifierName = modifierName;
	}

	public Integer getModifierID() {
		return modifierID;
	}

	public void setModifierID(Integer modifierID) {
		this.modifierID = modifierID;
	}

	public Long getModifierNum() {
		return modifierNum;
	}

	public void setModifierNum(Long modifierNum) {
		this.modifierNum = modifierNum;
	}
	
	
}
