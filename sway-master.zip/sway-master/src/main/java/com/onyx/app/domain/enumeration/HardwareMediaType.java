package com.onyx.app.domain.enumeration;

/**
 * The HardwareMediaType enumeration.
 */
public enum HardwareMediaType {
    CAST, ONLINE, INHOUSE
}
