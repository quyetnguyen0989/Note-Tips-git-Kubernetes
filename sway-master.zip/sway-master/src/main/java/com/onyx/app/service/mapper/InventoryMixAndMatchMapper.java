package com.onyx.app.service.mapper;

import com.onyx.app.domain.*;
import com.onyx.app.service.dto.InventoryMixAndMatchDTO;

import org.mapstruct.*;

/**
 * Mapper for the entity InventoryMixAndMatch and its DTO InventoryMixAndMatchDTO.
 */
@Mapper(componentModel = "spring", uses = {})
public interface InventoryMixAndMatchMapper extends EntityMapper<InventoryMixAndMatchDTO, InventoryMixAndMatch> {


}
