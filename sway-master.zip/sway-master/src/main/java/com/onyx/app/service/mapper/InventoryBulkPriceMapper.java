package com.onyx.app.service.mapper;

import com.onyx.app.domain.*;
import com.onyx.app.service.dto.InventoryBulkPriceDTO;

import org.mapstruct.*;

/**
 * Mapper for the entity InventoryBulkPrice and its DTO InventoryBulkPriceDTO.
 */
@Mapper(componentModel = "spring", uses = {})
public interface InventoryBulkPriceMapper extends EntityMapper<InventoryBulkPriceDTO, InventoryBulkPrice> {


}
