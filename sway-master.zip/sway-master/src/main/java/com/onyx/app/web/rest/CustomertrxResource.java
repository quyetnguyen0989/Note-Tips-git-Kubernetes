package com.onyx.app.web.rest;

import com.codahale.metrics.annotation.Timed;
import com.onyx.app.service.CustomertrxService;
import com.onyx.app.web.rest.errors.BadRequestAlertException;
import com.onyx.app.web.rest.util.HeaderUtil;
import com.onyx.app.service.dto.CustomertrxDTO;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.net.URISyntaxException;

import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing Customertrx.
 */
@RestController
@RequestMapping("/api")
public class CustomertrxResource {

    private final Logger log = LoggerFactory.getLogger(CustomertrxResource.class);

    private static final String ENTITY_NAME = "customertrx";

    private final CustomertrxService customertrxService;

    public CustomertrxResource(CustomertrxService customertrxService) {
        this.customertrxService = customertrxService;
    }

    /**
     * POST  /customertrxes : Create a new customertrx.
     *
     * @param customertrxDTO the customertrxDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new customertrxDTO, or with status 400 (Bad Request) if the customertrx has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/customertrxes")
    @Timed
    public ResponseEntity<CustomertrxDTO> createCustomertrx(@RequestBody CustomertrxDTO customertrxDTO) throws URISyntaxException {
        log.debug("REST request to save Customertrx : {}", customertrxDTO);
        if (customertrxDTO.getId() != null) {
            throw new BadRequestAlertException("A new customertrx cannot already have an ID", ENTITY_NAME, "idexists");
        }
        CustomertrxDTO result = customertrxService.save(customertrxDTO);
        return ResponseEntity.created(new URI("/api/customertrxes/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /customertrxes : Updates an existing customertrx.
     *
     * @param customertrxDTO the customertrxDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated customertrxDTO,
     * or with status 400 (Bad Request) if the customertrxDTO is not valid,
     * or with status 500 (Internal Server Error) if the customertrxDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/customertrxes")
    @Timed
    public ResponseEntity<CustomertrxDTO> updateCustomertrx(@RequestBody CustomertrxDTO customertrxDTO) throws URISyntaxException {
        log.debug("REST request to update Customertrx : {}", customertrxDTO);
        if (customertrxDTO.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        CustomertrxDTO result = customertrxService.save(customertrxDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, customertrxDTO.getId().toString()))
            .body(result);
    }

    /**
     * GET  /customertrxes : get all the customertrxes.
     *
     * @return the ResponseEntity with status 200 (OK) and the list of customertrxes in body
     */
    @GetMapping("/customertrxes")
    @Timed
    public List<CustomertrxDTO> getAllCustomertrxes() {
        log.debug("REST request to get all Customertrxes");
        return customertrxService.findAll();
    }

    /**
     * GET  /customertrxes/:id : get the "id" customertrx.
     *
     * @param id the id of the customertrxDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the customertrxDTO, or with status 404 (Not Found)
     */
    @GetMapping("/customertrxes/{id}")
    @Timed
    public ResponseEntity<CustomertrxDTO> getCustomertrx(@PathVariable String id) {
        log.debug("REST request to get Customertrx : {}", id);
        Optional<CustomertrxDTO> customertrxDTO = customertrxService.findOne(id);
        return ResponseUtil.wrapOrNotFound(customertrxDTO);
    }

    /**
     * DELETE  /customertrxes/:id : delete the "id" customertrx.
     *
     * @param id the id of the customertrxDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/customertrxes/{id}")
    @Timed
    public ResponseEntity<Void> deleteCustomertrx(@PathVariable String id) {
        log.debug("REST request to delete Customertrx : {}", id);
        customertrxService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id)).build();
    }
}
