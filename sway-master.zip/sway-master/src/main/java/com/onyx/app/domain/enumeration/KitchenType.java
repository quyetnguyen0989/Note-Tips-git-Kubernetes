package com.onyx.app.domain.enumeration;

/**
 * The KitchenType enumeration.
 */
public enum KitchenType {
    EPSON, STAR, KDS
}
