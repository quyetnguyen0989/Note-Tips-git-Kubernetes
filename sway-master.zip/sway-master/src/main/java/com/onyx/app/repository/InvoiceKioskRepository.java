package com.onyx.app.repository;

import com.onyx.app.domain.InvoiceKiosk;
import org.springframework.stereotype.Repository;

/**
 * Spring Data Couchbase repository for the InvoiceKiosk entity.
 */
@SuppressWarnings("unused")
@Repository
public interface InvoiceKioskRepository extends N1qlCouchbaseRepository<InvoiceKiosk, String> {

}
