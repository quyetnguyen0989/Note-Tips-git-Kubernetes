package com.onyx.app.service;

import com.onyx.app.service.dto.InventoryAttributeDTO;

import java.util.List;
import java.util.Optional;

/**
 * Service Interface for managing InventoryAttribute.
 */
public interface InventoryAttributeService {

    /**
     * Save a inventoryAttribute.
     *
     * @param inventoryAttributeDTO the entity to save
     * @return the persisted entity
     */
    InventoryAttributeDTO save(InventoryAttributeDTO inventoryAttributeDTO);

    /**
     * Get all the inventoryAttributes.
     *
     * @return the list of entities
     */
    List<InventoryAttributeDTO> findAll();


    /**
     * Get the "id" inventoryAttribute.
     *
     * @param id the id of the entity
     * @return the entity
     */
    Optional<InventoryAttributeDTO> findOne(String id);

    /**
     * Delete the "id" inventoryAttribute.
     *
     * @param id the id of the entity
     */
    void delete(String id);
}
