package com.onyx.app.service.dto;

import java.time.ZonedDateTime;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.Objects;

/**
 * A DTO for the Transfers entity.
 */
public class TransfersDTO implements Serializable {

    private String id;

    private Integer storeIdOrg;

    private Integer storeIdDes;

    private Integer cashierId;

    private Integer transferId;

    private ZonedDateTime createdTime;

    @NotNull
    private Integer itemNum;

    private Integer itemQtyOut;

    private Integer itemQtyIn;

    private String itemName;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getStoreIdOrg() {
        return storeIdOrg;
    }

    public void setStoreIdOrg(Integer storeIdOrg) {
        this.storeIdOrg = storeIdOrg;
    }

    public Integer getStoreIdDes() {
        return storeIdDes;
    }

    public void setStoreIdDes(Integer storeIdDes) {
        this.storeIdDes = storeIdDes;
    }

    public Integer getCashierId() {
        return cashierId;
    }

    public void setCashierId(Integer cashierId) {
        this.cashierId = cashierId;
    }

    public Integer getTransferId() {
        return transferId;
    }

    public void setTransferId(Integer transferId) {
        this.transferId = transferId;
    }

    public ZonedDateTime getCreatedTime() {
        return createdTime;
    }

    public void setCreatedTime(ZonedDateTime createdTime) {
        this.createdTime = createdTime;
    }

    public Integer getItemNum() {
        return itemNum;
    }

    public void setItemNum(Integer itemNum) {
        this.itemNum = itemNum;
    }

    public Integer getItemQtyOut() {
        return itemQtyOut;
    }

    public void setItemQtyOut(Integer itemQtyOut) {
        this.itemQtyOut = itemQtyOut;
    }

    public Integer getItemQtyIn() {
        return itemQtyIn;
    }

    public void setItemQtyIn(Integer itemQtyIn) {
        this.itemQtyIn = itemQtyIn;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        TransfersDTO transfersDTO = (TransfersDTO) o;
        if (transfersDTO.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), transfersDTO.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "TransfersDTO{" +
            "id=" + getId() +
            ", storeIdOrg=" + getStoreIdOrg() +
            ", storeIdDes=" + getStoreIdDes() +
            ", cashierId=" + getCashierId() +
            ", transferId=" + getTransferId() +
            ", createdTime='" + getCreatedTime() + "'" +
            ", itemNum=" + getItemNum() +
            ", itemQtyOut=" + getItemQtyOut() +
            ", itemQtyIn=" + getItemQtyIn() +
            ", itemName='" + getItemName() + "'" +
            "}";
    }
}
