package com.onyx.app.web.rest;

import com.codahale.metrics.annotation.Timed;
import com.onyx.app.service.InvoiceDetailsService;
import com.onyx.app.web.rest.errors.BadRequestAlertException;
import com.onyx.app.web.rest.util.HeaderUtil;
import com.onyx.app.service.dto.InvoiceDetailsDTO;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;

import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing InvoiceDetails.
 */
@RestController
@RequestMapping("/api")
public class InvoiceDetailsResource {

    private final Logger log = LoggerFactory.getLogger(InvoiceDetailsResource.class);

    private static final String ENTITY_NAME = "invoiceDetails";

    private final InvoiceDetailsService invoiceDetailsService;

    public InvoiceDetailsResource(InvoiceDetailsService invoiceDetailsService) {
        this.invoiceDetailsService = invoiceDetailsService;
    }

    /**
     * POST  /invoice-details : Create a new invoiceDetails.
     *
     * @param invoiceDetailsDTO the invoiceDetailsDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new invoiceDetailsDTO, or with status 400 (Bad Request) if the invoiceDetails has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/invoice-details")
    @Timed
    public ResponseEntity<InvoiceDetailsDTO> createInvoiceDetails(@Valid @RequestBody InvoiceDetailsDTO invoiceDetailsDTO) throws URISyntaxException {
        log.debug("REST request to save InvoiceDetails : {}", invoiceDetailsDTO);
        if (invoiceDetailsDTO.getId() != null) {
            throw new BadRequestAlertException("A new invoiceDetails cannot already have an ID", ENTITY_NAME, "idexists");
        }
        InvoiceDetailsDTO result = invoiceDetailsService.save(invoiceDetailsDTO);
        return ResponseEntity.created(new URI("/api/invoice-details/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /invoice-details : Updates an existing invoiceDetails.
     *
     * @param invoiceDetailsDTO the invoiceDetailsDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated invoiceDetailsDTO,
     * or with status 400 (Bad Request) if the invoiceDetailsDTO is not valid,
     * or with status 500 (Internal Server Error) if the invoiceDetailsDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/invoice-details")
    @Timed
    public ResponseEntity<InvoiceDetailsDTO> updateInvoiceDetails(@Valid @RequestBody InvoiceDetailsDTO invoiceDetailsDTO) throws URISyntaxException {
        log.debug("REST request to update InvoiceDetails : {}", invoiceDetailsDTO);
        if (invoiceDetailsDTO.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        InvoiceDetailsDTO result = invoiceDetailsService.save(invoiceDetailsDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, invoiceDetailsDTO.getId().toString()))
            .body(result);
    }

    /**
     * GET  /invoice-details : get all the invoiceDetails.
     *
     * @return the ResponseEntity with status 200 (OK) and the list of invoiceDetails in body
     */
    @GetMapping("/invoice-details")
    @Timed
    public List<InvoiceDetailsDTO> getAllInvoiceDetails() {
        log.debug("REST request to get all InvoiceDetails");
        return invoiceDetailsService.findAll();
    }

    /**
     * GET  /invoice-details/:id : get the "id" invoiceDetails.
     *
     * @param id the id of the invoiceDetailsDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the invoiceDetailsDTO, or with status 404 (Not Found)
     */
    @GetMapping("/invoice-details/{id}")
    @Timed
    public ResponseEntity<InvoiceDetailsDTO> getInvoiceDetails(@PathVariable String id) {
        log.debug("REST request to get InvoiceDetails : {}", id);
        Optional<InvoiceDetailsDTO> invoiceDetailsDTO = invoiceDetailsService.findOne(id);
        return ResponseUtil.wrapOrNotFound(invoiceDetailsDTO);
    }

    /**
     * DELETE  /invoice-details/:id : delete the "id" invoiceDetails.
     *
     * @param id the id of the invoiceDetailsDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/invoice-details/{id}")
    @Timed
    public ResponseEntity<Void> deleteInvoiceDetails(@PathVariable String id) {
        log.debug("REST request to delete InvoiceDetails : {}", id);
        invoiceDetailsService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id)).build();
    }
}
