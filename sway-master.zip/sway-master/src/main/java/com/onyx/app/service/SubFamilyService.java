package com.onyx.app.service;

import com.onyx.app.service.dto.SubFamilyDTO;

import java.util.List;
import java.util.Optional;

/**
 * Service Interface for managing SubFamily.
 */
public interface SubFamilyService {

    /**
     * Save a subFamily.
     *
     * @param subFamilyDTO the entity to save
     * @return the persisted entity
     */
    SubFamilyDTO save(SubFamilyDTO subFamilyDTO);

    /**
     * Get all the subFamilies.
     *
     * @return the list of entities
     */
    List<SubFamilyDTO> findAll();


    /**
     * Get the "id" subFamily.
     *
     * @param id the id of the entity
     * @return the entity
     */
    Optional<SubFamilyDTO> findOne(String id);

    /**
     * Delete the "id" subFamily.
     *
     * @param id the id of the entity
     */
    void delete(String id);
}
