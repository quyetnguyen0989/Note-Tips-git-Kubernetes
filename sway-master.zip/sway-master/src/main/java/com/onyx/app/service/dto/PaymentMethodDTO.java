package com.onyx.app.service.dto;

import java.io.Serializable;
import java.util.Objects;

/**
 * A DTO for the PaymentMethod entity.
 */
public class PaymentMethodDTO implements Serializable {

    private String id;

    private Integer paymentTypeID;

    private Integer storeid;

    private String description;

    private String tagid;

    private Integer numReceipts;

    private Boolean signature;

    private String currencytag;

    private Boolean checkID;

    private Boolean active;

    private Boolean processes;

    private Boolean taxExempt;

    private Boolean customerRequired;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getPaymentTypeID() {
        return paymentTypeID;
    }

    public void setPaymentTypeID(Integer paymentTypeID) {
        this.paymentTypeID = paymentTypeID;
    }

    public Integer getStoreid() {
        return storeid;
    }

    public void setStoreid(Integer storeid) {
        this.storeid = storeid;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getTagid() {
        return tagid;
    }

    public void setTagid(String tagid) {
        this.tagid = tagid;
    }

    public Integer getNumReceipts() {
        return numReceipts;
    }

    public void setNumReceipts(Integer numReceipts) {
        this.numReceipts = numReceipts;
    }

    public Boolean isSignature() {
        return signature;
    }

    public void setSignature(Boolean signature) {
        this.signature = signature;
    }

    public String getCurrencytag() {
        return currencytag;
    }

    public void setCurrencytag(String currencytag) {
        this.currencytag = currencytag;
    }

    public Boolean isCheckID() {
        return checkID;
    }

    public void setCheckID(Boolean checkID) {
        this.checkID = checkID;
    }

    public Boolean isActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    public Boolean isProcesses() {
        return processes;
    }

    public void setProcesses(Boolean processes) {
        this.processes = processes;
    }

    public Boolean isTaxExempt() {
        return taxExempt;
    }

    public void setTaxExempt(Boolean taxExempt) {
        this.taxExempt = taxExempt;
    }

    public Boolean isCustomerRequired() {
        return customerRequired;
    }

    public void setCustomerRequired(Boolean customerRequired) {
        this.customerRequired = customerRequired;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        PaymentMethodDTO paymentMethodDTO = (PaymentMethodDTO) o;
        if (paymentMethodDTO.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), paymentMethodDTO.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "PaymentMethodDTO{" +
            "id=" + getId() +
            ", paymentTypeID=" + getPaymentTypeID() +
            ", storeid=" + getStoreid() +
            ", description='" + getDescription() + "'" +
            ", tagid='" + getTagid() + "'" +
            ", numReceipts=" + getNumReceipts() +
            ", signature='" + isSignature() + "'" +
            ", currencytag='" + getCurrencytag() + "'" +
            ", checkID='" + isCheckID() + "'" +
            ", active='" + isActive() + "'" +
            ", processes='" + isProcesses() + "'" +
            ", taxExempt='" + isTaxExempt() + "'" +
            ", customerRequired='" + isCustomerRequired() + "'" +
            "}";
    }
}
