package com.onyx.app.web.rest.errors;

public enum ErrorMessages {

	MODIFIER_NOT_FOUND("Modifier not exists!"),
	MODIFIER_GROUP_NOT_FOUND("Modifier Group not exists!"),
	BRAND_NOT_FOUND("Brand not exist!"),
	FAMILY_NOT_FOUND("Family not exist!"),
	SUBFAMILY_NOT_FOUND("SubFamily not exists!"),
	SECTION_NOT_FOUND("Section not exists!"),
	STORE_NOT_FOUND("Store not exists!"),
	DEPT_NOT_FOUND("Department not exists!"),
	INVENTORY_NOT_FOUND("Item not exists!"),
	CATEGORY_NOT_FOUND("Category not exists!");
	
	public String errorMessage;
	
	private ErrorMessages(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	
	
}
