package com.onyx.app.repository;

import org.springframework.stereotype.Repository;

import com.onyx.app.domain.InvoiceOnHold;

/**
 * Spring Data MongoDB repository for the InvoiceOnHold entity.
 */
@SuppressWarnings("unused")
@Repository
public interface InvoiceOnHoldRepository extends N1qlCouchbaseRepository<InvoiceOnHold, String> {

}
