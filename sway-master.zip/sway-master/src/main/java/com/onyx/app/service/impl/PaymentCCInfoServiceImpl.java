package com.onyx.app.service.impl;

import com.onyx.app.service.PaymentCCInfoService;
import com.onyx.app.domain.PaymentCCInfo;
import com.onyx.app.repository.PaymentCCInfoRepository;
import com.onyx.app.service.dto.PaymentCCInfoDTO;
import com.onyx.app.service.mapper.PaymentCCInfoMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.stereotype.Service;

import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
/**
 * Service Implementation for managing PaymentCCInfo.
 */
@Service
public class PaymentCCInfoServiceImpl implements PaymentCCInfoService {

    private final Logger log = LoggerFactory.getLogger(PaymentCCInfoServiceImpl.class);

    private final PaymentCCInfoRepository paymentCCInfoRepository;

    private final PaymentCCInfoMapper paymentCCInfoMapper;

    public PaymentCCInfoServiceImpl(PaymentCCInfoRepository paymentCCInfoRepository, PaymentCCInfoMapper paymentCCInfoMapper) {
        this.paymentCCInfoRepository = paymentCCInfoRepository;
        this.paymentCCInfoMapper = paymentCCInfoMapper;
    }

    /**
     * Save a paymentCCInfo.
     *
     * @param paymentCCInfoDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public PaymentCCInfoDTO save(PaymentCCInfoDTO paymentCCInfoDTO) {
        log.debug("Request to save PaymentCCInfo : {}", paymentCCInfoDTO);
        PaymentCCInfo paymentCCInfo = paymentCCInfoMapper.toEntity(paymentCCInfoDTO);
        paymentCCInfo = paymentCCInfoRepository.save(paymentCCInfo);
        return paymentCCInfoMapper.toDto(paymentCCInfo);
    }

    /**
     * Get all the paymentCCInfos.
     *
     * @return the list of entities
     */
    @Override
    public List<PaymentCCInfoDTO> findAll() {
        log.debug("Request to get all PaymentCCInfos");
        return paymentCCInfoRepository.findAll().stream()
            .map(paymentCCInfoMapper::toDto)
            .collect(Collectors.toCollection(LinkedList::new));
    }


    /**
     * Get one paymentCCInfo by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    public Optional<PaymentCCInfoDTO> findOne(String id) {
        log.debug("Request to get PaymentCCInfo : {}", id);
        return paymentCCInfoRepository.findById(id)
            .map(paymentCCInfoMapper::toDto);
    }

    /**
     * Delete the paymentCCInfo by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(String id) {
        log.debug("Request to delete PaymentCCInfo : {}", id);
        paymentCCInfoRepository.deleteById(id);
    }
}
