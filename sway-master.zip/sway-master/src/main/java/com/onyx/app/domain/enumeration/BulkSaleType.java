package com.onyx.app.domain.enumeration;

/**
 * The BulkSaleType enumeration.
 */
public enum BulkSaleType {
    PERCENT, AMOUNT
}
