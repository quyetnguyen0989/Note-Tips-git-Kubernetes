package com.onyx.app.service.impl;

import com.onyx.app.service.InvoiceDetailsService;
import com.onyx.app.domain.InvoiceDetails;
import com.onyx.app.repository.InvoiceDetailsRepository;
import com.onyx.app.service.dto.InvoiceDetailsDTO;
import com.onyx.app.service.mapper.InvoiceDetailsMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.stereotype.Service;

import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
/**
 * Service Implementation for managing InvoiceDetails.
 */
@Service
public class InvoiceDetailsServiceImpl implements InvoiceDetailsService {

    private final Logger log = LoggerFactory.getLogger(InvoiceDetailsServiceImpl.class);

    private final InvoiceDetailsRepository invoiceDetailsRepository;

    private final InvoiceDetailsMapper invoiceDetailsMapper;

    public InvoiceDetailsServiceImpl(InvoiceDetailsRepository invoiceDetailsRepository, InvoiceDetailsMapper invoiceDetailsMapper) {
        this.invoiceDetailsRepository = invoiceDetailsRepository;
        this.invoiceDetailsMapper = invoiceDetailsMapper;
    }

    /**
     * Save a invoiceDetails.
     *
     * @param invoiceDetailsDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public InvoiceDetailsDTO save(InvoiceDetailsDTO invoiceDetailsDTO) {
        log.debug("Request to save InvoiceDetails : {}", invoiceDetailsDTO);
        InvoiceDetails invoiceDetails = invoiceDetailsMapper.toEntity(invoiceDetailsDTO);
        invoiceDetails = invoiceDetailsRepository.save(invoiceDetails);
        return invoiceDetailsMapper.toDto(invoiceDetails);
    }

    /**
     * Get all the invoiceDetails.
     *
     * @return the list of entities
     */
    @Override
    public List<InvoiceDetailsDTO> findAll() {
        log.debug("Request to get all InvoiceDetails");
        return invoiceDetailsRepository.findAll().stream()
            .map(invoiceDetailsMapper::toDto)
            .collect(Collectors.toCollection(LinkedList::new));
    }


    /**
     * Get one invoiceDetails by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    public Optional<InvoiceDetailsDTO> findOne(String id) {
        log.debug("Request to get InvoiceDetails : {}", id);
        return invoiceDetailsRepository.findById(id)
            .map(invoiceDetailsMapper::toDto);
    }

    /**
     * Delete the invoiceDetails by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(String id) {
        log.debug("Request to delete InvoiceDetails : {}", id);
        invoiceDetailsRepository.deleteById(id);
    }
}
