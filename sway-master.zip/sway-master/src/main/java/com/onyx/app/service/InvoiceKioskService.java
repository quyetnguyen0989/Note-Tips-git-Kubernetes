package com.onyx.app.service;

import com.onyx.app.service.dto.InvoiceKioskDTO;

import java.util.List;
import java.util.Optional;

/**
 * Service Interface for managing InvoiceKiosk.
 */
public interface InvoiceKioskService {

    /**
     * Save a invoiceKiosk.
     *
     * @param invoiceKioskDTO the entity to save
     * @return the persisted entity
     */
    InvoiceKioskDTO save(InvoiceKioskDTO invoiceKioskDTO);

    /**
     * Get all the invoiceKiosks.
     *
     * @return the list of entities
     */
    List<InvoiceKioskDTO> findAll();


    /**
     * Get the "id" invoiceKiosk.
     *
     * @param id the id of the entity
     * @return the entity
     */
    Optional<InvoiceKioskDTO> findOne(String id);

    /**
     * Delete the "id" invoiceKiosk.
     *
     * @param id the id of the entity
     */
    void delete(String id);
}
