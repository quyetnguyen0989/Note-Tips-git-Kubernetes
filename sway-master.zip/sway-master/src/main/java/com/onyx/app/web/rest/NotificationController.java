package com.onyx.app.web.rest;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.onyx.app.domain.InvoiceCheckout;
import com.onyx.app.domain.InvoiceMobile;
import com.onyx.app.domain.Notification;
import com.onyx.app.service.dto.InvoiceMobileDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.MessageDeliveryException;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import springfox.documentation.spring.web.json.Json;

@RestController
public class NotificationController {

    @Autowired
    private SimpMessagingTemplate simpMessagingTemplate;

    // Initialize Notification
    private Notification notification = new Notification(0);

    @MessageMapping("/notify")
    public ResponseEntity<InvoiceCheckout> getNotification(@RequestBody InvoiceCheckout invoiceCheckout){
        System.out.println("================================> " + invoiceCheckout);
        // Increment Notification by one
//        notification.increment();
        try {
            simpMessagingTemplate.convertAndSend("/topic" , invoiceCheckout);
        }catch (MessageDeliveryException e){
            System.out.println("============================> " + e.getMessage());
        }
        return new ResponseEntity<InvoiceCheckout>(invoiceCheckout  , HttpStatus.OK);
    }

    @MessageMapping("/notify-channel-100")
    public ResponseEntity<InvoiceCheckout> notifyChannel100(@RequestBody InvoiceCheckout invoiceCheckout){
        System.out.println("================================> " + invoiceCheckout);
        // Increment Notification by one
//        notification.increment();
        try {
            simpMessagingTemplate.convertAndSend("/channel-100" , invoiceCheckout);
        }catch (MessageDeliveryException e){
            System.out.println("============================> " + e.getMessage());
        }
        return new ResponseEntity<InvoiceCheckout>(invoiceCheckout   , HttpStatus.OK);
    }

    @MessageMapping("/notify-channel-200")
    public ResponseEntity<InvoiceCheckout> notifyChannel200(@RequestBody InvoiceCheckout invoiceCheckout){
        System.out.println("================================> " + invoiceCheckout);
        // Increment Notification by one
//        notification.increment();
        try {
            simpMessagingTemplate.convertAndSend("/channel-200" , invoiceCheckout);
        }catch (MessageDeliveryException e){
            System.out.println("============================> " + e.getMessage());
        }
        return new ResponseEntity<InvoiceCheckout>(invoiceCheckout   , HttpStatus.OK);
    }

    @MessageMapping("/notify-channel-300")
    public ResponseEntity<InvoiceCheckout> notifyChannel300(@RequestBody InvoiceCheckout invoiceCheckout){
        System.out.println("================================> " + invoiceCheckout);
        // Increment Notification by one
//        notification.increment();
        try {
            simpMessagingTemplate.convertAndSend("/channel-300" , invoiceCheckout);
        }catch (MessageDeliveryException e){
            System.out.println("============================> " + e.getMessage());
        }
        return new ResponseEntity<InvoiceCheckout>(invoiceCheckout   , HttpStatus.OK);
    }

    @MessageMapping("/notify-channel-400")
    public ResponseEntity<InvoiceCheckout> notifyChannel400(@RequestBody InvoiceCheckout invoiceCheckout){
        System.out.println("================================> " + invoiceCheckout);
        // Increment Notification by one
//        notification.increment();
        try {
            simpMessagingTemplate.convertAndSend("/channel-400" , invoiceCheckout);
        }catch (MessageDeliveryException e){
            System.out.println("============================> " + e.getMessage());
        }
        return new ResponseEntity<InvoiceCheckout>(invoiceCheckout   , HttpStatus.OK);
    }

    @MessageMapping("/notify-channel-500")
    public ResponseEntity<InvoiceCheckout> notifyChannel500(@RequestBody InvoiceCheckout invoiceCheckout){
        System.out.println("================================> " + invoiceCheckout);
        // Increment Notification by one
//        notification.increment();
        try {
            simpMessagingTemplate.convertAndSend("/channel-500" , invoiceCheckout);
        }catch (MessageDeliveryException e){
            System.out.println("============================> " + e.getMessage());
        }
        return new ResponseEntity<InvoiceCheckout>(invoiceCheckout   , HttpStatus.OK);
    }

    @MessageMapping("/notify-channel-600")
    public ResponseEntity<InvoiceCheckout> notifyChannel600(@RequestBody InvoiceCheckout invoiceCheckout){
        System.out.println("================================> " + invoiceCheckout);
        // Increment Notification by one
//        notification.increment();
        try {
            simpMessagingTemplate.convertAndSend("/channel-600" , invoiceCheckout);
        }catch (MessageDeliveryException e){
            System.out.println("============================> " + e.getMessage());
        }
        return new ResponseEntity<InvoiceCheckout>(invoiceCheckout   , HttpStatus.OK);
    }

}
