package com.onyx.app.service.dto;

import java.time.ZonedDateTime;
import java.io.Serializable;
import java.util.Objects;

/**
 * A DTO for the Payout entity.
 */
public class PayoutDTO implements Serializable {

    private String id;

    private Integer payoutId;

    private Integer storeId;

    private Integer cashierId;

    private ZonedDateTime datetime;

    private String vendorNumber;

    private Double amount;

    private Integer stationId;

    private String description;

    private String paymentMethod;

    private String type;

    private String overrideId;

    private String itemNum;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getPayoutId() {
        return payoutId;
    }

    public void setPayoutId(Integer payoutId) {
        this.payoutId = payoutId;
    }

    public Integer getStoreId() {
        return storeId;
    }

    public void setStoreId(Integer storeId) {
        this.storeId = storeId;
    }

    public Integer getCashierId() {
        return cashierId;
    }

    public void setCashierId(Integer cashierId) {
        this.cashierId = cashierId;
    }

    public ZonedDateTime getDatetime() {
        return datetime;
    }

    public void setDatetime(ZonedDateTime datetime) {
        this.datetime = datetime;
    }

    public String getVendorNumber() {
        return vendorNumber;
    }

    public void setVendorNumber(String vendorNumber) {
        this.vendorNumber = vendorNumber;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public Integer getStationId() {
        return stationId;
    }

    public void setStationId(Integer stationId) {
        this.stationId = stationId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getOverrideId() {
        return overrideId;
    }

    public void setOverrideId(String overrideId) {
        this.overrideId = overrideId;
    }

    public String getItemNum() {
        return itemNum;
    }

    public void setItemNum(String itemNum) {
        this.itemNum = itemNum;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        PayoutDTO payoutDTO = (PayoutDTO) o;
        if (payoutDTO.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), payoutDTO.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "PayoutDTO{" +
            "id=" + getId() +
            ", payoutId=" + getPayoutId() +
            ", storeId=" + getStoreId() +
            ", cashierId=" + getCashierId() +
            ", datetime='" + getDatetime() + "'" +
            ", vendorNumber='" + getVendorNumber() + "'" +
            ", amount=" + getAmount() +
            ", stationId=" + getStationId() +
            ", description='" + getDescription() + "'" +
            ", paymentMethod='" + getPaymentMethod() + "'" +
            ", type='" + getType() + "'" +
            ", overrideId='" + getOverrideId() + "'" +
            ", itemNum='" + getItemNum() + "'" +
            "}";
    }
}
