package com.onyx.app.web.rest;

import com.onyx.app.domain.InvoiceCheckout;
import com.onyx.app.repository.InvoiceCheckoutRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/invoice-checkout")
public class InvoiceCheckoutResource {

    @Autowired
    private InvoiceCheckoutRepository invoiceCheckoutRepository;


    @PostMapping
    public ResponseEntity<InvoiceCheckout> create(@RequestBody InvoiceCheckout invoiceCheckout){
        InvoiceCheckout saved = invoiceCheckoutRepository.save(invoiceCheckout);
        return new ResponseEntity<InvoiceCheckout>(saved, HttpStatus.OK);
    }

    @GetMapping
    public ResponseEntity<List<InvoiceCheckout>> getAll(){
        List<InvoiceCheckout> invoiceCheckouts = invoiceCheckoutRepository.findAll();
        return new ResponseEntity<List<InvoiceCheckout>>(invoiceCheckouts,HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<InvoiceCheckout> getById(@PathVariable String id){
        InvoiceCheckout invoiceCheckout = invoiceCheckoutRepository.findById(id).get();
        return new ResponseEntity<InvoiceCheckout>(invoiceCheckout,HttpStatus.OK);
    }

//    @GetMapping("/checkout-by-item-id/{id}")
//    public ResponseEntity<InvoiceCheckout> getByItemId(@PathVariable Integer id){
//        InvoiceCheckout invoiceCheckout = invoiceCheckoutRepository.findByInventories_Id(id);
//        return new ResponseEntity<>(invoiceCheckout, HttpStatus.OK);
//    }
//
//    @GetMapping("/checkout-by-modifier-id/{id}")
//    public ResponseEntity<InvoiceCheckout> getByModifierId(@PathVariable String id){
//        InvoiceCheckout invoiceCheckout = invoiceCheckoutRepository.findByModifiers_Id(id);
//        return new ResponseEntity<InvoiceCheckout>(invoiceCheckout, HttpStatus.OK);
//    }

    @DeleteMapping
    public void deleteAll(){
        invoiceCheckoutRepository.deleteAll();
    }

}
