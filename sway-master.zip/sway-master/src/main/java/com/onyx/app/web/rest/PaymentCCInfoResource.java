package com.onyx.app.web.rest;

import com.codahale.metrics.annotation.Timed;
import com.onyx.app.service.PaymentCCInfoService;
import com.onyx.app.web.rest.errors.BadRequestAlertException;
import com.onyx.app.web.rest.util.HeaderUtil;
import com.onyx.app.service.dto.PaymentCCInfoDTO;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.net.URISyntaxException;

import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing PaymentCCInfo.
 */
@RestController
@RequestMapping("/api")
public class PaymentCCInfoResource {

    private final Logger log = LoggerFactory.getLogger(PaymentCCInfoResource.class);

    private static final String ENTITY_NAME = "paymentCCInfo";

    private final PaymentCCInfoService paymentCCInfoService;

    public PaymentCCInfoResource(PaymentCCInfoService paymentCCInfoService) {
        this.paymentCCInfoService = paymentCCInfoService;
    }

    /**
     * POST  /payment-cc-infos : Create a new paymentCCInfo.
     *
     * @param paymentCCInfoDTO the paymentCCInfoDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new paymentCCInfoDTO, or with status 400 (Bad Request) if the paymentCCInfo has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/payment-cc-infos")
    @Timed
    public ResponseEntity<PaymentCCInfoDTO> createPaymentCCInfo(@RequestBody PaymentCCInfoDTO paymentCCInfoDTO) throws URISyntaxException {
        log.debug("REST request to save PaymentCCInfo : {}", paymentCCInfoDTO);
        if (paymentCCInfoDTO.getId() != null) {
            throw new BadRequestAlertException("A new paymentCCInfo cannot already have an ID", ENTITY_NAME, "idexists");
        }
        PaymentCCInfoDTO result = paymentCCInfoService.save(paymentCCInfoDTO);
        return ResponseEntity.created(new URI("/api/payment-cc-infos/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /payment-cc-infos : Updates an existing paymentCCInfo.
     *
     * @param paymentCCInfoDTO the paymentCCInfoDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated paymentCCInfoDTO,
     * or with status 400 (Bad Request) if the paymentCCInfoDTO is not valid,
     * or with status 500 (Internal Server Error) if the paymentCCInfoDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/payment-cc-infos")
    @Timed
    public ResponseEntity<PaymentCCInfoDTO> updatePaymentCCInfo(@RequestBody PaymentCCInfoDTO paymentCCInfoDTO) throws URISyntaxException {
        log.debug("REST request to update PaymentCCInfo : {}", paymentCCInfoDTO);
        if (paymentCCInfoDTO.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        PaymentCCInfoDTO result = paymentCCInfoService.save(paymentCCInfoDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, paymentCCInfoDTO.getId().toString()))
            .body(result);
    }

    /**
     * GET  /payment-cc-infos : get all the paymentCCInfos.
     *
     * @return the ResponseEntity with status 200 (OK) and the list of paymentCCInfos in body
     */
    @GetMapping("/payment-cc-infos")
    @Timed
    public List<PaymentCCInfoDTO> getAllPaymentCCInfos() {
        log.debug("REST request to get all PaymentCCInfos");
        return paymentCCInfoService.findAll();
    }

    /**
     * GET  /payment-cc-infos/:id : get the "id" paymentCCInfo.
     *
     * @param id the id of the paymentCCInfoDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the paymentCCInfoDTO, or with status 404 (Not Found)
     */
    @GetMapping("/payment-cc-infos/{id}")
    @Timed
    public ResponseEntity<PaymentCCInfoDTO> getPaymentCCInfo(@PathVariable String id) {
        log.debug("REST request to get PaymentCCInfo : {}", id);
        Optional<PaymentCCInfoDTO> paymentCCInfoDTO = paymentCCInfoService.findOne(id);
        return ResponseUtil.wrapOrNotFound(paymentCCInfoDTO);
    }

    /**
     * DELETE  /payment-cc-infos/:id : delete the "id" paymentCCInfo.
     *
     * @param id the id of the paymentCCInfoDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/payment-cc-infos/{id}")
    @Timed
    public ResponseEntity<Void> deletePaymentCCInfo(@PathVariable String id) {
        log.debug("REST request to delete PaymentCCInfo : {}", id);
        paymentCCInfoService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id)).build();
    }
}
