package com.onyx.app.service.dto;

import java.io.Serializable;
import java.util.Objects;

/**
 * A DTO for the PaymentCCInfo entity.
 */
public class PaymentCCInfoDTO implements Serializable {

    private String id;

    private Integer storeId;

    private Integer stationId;

    private Boolean paymentMethod;

    private String primaryIP;

    private String processingCompany;

    private String filePath;

    private String userFriendlyName;

    private String timeOut;

    private Boolean requireCvv2;

    private Boolean checkNumberVerification;

    private Boolean checkDriversLicenceVerification;

    private Boolean checkLast4Digits;

    private Integer posId;

    private String captureType;

    private String settlementTime;

    private Boolean active;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getStoreId() {
        return storeId;
    }

    public void setStoreId(Integer storeId) {
        this.storeId = storeId;
    }

    public Integer getStationId() {
        return stationId;
    }

    public void setStationId(Integer stationId) {
        this.stationId = stationId;
    }

    public Boolean isPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(Boolean paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public String getPrimaryIP() {
        return primaryIP;
    }

    public void setPrimaryIP(String primaryIP) {
        this.primaryIP = primaryIP;
    }

    public String getProcessingCompany() {
        return processingCompany;
    }

    public void setProcessingCompany(String processingCompany) {
        this.processingCompany = processingCompany;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public String getUserFriendlyName() {
        return userFriendlyName;
    }

    public void setUserFriendlyName(String userFriendlyName) {
        this.userFriendlyName = userFriendlyName;
    }

    public String getTimeOut() {
        return timeOut;
    }

    public void setTimeOut(String timeOut) {
        this.timeOut = timeOut;
    }

    public Boolean isRequireCvv2() {
        return requireCvv2;
    }

    public void setRequireCvv2(Boolean requireCvv2) {
        this.requireCvv2 = requireCvv2;
    }

    public Boolean isCheckNumberVerification() {
        return checkNumberVerification;
    }

    public void setCheckNumberVerification(Boolean checkNumberVerification) {
        this.checkNumberVerification = checkNumberVerification;
    }

    public Boolean isCheckDriversLicenceVerification() {
        return checkDriversLicenceVerification;
    }

    public void setCheckDriversLicenceVerification(Boolean checkDriversLicenceVerification) {
        this.checkDriversLicenceVerification = checkDriversLicenceVerification;
    }

    public Boolean isCheckLast4Digits() {
        return checkLast4Digits;
    }

    public void setCheckLast4Digits(Boolean checkLast4Digits) {
        this.checkLast4Digits = checkLast4Digits;
    }

    public Integer getPosId() {
        return posId;
    }

    public void setPosId(Integer posId) {
        this.posId = posId;
    }

    public String getCaptureType() {
        return captureType;
    }

    public void setCaptureType(String captureType) {
        this.captureType = captureType;
    }

    public String getSettlementTime() {
        return settlementTime;
    }

    public void setSettlementTime(String settlementTime) {
        this.settlementTime = settlementTime;
    }

    public Boolean isActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        PaymentCCInfoDTO paymentCCInfoDTO = (PaymentCCInfoDTO) o;
        if (paymentCCInfoDTO.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), paymentCCInfoDTO.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "PaymentCCInfoDTO{" +
            "id=" + getId() +
            ", storeId=" + getStoreId() +
            ", stationId=" + getStationId() +
            ", paymentMethod='" + isPaymentMethod() + "'" +
            ", primaryIP='" + getPrimaryIP() + "'" +
            ", processingCompany='" + getProcessingCompany() + "'" +
            ", filePath='" + getFilePath() + "'" +
            ", userFriendlyName='" + getUserFriendlyName() + "'" +
            ", timeOut='" + getTimeOut() + "'" +
            ", requireCvv2='" + isRequireCvv2() + "'" +
            ", checkNumberVerification='" + isCheckNumberVerification() + "'" +
            ", checkDriversLicenceVerification='" + isCheckDriversLicenceVerification() + "'" +
            ", checkLast4Digits='" + isCheckLast4Digits() + "'" +
            ", posId=" + getPosId() +
            ", captureType='" + getCaptureType() + "'" +
            ", settlementTime='" + getSettlementTime() + "'" +
            ", active='" + isActive() + "'" +
            "}";
    }
}
