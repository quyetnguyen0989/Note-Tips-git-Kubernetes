package com.onyx.app.service;

import com.onyx.app.service.dto.InventoryExpDTO;

import java.util.List;
import java.util.Optional;

/**
 * Service Interface for managing InventoryExp.
 */
public interface InventoryExpService {

    /**
     * Save a inventoryExp.
     *
     * @param inventoryExpDTO the entity to save
     * @return the persisted entity
     */
    InventoryExpDTO save(InventoryExpDTO inventoryExpDTO);

    /**
     * Get all the inventoryExps.
     *
     * @return the list of entities
     */
    List<InventoryExpDTO> findAll();


    /**
     * Get the "id" inventoryExp.
     *
     * @param id the id of the entity
     * @return the entity
     */
    Optional<InventoryExpDTO> findOne(String id);

    /**
     * Delete the "id" inventoryExp.
     *
     * @param id the id of the entity
     */
    void delete(String id);
}
