package com.onyx.app.service.dto;

import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.Objects;

/**
 * A DTO for the CustomerInfo entity.
 */
public class CustomerInfoDTO implements Serializable {

    private String id;

    private Integer storeId;

    private Integer custNum;

    @Size(max = 20)
    private String firstName;

    @Size(max = 20)
    private String lastName;

    @Size(max = 30)
    private String address1;

    @Size(max = 30)
    private String address2;

    @Size(max = 20)
    private String city;

    @Size(max = 10)
    private String state;

    private Integer zipCode;

    private Integer phone1;

    private Integer mobileNum;

    private Integer discountLevel;

    private Integer discountPercent;

    private String acctOpenDate;

    private Integer acctBalance;

    private Integer acctMaxBalance;

    private String rewardPlan;

    private Integer rewardPoints;

    private String onlineUserName;

    private String birthday;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getStoreId() {
        return storeId;
    }

    public void setStoreId(Integer storeId) {
        this.storeId = storeId;
    }

    public Integer getCustNum() {
        return custNum;
    }

    public void setCustNum(Integer custNum) {
        this.custNum = custNum;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getAddress1() {
        return address1;
    }

    public void setAddress1(String address1) {
        this.address1 = address1;
    }

    public String getAddress2() {
        return address2;
    }

    public void setAddress2(String address2) {
        this.address2 = address2;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public Integer getZipCode() {
        return zipCode;
    }

    public void setZipCode(Integer zipCode) {
        this.zipCode = zipCode;
    }

    public Integer getPhone1() {
        return phone1;
    }

    public void setPhone1(Integer phone1) {
        this.phone1 = phone1;
    }

    public Integer getMobileNum() {
        return mobileNum;
    }

    public void setMobileNum(Integer mobileNum) {
        this.mobileNum = mobileNum;
    }

    public Integer getDiscountLevel() {
        return discountLevel;
    }

    public void setDiscountLevel(Integer discountLevel) {
        this.discountLevel = discountLevel;
    }

    public Integer getDiscountPercent() {
        return discountPercent;
    }

    public void setDiscountPercent(Integer discountPercent) {
        this.discountPercent = discountPercent;
    }

    public String getAcctOpenDate() {
        return acctOpenDate;
    }

    public void setAcctOpenDate(String acctOpenDate) {
        this.acctOpenDate = acctOpenDate;
    }

    public Integer getAcctBalance() {
        return acctBalance;
    }

    public void setAcctBalance(Integer acctBalance) {
        this.acctBalance = acctBalance;
    }

    public Integer getAcctMaxBalance() {
        return acctMaxBalance;
    }

    public void setAcctMaxBalance(Integer acctMaxBalance) {
        this.acctMaxBalance = acctMaxBalance;
    }

    public String getRewardPlan() {
        return rewardPlan;
    }

    public void setRewardPlan(String rewardPlan) {
        this.rewardPlan = rewardPlan;
    }

    public Integer getRewardPoints() {
        return rewardPoints;
    }

    public void setRewardPoints(Integer rewardPoints) {
        this.rewardPoints = rewardPoints;
    }

    public String getOnlineUserName() {
        return onlineUserName;
    }

    public void setOnlineUserName(String onlineUserName) {
        this.onlineUserName = onlineUserName;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        CustomerInfoDTO customerInfoDTO = (CustomerInfoDTO) o;
        if (customerInfoDTO.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), customerInfoDTO.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "CustomerInfoDTO{" +
            "id=" + getId() +
            ", storeId=" + getStoreId() +
            ", custNum=" + getCustNum() +
            ", firstName='" + getFirstName() + "'" +
            ", lastName='" + getLastName() + "'" +
            ", address1='" + getAddress1() + "'" +
            ", address2='" + getAddress2() + "'" +
            ", city='" + getCity() + "'" +
            ", state='" + getState() + "'" +
            ", zipCode=" + getZipCode() +
            ", phone1=" + getPhone1() +
            ", mobileNum=" + getMobileNum() +
            ", discountLevel=" + getDiscountLevel() +
            ", discountPercent=" + getDiscountPercent() +
            ", acctOpenDate='" + getAcctOpenDate() + "'" +
            ", acctBalance=" + getAcctBalance() +
            ", acctMaxBalance=" + getAcctMaxBalance() +
            ", rewardPlan='" + getRewardPlan() + "'" +
            ", rewardPoints=" + getRewardPoints() +
            ", onlineUserName='" + getOnlineUserName() + "'" +
            ", birthday='" + getBirthday() + "'" +
            "}";
    }
}
