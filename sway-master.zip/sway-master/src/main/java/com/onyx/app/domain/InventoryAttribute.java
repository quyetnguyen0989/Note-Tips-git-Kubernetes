package com.onyx.app.domain;

import org.springframework.data.annotation.Id;
import com.couchbase.client.java.repository.annotation.Field;
import org.springframework.data.couchbase.core.mapping.Document;
import org.springframework.data.couchbase.core.mapping.id.GeneratedValue;
import org.springframework.data.couchbase.core.mapping.id.IdPrefix;
import javax.validation.constraints.*;

import java.io.Serializable;
import java.util.Objects;

import static com.onyx.app.config.Constants.ID_DELIMITER;
import static org.springframework.data.couchbase.core.mapping.id.GenerationStrategy.UNIQUE;

/**
 * A InventoryAttribute.
 */
@Document
public class InventoryAttribute implements Serializable {

    private static final long serialVersionUID = 1L;
    public static final String PREFIX = "inventoryattribute";

    @SuppressWarnings("unused")
    @IdPrefix
    private String prefix = PREFIX;

    @Id
    @GeneratedValue(strategy = UNIQUE, delimiter = ID_DELIMITER)
    private String id;

    @Size(max = 50)
    @Field("item_name")
    private String itemName;

    @Size(max = 25)
    @Field("item_num")
    private String itemNum;

    @Field("item_size")
    private Integer itemSize;

    @NotNull
    @Field("store_id")
    private Integer storeId;

    @Field("item_att_price")
    private Double itemAttPrice;

    @Field("item_att_num")
    private Integer itemAttNum;

    @Field("active")
    private Boolean active;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getItemName() {
        return itemName;
    }

    public InventoryAttribute itemName(String itemName) {
        this.itemName = itemName;
        return this;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public String getItemNum() {
        return itemNum;
    }

    public InventoryAttribute itemNum(String itemNum) {
        this.itemNum = itemNum;
        return this;
    }

    public void setItemNum(String itemNum) {
        this.itemNum = itemNum;
    }

    public Integer getItemSize() {
        return itemSize;
    }

    public InventoryAttribute itemSize(Integer itemSize) {
        this.itemSize = itemSize;
        return this;
    }

    public void setItemSize(Integer itemSize) {
        this.itemSize = itemSize;
    }

    public Integer getStoreId() {
        return storeId;
    }

    public InventoryAttribute storeId(Integer storeId) {
        this.storeId = storeId;
        return this;
    }

    public void setStoreId(Integer storeId) {
        this.storeId = storeId;
    }

    public Double getItemAttPrice() {
        return itemAttPrice;
    }

    public InventoryAttribute itemAttPrice(Double itemAttPrice) {
        this.itemAttPrice = itemAttPrice;
        return this;
    }

    public void setItemAttPrice(Double itemAttPrice) {
        this.itemAttPrice = itemAttPrice;
    }

    public Integer getItemAttNum() {
        return itemAttNum;
    }

    public InventoryAttribute itemAttNum(Integer itemAttNum) {
        this.itemAttNum = itemAttNum;
        return this;
    }

    public void setItemAttNum(Integer itemAttNum) {
        this.itemAttNum = itemAttNum;
    }

    public Boolean isActive() {
        return active;
    }

    public InventoryAttribute active(Boolean active) {
        this.active = active;
        return this;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        InventoryAttribute inventoryAttribute = (InventoryAttribute) o;
        if (inventoryAttribute.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), inventoryAttribute.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "InventoryAttribute{" +
            "id=" + getId() +
            ", itemName='" + getItemName() + "'" +
            ", itemNum='" + getItemNum() + "'" +
            ", itemSize=" + getItemSize() +
            ", storeId=" + getStoreId() +
            ", itemAttPrice=" + getItemAttPrice() +
            ", itemAttNum=" + getItemAttNum() +
            ", active='" + isActive() + "'" +
            "}";
    }
}
