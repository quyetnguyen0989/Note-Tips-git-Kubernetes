package com.onyx.app.web.rest;

import com.codahale.metrics.annotation.Timed;
import com.onyx.app.service.InventoryMixAndMatchService;
import com.onyx.app.web.rest.errors.BadRequestAlertException;
import com.onyx.app.web.rest.util.HeaderUtil;
import com.onyx.app.service.dto.InventoryMixAndMatchDTO;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;

import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing InventoryMixAndMatch.
 */
@RestController
@RequestMapping("/api")
public class InventoryMixAndMatchResource {

    private final Logger log = LoggerFactory.getLogger(InventoryMixAndMatchResource.class);

    private static final String ENTITY_NAME = "inventoryMixAndMatch";

    private final InventoryMixAndMatchService inventoryMixAndMatchService;

    public InventoryMixAndMatchResource(InventoryMixAndMatchService inventoryMixAndMatchService) {
        this.inventoryMixAndMatchService = inventoryMixAndMatchService;
    }

    /**
     * POST  /inventory-mix-and-matches : Create a new inventoryMixAndMatch.
     *
     * @param inventoryMixAndMatchDTO the inventoryMixAndMatchDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new inventoryMixAndMatchDTO, or with status 400 (Bad Request) if the inventoryMixAndMatch has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/inventory-mix-and-matches")
    @Timed
    public ResponseEntity<InventoryMixAndMatchDTO> createInventoryMixAndMatch(@Valid @RequestBody InventoryMixAndMatchDTO inventoryMixAndMatchDTO) throws URISyntaxException {
        log.debug("REST request to save InventoryMixAndMatch : {}", inventoryMixAndMatchDTO);
        if (inventoryMixAndMatchDTO.getId() != null) {
            throw new BadRequestAlertException("A new inventoryMixAndMatch cannot already have an ID", ENTITY_NAME, "idexists");
        }
        InventoryMixAndMatchDTO result = inventoryMixAndMatchService.save(inventoryMixAndMatchDTO);
        return ResponseEntity.created(new URI("/api/inventory-mix-and-matches/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /inventory-mix-and-matches : Updates an existing inventoryMixAndMatch.
     *
     * @param inventoryMixAndMatchDTO the inventoryMixAndMatchDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated inventoryMixAndMatchDTO,
     * or with status 400 (Bad Request) if the inventoryMixAndMatchDTO is not valid,
     * or with status 500 (Internal Server Error) if the inventoryMixAndMatchDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/inventory-mix-and-matches")
    @Timed
    public ResponseEntity<InventoryMixAndMatchDTO> updateInventoryMixAndMatch(@Valid @RequestBody InventoryMixAndMatchDTO inventoryMixAndMatchDTO) throws URISyntaxException {
        log.debug("REST request to update InventoryMixAndMatch : {}", inventoryMixAndMatchDTO);
        if (inventoryMixAndMatchDTO.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        InventoryMixAndMatchDTO result = inventoryMixAndMatchService.save(inventoryMixAndMatchDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, inventoryMixAndMatchDTO.getId().toString()))
            .body(result);
    }

    /**
     * GET  /inventory-mix-and-matches : get all the inventoryMixAndMatches.
     *
     * @return the ResponseEntity with status 200 (OK) and the list of inventoryMixAndMatches in body
     */
    @GetMapping("/inventory-mix-and-matches")
    @Timed
    public List<InventoryMixAndMatchDTO> getAllInventoryMixAndMatches() {
        log.debug("REST request to get all InventoryMixAndMatches");
        return inventoryMixAndMatchService.findAll();
    }

    /**
     * GET  /inventory-mix-and-matches/:id : get the "id" inventoryMixAndMatch.
     *
     * @param id the id of the inventoryMixAndMatchDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the inventoryMixAndMatchDTO, or with status 404 (Not Found)
     */
    @GetMapping("/inventory-mix-and-matches/{id}")
    @Timed
    public ResponseEntity<InventoryMixAndMatchDTO> getInventoryMixAndMatch(@PathVariable String id) {
        log.debug("REST request to get InventoryMixAndMatch : {}", id);
        Optional<InventoryMixAndMatchDTO> inventoryMixAndMatchDTO = inventoryMixAndMatchService.findOne(id);
        return ResponseUtil.wrapOrNotFound(inventoryMixAndMatchDTO);
    }

    /**
     * DELETE  /inventory-mix-and-matches/:id : delete the "id" inventoryMixAndMatch.
     *
     * @param id the id of the inventoryMixAndMatchDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/inventory-mix-and-matches/{id}")
    @Timed
    public ResponseEntity<Void> deleteInventoryMixAndMatch(@PathVariable String id) {
        log.debug("REST request to delete InventoryMixAndMatch : {}", id);
        inventoryMixAndMatchService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id)).build();
    }
}
