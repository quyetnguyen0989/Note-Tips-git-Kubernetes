package com.onyx.app.domain;

import org.springframework.data.annotation.Id;
import com.couchbase.client.java.repository.annotation.Field;
import org.springframework.data.couchbase.core.mapping.Document;
import org.springframework.data.couchbase.core.mapping.id.GeneratedValue;
import org.springframework.data.couchbase.core.mapping.id.IdPrefix;

import java.io.Serializable;
import java.time.ZonedDateTime;
import java.util.Objects;

import static com.onyx.app.config.Constants.ID_DELIMITER;
import static org.springframework.data.couchbase.core.mapping.id.GenerationStrategy.UNIQUE;

/**
 * A Ctrx.
 */
@Document
public class Ctrx implements Serializable {

    private static final long serialVersionUID = 1L;
    public static final String PREFIX = "ctrx";

    @SuppressWarnings("unused")
    @IdPrefix
    private String prefix = PREFIX;

    @Id
    @GeneratedValue(strategy = UNIQUE, delimiter = ID_DELIMITER)
    private String id;

    @Field("store_id")
    private Integer storeId;

    @Field("date_time")
    private ZonedDateTime dateTime;

    @Field("trx_type")
    private String trxType;

    @Field("amount")
    private Double amount;

    @Field("approval")
    private String approval;

    @Field("reference")
    private String reference;

    @Field("inv_num")
    private Integer invNum;

    @Field("tip_amount")
    private Double tipAmount;

    @Field("card_type")
    private String cardType;

    @Field("tip_applied")
    private Double tipApplied;

    @Field("trout_d")
    private String troutD;

    @Field("post_auth_reference_number")
    private String postAuthReferenceNumber;

    @Field("order_id")
    private Integer orderId;

    @Field("language")
    private String language;

    @Field("card_number")
    private Integer cardNumber;

    @Field("payment_method")
    private String paymentMethod;

    @Field("cash_back")
    private Double cashBack;

    @Field("terminal_number")
    private Integer terminalNumber;

    @Field("a_ci")
    private String aCI;

    @Field("card_entry_source")
    private String cardEntrySource;

    @Field("trace_number")
    private String traceNumber;

    @Field("sequence_number")
    private Integer sequenceNumber;

    @Field("is_pre_paid_card")
    private String isPrePaidCard;

    @Field("pre_auth_amount")
    private Double preAuthAmount;

    @Field("app_label")
    private String appLabel;

    @Field("app_preferred_name")
    private String appPreferredName;

    @Field("card_plan")
    private String cardPlan;

    @Field("emv_aid")
    private String emvAid;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getStoreId() {
        return storeId;
    }

    public Ctrx storeId(Integer storeId) {
        this.storeId = storeId;
        return this;
    }

    public void setStoreId(Integer storeId) {
        this.storeId = storeId;
    }

    public ZonedDateTime getDateTime() {
        return dateTime;
    }

    public Ctrx dateTime(ZonedDateTime dateTime) {
        this.dateTime = dateTime;
        return this;
    }

    public void setDateTime(ZonedDateTime dateTime) {
        this.dateTime = dateTime;
    }

    public String getTrxType() {
        return trxType;
    }

    public Ctrx trxType(String trxType) {
        this.trxType = trxType;
        return this;
    }

    public void setTrxType(String trxType) {
        this.trxType = trxType;
    }

    public Double getAmount() {
        return amount;
    }

    public Ctrx amount(Double amount) {
        this.amount = amount;
        return this;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public String getApproval() {
        return approval;
    }

    public Ctrx approval(String approval) {
        this.approval = approval;
        return this;
    }

    public void setApproval(String approval) {
        this.approval = approval;
    }

    public String getReference() {
        return reference;
    }

    public Ctrx reference(String reference) {
        this.reference = reference;
        return this;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    public Integer getInvNum() {
        return invNum;
    }

    public Ctrx invNum(Integer invNum) {
        this.invNum = invNum;
        return this;
    }

    public void setInvNum(Integer invNum) {
        this.invNum = invNum;
    }

    public Double getTipAmount() {
        return tipAmount;
    }

    public Ctrx tipAmount(Double tipAmount) {
        this.tipAmount = tipAmount;
        return this;
    }

    public void setTipAmount(Double tipAmount) {
        this.tipAmount = tipAmount;
    }

    public String getCardType() {
        return cardType;
    }

    public Ctrx cardType(String cardType) {
        this.cardType = cardType;
        return this;
    }

    public void setCardType(String cardType) {
        this.cardType = cardType;
    }

    public Double getTipApplied() {
        return tipApplied;
    }

    public Ctrx tipApplied(Double tipApplied) {
        this.tipApplied = tipApplied;
        return this;
    }

    public void setTipApplied(Double tipApplied) {
        this.tipApplied = tipApplied;
    }

    public String getTroutD() {
        return troutD;
    }

    public Ctrx troutD(String troutD) {
        this.troutD = troutD;
        return this;
    }

    public void setTroutD(String troutD) {
        this.troutD = troutD;
    }

    public String getPostAuthReferenceNumber() {
        return postAuthReferenceNumber;
    }

    public Ctrx postAuthReferenceNumber(String postAuthReferenceNumber) {
        this.postAuthReferenceNumber = postAuthReferenceNumber;
        return this;
    }

    public void setPostAuthReferenceNumber(String postAuthReferenceNumber) {
        this.postAuthReferenceNumber = postAuthReferenceNumber;
    }

    public Integer getOrderId() {
        return orderId;
    }

    public Ctrx orderId(Integer orderId) {
        this.orderId = orderId;
        return this;
    }

    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }

    public String getLanguage() {
        return language;
    }

    public Ctrx language(String language) {
        this.language = language;
        return this;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public Integer getCardNumber() {
        return cardNumber;
    }

    public Ctrx cardNumber(Integer cardNumber) {
        this.cardNumber = cardNumber;
        return this;
    }

    public void setCardNumber(Integer cardNumber) {
        this.cardNumber = cardNumber;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public Ctrx paymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
        return this;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public Double getCashBack() {
        return cashBack;
    }

    public Ctrx cashBack(Double cashBack) {
        this.cashBack = cashBack;
        return this;
    }

    public void setCashBack(Double cashBack) {
        this.cashBack = cashBack;
    }

    public Integer getTerminalNumber() {
        return terminalNumber;
    }

    public Ctrx terminalNumber(Integer terminalNumber) {
        this.terminalNumber = terminalNumber;
        return this;
    }

    public void setTerminalNumber(Integer terminalNumber) {
        this.terminalNumber = terminalNumber;
    }

    public String getaCI() {
        return aCI;
    }

    public Ctrx aCI(String aCI) {
        this.aCI = aCI;
        return this;
    }

    public void setaCI(String aCI) {
        this.aCI = aCI;
    }

    public String getCardEntrySource() {
        return cardEntrySource;
    }

    public Ctrx cardEntrySource(String cardEntrySource) {
        this.cardEntrySource = cardEntrySource;
        return this;
    }

    public void setCardEntrySource(String cardEntrySource) {
        this.cardEntrySource = cardEntrySource;
    }

    public String getTraceNumber() {
        return traceNumber;
    }

    public Ctrx traceNumber(String traceNumber) {
        this.traceNumber = traceNumber;
        return this;
    }

    public void setTraceNumber(String traceNumber) {
        this.traceNumber = traceNumber;
    }

    public Integer getSequenceNumber() {
        return sequenceNumber;
    }

    public Ctrx sequenceNumber(Integer sequenceNumber) {
        this.sequenceNumber = sequenceNumber;
        return this;
    }

    public void setSequenceNumber(Integer sequenceNumber) {
        this.sequenceNumber = sequenceNumber;
    }

    public String getIsPrePaidCard() {
        return isPrePaidCard;
    }

    public Ctrx isPrePaidCard(String isPrePaidCard) {
        this.isPrePaidCard = isPrePaidCard;
        return this;
    }

    public void setIsPrePaidCard(String isPrePaidCard) {
        this.isPrePaidCard = isPrePaidCard;
    }

    public Double getPreAuthAmount() {
        return preAuthAmount;
    }

    public Ctrx preAuthAmount(Double preAuthAmount) {
        this.preAuthAmount = preAuthAmount;
        return this;
    }

    public void setPreAuthAmount(Double preAuthAmount) {
        this.preAuthAmount = preAuthAmount;
    }

    public String getAppLabel() {
        return appLabel;
    }

    public Ctrx appLabel(String appLabel) {
        this.appLabel = appLabel;
        return this;
    }

    public void setAppLabel(String appLabel) {
        this.appLabel = appLabel;
    }

    public String getAppPreferredName() {
        return appPreferredName;
    }

    public Ctrx appPreferredName(String appPreferredName) {
        this.appPreferredName = appPreferredName;
        return this;
    }

    public void setAppPreferredName(String appPreferredName) {
        this.appPreferredName = appPreferredName;
    }

    public String getCardPlan() {
        return cardPlan;
    }

    public Ctrx cardPlan(String cardPlan) {
        this.cardPlan = cardPlan;
        return this;
    }

    public void setCardPlan(String cardPlan) {
        this.cardPlan = cardPlan;
    }

    public String getEmvAid() {
        return emvAid;
    }

    public Ctrx emvAid(String emvAid) {
        this.emvAid = emvAid;
        return this;
    }

    public void setEmvAid(String emvAid) {
        this.emvAid = emvAid;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Ctrx ctrx = (Ctrx) o;
        if (ctrx.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), ctrx.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "Ctrx{" +
            "id=" + getId() +
            ", storeId=" + getStoreId() +
            ", dateTime='" + getDateTime() + "'" +
            ", trxType='" + getTrxType() + "'" +
            ", amount=" + getAmount() +
            ", approval='" + getApproval() + "'" +
            ", reference='" + getReference() + "'" +
            ", invNum=" + getInvNum() +
            ", tipAmount=" + getTipAmount() +
            ", cardType='" + getCardType() + "'" +
            ", tipApplied=" + getTipApplied() +
            ", troutD='" + getTroutD() + "'" +
            ", postAuthReferenceNumber='" + getPostAuthReferenceNumber() + "'" +
            ", orderId=" + getOrderId() +
            ", language='" + getLanguage() + "'" +
            ", cardNumber=" + getCardNumber() +
            ", paymentMethod='" + getPaymentMethod() + "'" +
            ", cashBack=" + getCashBack() +
            ", terminalNumber=" + getTerminalNumber() +
            ", aCI='" + getaCI() + "'" +
            ", cardEntrySource='" + getCardEntrySource() + "'" +
            ", traceNumber='" + getTraceNumber() + "'" +
            ", sequenceNumber=" + getSequenceNumber() +
            ", isPrePaidCard='" + getIsPrePaidCard() + "'" +
            ", preAuthAmount=" + getPreAuthAmount() +
            ", appLabel='" + getAppLabel() + "'" +
            ", appPreferredName='" + getAppPreferredName() + "'" +
            ", cardPlan='" + getCardPlan() + "'" +
            ", emvAid='" + getEmvAid() + "'" +
            "}";
    }
}
