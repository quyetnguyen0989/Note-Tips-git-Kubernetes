package com.onyx.app.service.impl;

import com.onyx.app.service.SubFamilyService;
import com.onyx.app.domain.SubFamily;
import com.onyx.app.repository.SubFamilyRepository;
import com.onyx.app.service.dto.SubFamilyDTO;
import com.onyx.app.service.mapper.SubFamilyMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.stereotype.Service;

import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
/**
 * Service Implementation for managing SubFamily.
 */
@Service
public class SubFamilyServiceImpl implements SubFamilyService {

    private final Logger log = LoggerFactory.getLogger(SubFamilyServiceImpl.class);

    private final SubFamilyRepository subFamilyRepository;

    private final SubFamilyMapper subFamilyMapper;

    public SubFamilyServiceImpl(SubFamilyRepository subFamilyRepository, SubFamilyMapper subFamilyMapper) {
        this.subFamilyRepository = subFamilyRepository;
        this.subFamilyMapper = subFamilyMapper;
    }

    /**
     * Save a subFamily.
     *
     * @param subFamilyDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public SubFamilyDTO save(SubFamilyDTO subFamilyDTO) {
        log.debug("Request to save SubFamily : {}", subFamilyDTO);
        SubFamily subFamily = subFamilyMapper.toEntity(subFamilyDTO);
        subFamily = subFamilyRepository.save(subFamily);
        return subFamilyMapper.toDto(subFamily);
    }

    /**
     * Get all the subFamilies.
     *
     * @return the list of entities
     */
    @Override
    public List<SubFamilyDTO> findAll() {
        log.debug("Request to get all SubFamilies");
        return subFamilyRepository.findAll().stream()
            .map(subFamilyMapper::toDto)
            .collect(Collectors.toCollection(LinkedList::new));
    }


    /**
     * Get one subFamily by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    public Optional<SubFamilyDTO> findOne(String id) {
        log.debug("Request to get SubFamily : {}", id);
        return subFamilyRepository.findById(id)
            .map(subFamilyMapper::toDto);
    }

    /**
     * Delete the subFamily by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(String id) {
        log.debug("Request to delete SubFamily : {}", id);
        subFamilyRepository.deleteById(id);
    }
}
