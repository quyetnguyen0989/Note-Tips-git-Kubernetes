package com.onyx.app.repository;

import com.onyx.app.domain.Groups;
import org.springframework.stereotype.Repository;

/**
 * Spring Data Couchbase repository for the Groups entity.
 */
@SuppressWarnings("unused")
@Repository
public interface GroupsRepository extends N1qlCouchbaseRepository<Groups, String> {

}
