package com.onyx.app.service.mapper;

import com.onyx.app.domain.*;
import com.onyx.app.service.dto.SizeListDTO;

import org.mapstruct.*;

/**
 * Mapper for the entity SizeList and its DTO SizeListDTO.
 */
@Mapper(componentModel = "spring", uses = {})
public interface SizeListMapper extends EntityMapper<SizeListDTO, SizeList> {


}
