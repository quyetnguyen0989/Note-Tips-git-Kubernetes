package com.onyx.app.domain;

import afu.org.checkerframework.checker.units.qual.Time;
import com.couchbase.client.java.repository.annotation.Field;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.onyx.app.domain.enumeration.DayName;
import org.springframework.data.annotation.Id;
import org.springframework.data.couchbase.core.mapping.Document;
import org.springframework.data.couchbase.core.mapping.id.GeneratedValue;
import org.springframework.data.couchbase.core.mapping.id.IdPrefix;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.io.Serializable;
import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalTime;

import static com.onyx.app.config.Constants.ID_DELIMITER;
import static org.springframework.data.couchbase.core.mapping.id.GenerationStrategy.UNIQUE;

@Document
public class StoreTime implements Serializable {


    private static final long serialVersionUID = 6801956805764752496L;
    public static final String PREFIX = "storetime";

    @SuppressWarnings("unused")
    @IdPrefix
    private String prefix = PREFIX;

    @Id
    @GeneratedValue(strategy = UNIQUE, delimiter = ID_DELIMITER)
    private String id;

    @NotNull
    @Field("store_id")
    private Integer storeId;

    @NotNull
    @Field("day")
    private DayName day;

    @NotNull
    @Field("from")
    private Instant from;

    @NotNull
    @Field("to")
    private Instant to;

    public StoreTime() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getStoreId() {
        return storeId;
    }

    public void setStoreId(Integer storeId) {
        this.storeId = storeId;
    }

    public DayName getDay() {
        return day;
    }

    public void setDay(DayName day) {
        this.day = day;
    }

    public Instant getFrom() {
        return from;
    }

    public void setFrom(Instant from) {
        this.from = from;
    }

    public Instant getTo() {
        return to;
    }

    public void setTo(Instant to) {
        this.to = to;
    }

    @Override
    public String toString() {
        return "StoreTime{" +
            "id='" + id + '\'' +
            ", storeId=" + storeId +
            ", day=" + day +
            ", from=" + from +
            ", to=" + to +
            '}';
    }
}
