package com.onyx.app.domain.enumeration;

/**
 * The KitchenPort enumeration.
 */
public enum KitchenPort {
    COM, USB, TCP_IP
}
