package com.onyx.app.service;

import com.onyx.app.service.dto.GroupsDTO;

import java.util.List;
import java.util.Optional;

/**
 * Service Interface for managing Groups.
 */
public interface GroupsService {

    /**
     * Save a groups.
     *
     * @param groupsDTO the entity to save
     * @return the persisted entity
     */
    GroupsDTO save(GroupsDTO groupsDTO);

    /**
     * Get all the groups.
     *
     * @return the list of entities
     */
    List<GroupsDTO> findAll();


    /**
     * Get the "id" groups.
     *
     * @param id the id of the entity
     * @return the entity
     */
    Optional<GroupsDTO> findOne(String id);

    /**
     * Delete the "id" groups.
     *
     * @param id the id of the entity
     */
    void delete(String id);
}
