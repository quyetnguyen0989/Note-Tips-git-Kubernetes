package com.onyx.app.web.rest;

import com.codahale.metrics.annotation.Timed;
import com.onyx.app.service.SizeListService;
import com.onyx.app.web.rest.errors.BadRequestAlertException;
import com.onyx.app.web.rest.util.HeaderUtil;
import com.onyx.app.service.dto.SizeListDTO;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.net.URISyntaxException;

import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing SizeList.
 */
@RestController
@RequestMapping("/api")
public class SizeListResource {

    private final Logger log = LoggerFactory.getLogger(SizeListResource.class);

    private static final String ENTITY_NAME = "sizeList";

    private final SizeListService sizeListService;

    public SizeListResource(SizeListService sizeListService) {
        this.sizeListService = sizeListService;
    }

    /**
     * POST  /size-lists : Create a new sizeList.
     *
     * @param sizeListDTO the sizeListDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new sizeListDTO, or with status 400 (Bad Request) if the sizeList has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/size-lists")
    @Timed
    public ResponseEntity<SizeListDTO> createSizeList(@RequestBody SizeListDTO sizeListDTO) throws URISyntaxException {
        log.debug("REST request to save SizeList : {}", sizeListDTO);
        if (sizeListDTO.getId() != null) {
            throw new BadRequestAlertException("A new sizeList cannot already have an ID", ENTITY_NAME, "idexists");
        }
        SizeListDTO result = sizeListService.save(sizeListDTO);
        return ResponseEntity.created(new URI("/api/size-lists/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /size-lists : Updates an existing sizeList.
     *
     * @param sizeListDTO the sizeListDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated sizeListDTO,
     * or with status 400 (Bad Request) if the sizeListDTO is not valid,
     * or with status 500 (Internal Server Error) if the sizeListDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/size-lists")
    @Timed
    public ResponseEntity<SizeListDTO> updateSizeList(@RequestBody SizeListDTO sizeListDTO) throws URISyntaxException {
        log.debug("REST request to update SizeList : {}", sizeListDTO);
        if (sizeListDTO.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        SizeListDTO result = sizeListService.save(sizeListDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, sizeListDTO.getId().toString()))
            .body(result);
    }

    /**
     * GET  /size-lists : get all the sizeLists.
     *
     * @return the ResponseEntity with status 200 (OK) and the list of sizeLists in body
     */
    @GetMapping("/size-lists")
    @Timed
    public List<SizeListDTO> getAllSizeLists() {
        log.debug("REST request to get all SizeLists");
        return sizeListService.findAll();
    }

    /**
     * GET  /size-lists/:id : get the "id" sizeList.
     *
     * @param id the id of the sizeListDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the sizeListDTO, or with status 404 (Not Found)
     */
    @GetMapping("/size-lists/{id}")
    @Timed
    public ResponseEntity<SizeListDTO> getSizeList(@PathVariable String id) {
        log.debug("REST request to get SizeList : {}", id);
        Optional<SizeListDTO> sizeListDTO = sizeListService.findOne(id);
        return ResponseUtil.wrapOrNotFound(sizeListDTO);
    }

    /**
     * DELETE  /size-lists/:id : delete the "id" sizeList.
     *
     * @param id the id of the sizeListDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/size-lists/{id}")
    @Timed
    public ResponseEntity<Void> deleteSizeList(@PathVariable String id) {
        log.debug("REST request to delete SizeList : {}", id);
        sizeListService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id)).build();
    }
}
