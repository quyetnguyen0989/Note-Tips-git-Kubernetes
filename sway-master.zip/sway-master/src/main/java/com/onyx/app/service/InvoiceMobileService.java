package com.onyx.app.service;

import com.onyx.app.service.dto.InvoiceMobileDTO;

import java.util.List;
import java.util.Optional;

/**
 * Service Interface for managing InvoiceMobile.
 */
public interface InvoiceMobileService {

    /**
     * Save a invoiceMobile.
     *
     * @param invoiceMobileDTO the entity to save
     * @return the persisted entity
     */
    InvoiceMobileDTO save(InvoiceMobileDTO invoiceMobileDTO);

    /**
     * Get all the invoiceMobiles.
     *
     * @return the list of entities
     */
    List<InvoiceMobileDTO> findAll();


    /**
     * Get the "id" invoiceMobile.
     *
     * @param id the id of the entity
     * @return the entity
     */
    Optional<InvoiceMobileDTO> findOne(String id);

    /**
     * Delete the "id" invoiceMobile.
     *
     * @param id the id of the entity
     */
    void delete(String id);
}
