package com.onyx.app.repository;

import com.onyx.app.domain.InventoryTimeSale;
import org.springframework.stereotype.Repository;

/**
 * Spring Data Couchbase repository for the InventoryTimeSale entity.
 */
@SuppressWarnings("unused")
@Repository
public interface InventoryTimeSaleRepository extends N1qlCouchbaseRepository<InventoryTimeSale, String> {

}
