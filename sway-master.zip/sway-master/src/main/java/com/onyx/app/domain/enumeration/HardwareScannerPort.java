package com.onyx.app.domain.enumeration;

/**
 * The HardwareScannerPort enumeration.
 */
public enum HardwareScannerPort {
    USB, COM
}
