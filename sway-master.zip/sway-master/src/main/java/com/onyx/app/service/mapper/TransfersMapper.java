package com.onyx.app.service.mapper;

import com.onyx.app.domain.*;
import com.onyx.app.service.dto.TransfersDTO;

import org.mapstruct.*;

/**
 * Mapper for the entity Transfers and its DTO TransfersDTO.
 */
@Mapper(componentModel = "spring", uses = {})
public interface TransfersMapper extends EntityMapper<TransfersDTO, Transfers> {


}
