package com.onyx.app.web.rest;

import com.codahale.metrics.annotation.Timed;
import com.onyx.app.service.TouchDisplayService;
import com.onyx.app.web.rest.errors.BadRequestAlertException;
import com.onyx.app.web.rest.util.HeaderUtil;
import com.onyx.app.service.dto.TouchDisplayDTO;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.net.URISyntaxException;

import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing TouchDisplay.
 */
@RestController
@RequestMapping("/api")
public class TouchDisplayResource {

    private final Logger log = LoggerFactory.getLogger(TouchDisplayResource.class);

    private static final String ENTITY_NAME = "touchDisplay";

    private final TouchDisplayService touchDisplayService;

    public TouchDisplayResource(TouchDisplayService touchDisplayService) {
        this.touchDisplayService = touchDisplayService;
    }

    /**
     * POST  /touch-displays : Create a new touchDisplay.
     *
     * @param touchDisplayDTO the touchDisplayDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new touchDisplayDTO, or with status 400 (Bad Request) if the touchDisplay has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/touch-displays")
    @Timed
    public ResponseEntity<TouchDisplayDTO> createTouchDisplay(@RequestBody TouchDisplayDTO touchDisplayDTO) throws URISyntaxException {
        log.debug("REST request to save TouchDisplay : {}", touchDisplayDTO);
        if (touchDisplayDTO.getId() != null) {
            throw new BadRequestAlertException("A new touchDisplay cannot already have an ID", ENTITY_NAME, "idexists");
        }
        TouchDisplayDTO result = touchDisplayService.save(touchDisplayDTO);
        return ResponseEntity.created(new URI("/api/touch-displays/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /touch-displays : Updates an existing touchDisplay.
     *
     * @param touchDisplayDTO the touchDisplayDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated touchDisplayDTO,
     * or with status 400 (Bad Request) if the touchDisplayDTO is not valid,
     * or with status 500 (Internal Server Error) if the touchDisplayDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/touch-displays")
    @Timed
    public ResponseEntity<TouchDisplayDTO> updateTouchDisplay(@RequestBody TouchDisplayDTO touchDisplayDTO) throws URISyntaxException {
        log.debug("REST request to update TouchDisplay : {}", touchDisplayDTO);
        if (touchDisplayDTO.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        TouchDisplayDTO result = touchDisplayService.save(touchDisplayDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, touchDisplayDTO.getId().toString()))
            .body(result);
    }

    /**
     * GET  /touch-displays : get all the touchDisplays.
     *
     * @return the ResponseEntity with status 200 (OK) and the list of touchDisplays in body
     */
    @GetMapping("/touch-displays")
    @Timed
    public List<TouchDisplayDTO> getAllTouchDisplays() {
        log.debug("REST request to get all TouchDisplays");
        return touchDisplayService.findAll();
    }

    /**
     * GET  /touch-displays/:id : get the "id" touchDisplay.
     *
     * @param id the id of the touchDisplayDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the touchDisplayDTO, or with status 404 (Not Found)
     */
    @GetMapping("/touch-displays/{id}")
    @Timed
    public ResponseEntity<TouchDisplayDTO> getTouchDisplay(@PathVariable String id) {
        log.debug("REST request to get TouchDisplay : {}", id);
        Optional<TouchDisplayDTO> touchDisplayDTO = touchDisplayService.findOne(id);
        return ResponseUtil.wrapOrNotFound(touchDisplayDTO);
    }

    /**
     * DELETE  /touch-displays/:id : delete the "id" touchDisplay.
     *
     * @param id the id of the touchDisplayDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/touch-displays/{id}")
    @Timed
    public ResponseEntity<Void> deleteTouchDisplay(@PathVariable String id) {
        log.debug("REST request to delete TouchDisplay : {}", id);
        touchDisplayService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id)).build();
    }
}
