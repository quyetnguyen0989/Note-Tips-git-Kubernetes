package com.onyx.app.domain;

import org.springframework.data.annotation.Id;
import com.couchbase.client.java.repository.annotation.Field;
import org.springframework.data.couchbase.core.mapping.Document;
import org.springframework.data.couchbase.core.mapping.id.GeneratedValue;
import org.springframework.data.couchbase.core.mapping.id.IdPrefix;
import javax.validation.constraints.*;

import java.io.Serializable;
import java.util.Objects;

import static com.onyx.app.config.Constants.ID_DELIMITER;
import static org.springframework.data.couchbase.core.mapping.id.GenerationStrategy.UNIQUE;

/**
 * A InventoryExp.
 */
@Document
public class InventoryExp implements Serializable {

    private static final long serialVersionUID = 1L;
    public static final String PREFIX = "inventoryexp";

    @SuppressWarnings("unused")
    @IdPrefix
    private String prefix = PREFIX;

    @Id
    @GeneratedValue(strategy = UNIQUE, delimiter = ID_DELIMITER)
    private String id;

    @Size(max = 25)
    @Field("item_num")
    private String itemNum;

    @Size(max = 50)
    @Field("item_name")
    private String itemName;

    @Field("store_id")
    private Integer storeId;

    @Field("expiration_date")
    private String expirationDate;

    @Field("received_date")
    private String receivedDate;

    @Field("note_on_expiration")
    private Boolean noteOnExpiration;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getItemNum() {
        return itemNum;
    }

    public InventoryExp itemNum(String itemNum) {
        this.itemNum = itemNum;
        return this;
    }

    public void setItemNum(String itemNum) {
        this.itemNum = itemNum;
    }

    public String getItemName() {
        return itemName;
    }

    public InventoryExp itemName(String itemName) {
        this.itemName = itemName;
        return this;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public Integer getStoreId() {
        return storeId;
    }

    public InventoryExp storeId(Integer storeId) {
        this.storeId = storeId;
        return this;
    }

    public void setStoreId(Integer storeId) {
        this.storeId = storeId;
    }

    public String getExpirationDate() {
        return expirationDate;
    }

    public InventoryExp expirationDate(String expirationDate) {
        this.expirationDate = expirationDate;
        return this;
    }

    public void setExpirationDate(String expirationDate) {
        this.expirationDate = expirationDate;
    }

    public String getReceivedDate() {
        return receivedDate;
    }

    public InventoryExp receivedDate(String receivedDate) {
        this.receivedDate = receivedDate;
        return this;
    }

    public void setReceivedDate(String receivedDate) {
        this.receivedDate = receivedDate;
    }

    public Boolean isNoteOnExpiration() {
        return noteOnExpiration;
    }

    public InventoryExp noteOnExpiration(Boolean noteOnExpiration) {
        this.noteOnExpiration = noteOnExpiration;
        return this;
    }

    public void setNoteOnExpiration(Boolean noteOnExpiration) {
        this.noteOnExpiration = noteOnExpiration;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        InventoryExp inventoryExp = (InventoryExp) o;
        if (inventoryExp.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), inventoryExp.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "InventoryExp{" +
            "id=" + getId() +
            ", itemNum='" + getItemNum() + "'" +
            ", itemName='" + getItemName() + "'" +
            ", storeId=" + getStoreId() +
            ", expirationDate='" + getExpirationDate() + "'" +
            ", receivedDate='" + getReceivedDate() + "'" +
            ", noteOnExpiration='" + isNoteOnExpiration() + "'" +
            "}";
    }
}
