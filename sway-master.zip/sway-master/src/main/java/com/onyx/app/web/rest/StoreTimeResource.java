package com.onyx.app.web.rest;

import com.onyx.app.domain.StoreTime;
import com.onyx.app.repository.StoreTimeRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.temporal.Temporal;
import java.util.List;

@RestController
@RequestMapping("/api")
public class StoreTimeResource {

    private final Logger LOG = LoggerFactory.getLogger(StoreTimeResource.class);

    boolean isFlag = false;

    @Autowired
    private StoreTimeRepository storeTimeRepository;

    @PostMapping("/store-time")
    public ResponseEntity<?> create(@RequestBody StoreTime storeTime){
//        LocalTime start = LocalTime.of(10,00);
//        LocalTime end = LocalTime.of(12,00);
//        storeTime.setFrom(start);
//        storeTime.setTo(end);
        StoreTime storeSaved = storeTimeRepository.save(storeTime);
        return new ResponseEntity<StoreTime>(storeSaved , HttpStatus.OK);
    }

    @GetMapping("/store-time")
    public ResponseEntity<List<StoreTime>> getAll(){
        List<StoreTime> storeTimes = storeTimeRepository.findAll();
        return new ResponseEntity<>(storeTimes , HttpStatus.OK);
    }

    @GetMapping("/store-time/{storeId}")
    public ResponseEntity<?> getByStoreId(@PathVariable Integer storeId){

//        StoreTime storeTime = storeTimeRepository.findByStoreId(storeId);
        List<StoreTime> storeTimes = storeTimeRepository.findAllByStoreId(storeId);
        storeTimes.stream().forEach(storeTime -> {
            LocalTime startTime = storeTime.getFrom().atZone(ZoneOffset.UTC).toLocalTime();
            LocalTime endTime = storeTime.getTo().atZone(ZoneOffset.UTC).toLocalTime();
            LocalTime now = LocalTime.now();
            String day = LocalDate.now().getDayOfWeek().name();
            if (day.equals(storeTime.getDay().name())) {
                LOG.info("--------------> start time " + startTime.format(DateTimeFormatter.ofPattern("hh:mm:ss a")));
                LOG.info("--------------> end time " + endTime.format(DateTimeFormatter.ofPattern("hh:mm:ss a")));
                LOG.info("--------------> now time " + LocalTime.now().format(DateTimeFormatter.ofPattern("hh:mm:ss a")));
                if (now.isBefore(endTime) && now.isAfter(startTime)) {
                    isFlag = true;
                }
            }
        });

//        LOG.info(" ---------------------> start time is: " + storeTime.getFrom().format(DateTimeFormatter.ofPattern("hh:mm a")));
//        LOG.info(" ---------------------> end time is: " + storeTime.getTo().format(DateTimeFormatter.ofPattern("hh:mm a")));
//        LOG.info(" ---------------------> now time is: " + now);
//        LOG.info(" ---------------------> now time without format: " + now);
//        LOG.info(" ---------------------> end time without format: " + storeTime.getTo());



        return new ResponseEntity<Object>(isFlag, HttpStatus.OK);
    }

    @DeleteMapping("/store-time/{id}")
    public ResponseEntity<Void> deleteStoreTime(@PathVariable String id){
        storeTimeRepository.deleteById(id);
        return new ResponseEntity<Void>(HttpStatus.OK);
    }
}
