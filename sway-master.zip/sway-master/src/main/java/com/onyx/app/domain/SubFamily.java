package com.onyx.app.domain;

import org.springframework.data.annotation.Id;
import com.couchbase.client.java.repository.annotation.Field;
import org.springframework.data.couchbase.core.mapping.Document;
import org.springframework.data.couchbase.core.mapping.id.GeneratedValue;
import org.springframework.data.couchbase.core.mapping.id.IdPrefix;
import javax.validation.constraints.*;

import java.io.Serializable;
import java.util.Objects;

import static com.onyx.app.config.Constants.ID_DELIMITER;
import static org.springframework.data.couchbase.core.mapping.id.GenerationStrategy.UNIQUE;

/**
 * A SubFamily.
 */
@Document
public class SubFamily implements Serializable {

    private static final long serialVersionUID = 1L;
    public static final String PREFIX = "subfamily";

    @SuppressWarnings("unused")
    @IdPrefix
    private String prefix = PREFIX;

    @Id
    @GeneratedValue(strategy = UNIQUE, delimiter = ID_DELIMITER)
    private String id;

    @Field("family_id")
    private Integer familyId;

    @Field("sub_family_id")
    private Integer subFamilyId;

    @Field("sub_family_name")
    private String subFamilyName;

    @NotNull
    @Field("store_id")
    private Integer storeId;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getFamilyId() {
        return familyId;
    }

    public SubFamily familyId(Integer familyId) {
        this.familyId = familyId;
        return this;
    }

    public void setFamilyId(Integer familyId) {
        this.familyId = familyId;
    }

    public Integer getSubFamilyId() {
        return subFamilyId;
    }

    public SubFamily subFamilyId(Integer subFamilyId) {
        this.subFamilyId = subFamilyId;
        return this;
    }

    public void setSubFamilyId(Integer subFamilyId) {
        this.subFamilyId = subFamilyId;
    }

    public String getSubFamilyName() {
        return subFamilyName;
    }

    public SubFamily subFamilyName(String subFamilyName) {
        this.subFamilyName = subFamilyName;
        return this;
    }

    public void setSubFamilyName(String subFamilyName) {
        this.subFamilyName = subFamilyName;
    }

    public Integer getStoreId() {
        return storeId;
    }

    public SubFamily storeId(Integer storeId) {
        this.storeId = storeId;
        return this;
    }

    public void setStoreId(Integer storeId) {
        this.storeId = storeId;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        SubFamily subFamily = (SubFamily) o;
        if (subFamily.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), subFamily.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "SubFamily{" +
            "id=" + getId() +
            ", familyId=" + getFamilyId() +
            ", subFamilyId=" + getSubFamilyId() +
            ", subFamilyName='" + getSubFamilyName() + "'" +
            ", storeId=" + getStoreId() +
            "}";
    }
}
