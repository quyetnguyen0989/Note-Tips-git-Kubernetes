package com.onyx.app.service;

import com.onyx.app.service.dto.InvoiceOnHoldDTO;

import java.util.List;
import java.util.Optional;

/**
 * Service Interface for managing InvoiceOnHold.
 */
public interface InvoiceOnHoldService {

    /**
     * Save a invoiceOnHold.
     *
     * @param invoiceOnHoldDTO the entity to save
     * @return the persisted entity
     */
    InvoiceOnHoldDTO save(InvoiceOnHoldDTO invoiceOnHoldDTO);

    /**
     * Get all the invoiceOnHolds.
     *
     * @return the list of entities
     */
    List<InvoiceOnHoldDTO> findAll();


    /**
     * Get the "id" invoiceOnHold.
     *
     * @param id the id of the entity
     * @return the entity
     */
    Optional<InvoiceOnHoldDTO> findOne(String id);

    /**
     * Delete the "id" invoiceOnHold.
     *
     * @param id the id of the entity
     */
    void delete(String id);
}
