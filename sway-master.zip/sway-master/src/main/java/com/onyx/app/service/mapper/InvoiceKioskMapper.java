package com.onyx.app.service.mapper;

import com.onyx.app.domain.*;
import com.onyx.app.service.dto.InvoiceKioskDTO;

import org.mapstruct.*;

/**
 * Mapper for the entity InvoiceKiosk and its DTO InvoiceKioskDTO.
 */
@Mapper(componentModel = "spring", uses = {})
public interface InvoiceKioskMapper extends EntityMapper<InvoiceKioskDTO, InvoiceKiosk> {


}
