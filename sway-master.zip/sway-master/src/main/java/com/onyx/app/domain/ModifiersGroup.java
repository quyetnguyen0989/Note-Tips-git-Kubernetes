package com.onyx.app.domain;

import org.springframework.data.annotation.Id;
import com.couchbase.client.java.repository.annotation.Field;
import org.springframework.data.couchbase.core.mapping.Document;
import org.springframework.data.couchbase.core.mapping.id.GeneratedValue;
import org.springframework.data.couchbase.core.mapping.id.IdPrefix;

import java.io.Serializable;
import java.util.List;
import java.util.Objects;

import static com.onyx.app.config.Constants.ID_DELIMITER;
import static org.springframework.data.couchbase.core.mapping.id.GenerationStrategy.UNIQUE;

/**
 * A ModifiersGroup.
 */
@Document
public class ModifiersGroup implements Serializable {

	private static final long serialVersionUID = 1L;
	public static final String PREFIX = "modifiersgroup";

	@SuppressWarnings("unused")
	@IdPrefix
	private String prefix = PREFIX;

	@Id
	@GeneratedValue(strategy = UNIQUE, delimiter = ID_DELIMITER)
	private String id;

	@Field("storeid")
	private Integer storeid;

	@Field("modifier_group_id")
	private Integer modifierGroupID;

	@Field("modifier_group_name")
	private String modifierGroupName;

	@Field("modifiers")
	private List<Modifier> modifiers;

	// @Field("modifier_name")
	// private String modifierName;
	//
	// @Field("modifier_id")
	// private Integer modifierID;
	//
	// @Field("modifier_num")
	// private Long modifierNum;

	// jhipster-needle-entity-add-field - JHipster will add fields here, do not
	// remove
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Integer getStoreid() {
		return storeid;
	}

	public ModifiersGroup storeid(Integer storeid) {
		this.storeid = storeid;
		return this;
	}

	public void setStoreid(Integer storeid) {
		this.storeid = storeid;
	}

	public Integer getModifierGroupID() {
		return modifierGroupID;
	}

	public ModifiersGroup modifierGroupID(Integer modifierGroupID) {
		this.modifierGroupID = modifierGroupID;
		return this;
	}

	public void setModifierGroupID(Integer modifierGroupID) {
		this.modifierGroupID = modifierGroupID;
	}

	// public String getModifierName() {
	// return modifierName;
	// }
	//
	// public ModifiersGroup modifierName(String modifierName) {
	// this.modifierName = modifierName;
	// return this;
	// }
	//
	// public void setModifierName(String modifierName) {
	// this.modifierName = modifierName;
	// }
	//
	// public Integer getModifierID() {
	// return modifierID;
	// }
	//
	// public ModifiersGroup modifierID(Integer modifierID) {
	// this.modifierID = modifierID;
	// return this;
	// }
	//
	// public void setModifierID(Integer modifierID) {
	// this.modifierID = modifierID;
	// }
	//
	// public Long getModifierNum() {
	// return modifierNum;
	// }
	//
	// public ModifiersGroup modifierNum(Long modifierNum) {
	// this.modifierNum = modifierNum;
	// return this;
	// }
	//
	// public void setModifierNum(Long modifierNum) {
	// this.modifierNum = modifierNum;
	// }
	// jhipster-needle-entity-add-getters-setters - JHipster will add getters and
	// setters here, do not remove

	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		ModifiersGroup modifiersGroup = (ModifiersGroup) o;
		if (modifiersGroup.getId() == null || getId() == null) {
			return false;
		}
		return Objects.equals(getId(), modifiersGroup.getId());
	}

	public String getModifierGroupName() {
		return modifierGroupName;
	}

	public void setModifierGroupName(String modifierGroupName) {
		this.modifierGroupName = modifierGroupName;
	}

	public List<Modifier> getModifiers() {
		return modifiers;
	}

	public void setModifiers(List<Modifier> modifiers) {
		this.modifiers = modifiers;
	}

	@Override
	public int hashCode() {
		return Objects.hashCode(getId());
	}

	@Override
	public String toString() {
		return "ModifiersGroup [id=" + id + ", storeid=" + storeid + ", modifierGroupID=" + modifierGroupID
				+ ", modifierGroupName=" + modifierGroupName + ", modifiers=" + modifiers + "]";
	}

}
