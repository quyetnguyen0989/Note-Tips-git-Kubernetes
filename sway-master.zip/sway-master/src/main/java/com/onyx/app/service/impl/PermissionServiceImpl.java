package com.onyx.app.service.impl;

import com.onyx.app.domain.Permission;
import com.onyx.app.repository.EmployeeRepository;
import com.onyx.app.repository.PermissionRepository;
import com.onyx.app.service.PermissionService;
import com.onyx.app.service.dto.PermissionDTO;
import com.onyx.app.service.mapper.PermissionMapper;
import com.onyx.app.web.rest.errors.BrandException;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.Optional;
/**
 * Service Implementation for managing Employee.
 */
@Service
public class PermissionServiceImpl implements PermissionService {

    private final Logger log = LoggerFactory.getLogger(PermissionServiceImpl.class);

    private final PermissionRepository permissionRepository;
    
    private final EmployeeRepository employeeRepository;

    private final PermissionMapper permissionMapper;

    public PermissionServiceImpl(PermissionRepository permissionRepository, PermissionMapper permissionMapper,
    		EmployeeRepository employeeRepository) {
        this.permissionRepository = permissionRepository;
        this.permissionMapper = permissionMapper;
        this.employeeRepository = employeeRepository;
    }

    /**
     * Save a employee.
     *
     * @param permissionDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public PermissionDTO save(PermissionDTO permissionDTO) {
        log.debug("Request to save Employee : {}", permissionDTO);
        ModelMapper mapper = new ModelMapper();
        if(permissionDTO.getEmployees() != null) {
        	permissionDTO.getEmployees().stream().forEach(id -> {
        		employeeRepository.findById(id).orElseThrow(() -> new BrandException("Employee Not exists! with ID: " + id));
        	});
        }
//        Permission employee = permissionMapper.toEntity(permissionDTO);
        Permission permission = mapper.map(permissionDTO, Permission.class);
        permission = permissionRepository.save(permission);
        return mapper.map(permission, PermissionDTO.class);
    }

    /**
     * Get all the employees.
     *
     * @param pageable the pagination information
     * @return the list of entities
     */
    @Override
    public Page<PermissionDTO> findAll(Pageable pageable) {
        log.debug("Request to get all Employees");
        return permissionRepository.findAll(pageable)
            .map(permissionMapper::toDto);
    }

    /*@Override
    public Optional<Employee> findOne(Example<Employee> ex) {
        return employeeRepository.(ex);
    }*/


    /**
     * Get one employee by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    public Optional<PermissionDTO> findOne(String id) {
        log.debug("Request to get Employee : {}", id);
        return permissionRepository.findById(id)
            .map(permissionMapper::toDto);
    }

    /**
     * Delete the employee by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(String id) {
        log.debug("Request to delete Employee : {}", id);
        permissionRepository.deleteById(id);
    }
}
