package com.onyx.app.service;

import com.onyx.app.domain.Inventory;
import com.onyx.app.domain.InvoiceCheckout;
import com.onyx.app.repository.InventoryRepository;
import com.onyx.app.repository.InvoiceCheckoutRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Service;

import java.util.Arrays;

//@Service
public class DBseeder implements CommandLineRunner{

    @Autowired
    private InventoryRepository inventoryRepository;

//    @Autowired
//    private InvoiceCheckoutRepository invoiceCheckoutRepository;

    @Override
    public void run(String... args) throws Exception {
//        if (invoiceCheckoutRepository.findAll() != null) {
//            invoiceCheckoutRepository.deleteAll();
//        }

        try {
            Inventory inventory1 = inventoryRepository.findById("inventory__0d5f9de7-23ea-4e57-b988-834417b62a66").get();
            inventory1.setId(inventory1.getId());
            Inventory inventory2 = inventoryRepository.findById("inventory__11ea22a7-2f5f-4d7e-bc70-eb4c1cce41cf").get();
            inventory2.setId(inventory2.getId());
            InvoiceCheckout invoiceCheckout = new InvoiceCheckout();
            invoiceCheckout.setInventories(Arrays.asList(inventory1,inventory2));
            invoiceCheckout.setCashiername("Andrew");
            invoiceCheckout.setInvnum(44);

//            invoiceCheckoutRepository.save(invoiceCheckout);
        }catch (Exception e){
            System.out.println(e.getMessage());
        }




    }
}
