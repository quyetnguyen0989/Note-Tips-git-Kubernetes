package com.onyx.app.service.mapper;

import com.onyx.app.domain.*;
import com.onyx.app.service.dto.InvoiceDetailsDTO;

import org.mapstruct.*;

/**
 * Mapper for the entity InvoiceDetails and its DTO InvoiceDetailsDTO.
 */
@Mapper(componentModel = "spring", uses = {})
public interface InvoiceDetailsMapper extends EntityMapper<InvoiceDetailsDTO, InvoiceDetails> {


}
