package com.onyx.app.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.onyx.app.domain.Employee;
import com.onyx.app.repository.EmployeeRepository;
import com.onyx.app.service.EmployeeService;
import com.onyx.app.web.rest.errors.BrandException;

@Service
public class EmployeeServiceImpl implements EmployeeService{
	
	@Autowired
	private EmployeeRepository employeeRepository;

	@Override
	public Employee save(Employee employee) {
		return employeeRepository.save(employee);
	}

	@Override
	public Employee getOne(String id) {
		return employeeRepository.findById(id).orElseThrow(() -> new BrandException("Employee not found with ID: " + id));
	}

	@Override
	public List<Employee> getEmployees(int page, int limit) {
		List<Employee> returnEmployees = new ArrayList<Employee>();
		Pageable pageable = PageRequest.of(page, limit);
		Page<Employee> employeesPage = employeeRepository.findAll(pageable);
		List<Employee> employees = employeesPage.getContent();
		if(employees != null) {
			employees.stream().map(returnEmployees:: add).collect(Collectors.toList());
		}
		return returnEmployees;
	}

	@Override
	public void delete(String id) {
		
	}

}
