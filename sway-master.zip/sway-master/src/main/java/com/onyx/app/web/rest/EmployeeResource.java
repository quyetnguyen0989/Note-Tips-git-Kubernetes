package com.onyx.app.web.rest;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.codahale.metrics.annotation.Timed;
import com.onyx.app.domain.Employee;
import com.onyx.app.repository.PermissionRepository;
import com.onyx.app.repository.StoreLocalRepository;
import com.onyx.app.service.EmployeeService;
import com.onyx.app.web.rest.errors.BadRequestAlertException;
import com.onyx.app.web.rest.errors.BrandException;
import com.onyx.app.web.rest.util.HeaderUtil;

@RestController
@RequestMapping("/api")
public class EmployeeResource {

	private final Logger log = LoggerFactory.getLogger(EmployeeResource.class);
	
	@Autowired
	private EmployeeService employeeService;
	
	@Autowired
	private PermissionRepository permissionRepository;
	
	@Autowired
	private StoreLocalRepository storeRepository;
	
	@PostMapping("/employees")
	@Timed
	public ResponseEntity<Employee> createEmp(@Valid @RequestBody Employee employee){
		
		log.debug("REST request to save Employee : {}" , employee);
		if(employee.getId() != null) {
			throw new BadRequestAlertException("A new employee cannot already have an ID", "employee" , "idexists");
		}
		if(employee.getStoreId() != null) {
		 storeRepository.findById(employee.getStoreId()).orElseThrow(() -> new BrandException("Store Not exsists with Id: " + employee.getStoreId()));
		}
		if(employee.getRoles() != null) {
			employee.getRoles().stream().forEach(id -> {
				permissionRepository.findById(id).orElseThrow(() -> new BrandException("Permission Not exsists with Id: " + id));
			});
		}
		
		Employee employeeSaved = employeeService.save(employee);
		return ResponseEntity.status(HttpStatus.OK).body(employeeSaved);
	}
	
	@GetMapping("/employees")
	@Timed
	public ResponseEntity<List<Employee>> getAllEmployee(@RequestParam(value="page" , defaultValue = "0") int page , 
    												   @RequestParam(value="limit" , defaultValue = "25") int limit){
		List<Employee> employeesReturned = new ArrayList<>();
		List<Employee> employees = employeeService.getEmployees(page , limit);
		if(employees != null) {
			employees.stream().map(employeesReturned:: add).collect(Collectors.toList());
		}
		return ResponseEntity.status(HttpStatus.OK).body(employeesReturned);
	}
	
	@GetMapping("/employees/{id}")
	@Timed
	public ResponseEntity<?> getEmployee(@PathVariable String id){
		Employee employee = employeeService.getOne(id);
		return ResponseEntity.status(HttpStatus.OK).body(employee);
	}
	
	@PutMapping("/employees")
	@Timed
	public ResponseEntity<?> updateEmployee(@Valid @RequestBody Employee employee){
		if(employee.getId() == null) {
			throw new BadRequestAlertException("Invalid Id", "employee", "idnull");
		}
		if(employee.getStoreId() != null) {
			 storeRepository.findById(employee.getStoreId()).orElseThrow(() -> new BrandException("Store Not exsists with Id: " + employee.getStoreId()));
			}
		if(employee.getRoles() != null) {
			employee.getRoles().stream().forEach(id -> {
				permissionRepository.findById(id).orElseThrow(() -> new BrandException("Permission Not exsists with Id: " + id));
			});
		}
		Employee employeeSaved = employeeService.save(employee);
		return ResponseEntity.status(HttpStatus.OK).body(employeeSaved);
	}
	
	@DeleteMapping("/employees/{id}")
	@Timed
	public ResponseEntity<Void> deleteEmployee(@PathVariable String id){
		employeeService.delete(id);
		return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert("employee", id)).build();
	}
}
