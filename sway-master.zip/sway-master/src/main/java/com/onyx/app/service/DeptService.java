package com.onyx.app.service;

import com.onyx.app.service.dto.DeptDTO;

import java.util.List;
import java.util.Optional;

/**
 * Service Interface for managing Dept.
 */
public interface DeptService {

    /**
     * Save a dept.
     *
     * @param deptDTO the entity to save
     * @return the persisted entity
     */
    DeptDTO save(DeptDTO deptDTO);

    /**
     * Get all the depts.
     *
     * @return the list of entities
     */
    List<DeptDTO> findAll();


    /**
     * Get the "id" dept.
     *
     * @param id the id of the entity
     * @return the entity
     */
    Optional<DeptDTO> findOne(String id);

    /**
     * Delete the "id" dept.
     *
     * @param id the id of the entity
     */
    void delete(String id);
}
