package com.onyx.app.service.dto;

import java.io.Serializable;
import java.util.Objects;

/**
 * A DTO for the SizeList entity.
 */
public class SizeListDTO implements Serializable {

    private String id;

    private Integer sizeId;

    private String unit;

    private String measurement;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getSizeId() {
        return sizeId;
    }

    public void setSizeId(Integer sizeId) {
        this.sizeId = sizeId;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public String getMeasurement() {
        return measurement;
    }

    public void setMeasurement(String measurement) {
        this.measurement = measurement;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        SizeListDTO sizeListDTO = (SizeListDTO) o;
        if (sizeListDTO.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), sizeListDTO.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "SizeListDTO{" +
            "id=" + getId() +
            ", sizeId=" + getSizeId() +
            ", unit='" + getUnit() + "'" +
            ", measurement='" + getMeasurement() + "'" +
            "}";
    }
}
