package com.onyx.app.service.impl;

import com.onyx.app.service.CtrxService;
import com.onyx.app.domain.Ctrx;
import com.onyx.app.repository.CtrxRepository;
import com.onyx.app.service.dto.CtrxDTO;
import com.onyx.app.service.mapper.CtrxMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.stereotype.Service;

import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
/**
 * Service Implementation for managing Ctrx.
 */
@Service
public class CtrxServiceImpl implements CtrxService {

    private final Logger log = LoggerFactory.getLogger(CtrxServiceImpl.class);

    private final CtrxRepository ctrxRepository;

    private final CtrxMapper ctrxMapper;

    public CtrxServiceImpl(CtrxRepository ctrxRepository, CtrxMapper ctrxMapper) {
        this.ctrxRepository = ctrxRepository;
        this.ctrxMapper = ctrxMapper;
    }

    /**
     * Save a ctrx.
     *
     * @param ctrxDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public CtrxDTO save(CtrxDTO ctrxDTO) {
        log.debug("Request to save Ctrx : {}", ctrxDTO);
        Ctrx ctrx = ctrxMapper.toEntity(ctrxDTO);
        ctrx = ctrxRepository.save(ctrx);
        return ctrxMapper.toDto(ctrx);
    }

    /**
     * Get all the ctrxes.
     *
     * @return the list of entities
     */
    @Override
    public List<CtrxDTO> findAll() {
        log.debug("Request to get all Ctrxes");
        return ctrxRepository.findAll().stream()
            .map(ctrxMapper::toDto)
            .collect(Collectors.toCollection(LinkedList::new));
    }


    /**
     * Get one ctrx by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    public Optional<CtrxDTO> findOne(String id) {
        log.debug("Request to get Ctrx : {}", id);
        return ctrxRepository.findById(id)
            .map(ctrxMapper::toDto);
    }

    /**
     * Delete the ctrx by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(String id) {
        log.debug("Request to delete Ctrx : {}", id);
        ctrxRepository.deleteById(id);
    }
}
