package com.onyx.app.domain.enumeration;

/**
 * The HardwarePoleType enumeration.
 */
public enum HardwarePoleType {
    BEAMATECH, LG, NCR
}
