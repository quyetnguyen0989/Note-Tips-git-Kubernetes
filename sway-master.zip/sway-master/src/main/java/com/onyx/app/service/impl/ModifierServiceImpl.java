package com.onyx.app.service.impl;

import com.onyx.app.service.ModifierService;
import com.onyx.app.domain.Modifier;
import com.onyx.app.repository.ModifierRepository;
import com.onyx.app.service.dto.ModifierDTO;
import com.onyx.app.service.mapper.ModifierMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.stereotype.Service;

import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
/**
 * Service Implementation for managing Modifier.
 */
@Service
public class ModifierServiceImpl implements ModifierService {

    private final Logger log = LoggerFactory.getLogger(ModifierServiceImpl.class);

    private final ModifierRepository modifierRepository;

    private final ModifierMapper modifierMapper;

    public ModifierServiceImpl(ModifierRepository modifierRepository, ModifierMapper modifierMapper) {
        this.modifierRepository = modifierRepository;
        this.modifierMapper = modifierMapper;
    }

    /**
     * Save a modifier.
     *
     * @param modifierDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public ModifierDTO save(ModifierDTO modifierDTO) {
        log.debug("Request to save Modifier : {}", modifierDTO);
        Modifier modifier = modifierMapper.toEntity(modifierDTO);
        modifier = modifierRepository.save(modifier);
        return modifierMapper.toDto(modifier);
    }

    /**
     * Get all the modifiers.
     *
     * @return the list of entities
     */
    @Override
    public List<ModifierDTO> findAll() {
        log.debug("Request to get all Modifiers");
        return modifierRepository.findAll().stream()
            .map(modifierMapper::toDto)
            .collect(Collectors.toCollection(LinkedList::new));
    }


    /**
     * Get one modifier by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    public Optional<ModifierDTO> findOne(String id) {
        log.debug("Request to get Modifier : {}", id);
        return modifierRepository.findById(id)
            .map(modifierMapper::toDto);
    }

    /**
     * Delete the modifier by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(String id) {
        log.debug("Request to delete Modifier : {}", id);
        modifierRepository.deleteById(id);
    }
}
