package com.onyx.app.config;

import com.onyx.app.domain.Notification;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.messaging.simp.stomp.StompCommand;
import org.springframework.messaging.simp.stomp.StompHeaders;
import org.springframework.messaging.simp.stomp.StompSession;
import org.springframework.messaging.simp.stomp.StompSessionHandlerAdapter;
import org.springframework.stereotype.Component;

import java.lang.reflect.Type;

public class MySessionHandler extends StompSessionHandlerAdapter{

    private static final Logger log = LoggerFactory.getLogger(MySessionHandler.class);

//    @Override
//    public void afterConnected(StompSession session, StompHeaders connectedHeaders) {
//        session.subscribe("/topic/greetings", this);
//        session.send("/app/socket", "{\"name\":\"Client\"}".getBytes());
//
//        log.info("New session: {}", session.getSessionId());
//    }

    @Override
    public void handleException(StompSession session, StompCommand command, StompHeaders headers, byte[] payload, Throwable exception) {
        exception.printStackTrace();
    }

    @Override
    public Type getPayloadType(StompHeaders headers) {
        return Notification.class;
    }

    @Override
    public void handleFrame(StompHeaders headers, Object payload) {
        log.info("Received: {}", ((Notification) payload).getCount());
    }
}
