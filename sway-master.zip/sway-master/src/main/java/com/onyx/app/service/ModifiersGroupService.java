package com.onyx.app.service;

import com.onyx.app.service.dto.ModifiersGroupDTO;

import java.util.List;
import java.util.Optional;

/**
 * Service Interface for managing ModifiersGroup.
 */
public interface ModifiersGroupService {

    /**
     * Save a modifiersGroup.
     *
     * @param modifiersGroupDTO the entity to save
     * @return the persisted entity
     */
    ModifiersGroupDTO save(ModifiersGroupDTO modifiersGroupDTO);

    /**
     * Get all the modifiersGroups.
     *
     * @return the list of entities
     */
    List<ModifiersGroupDTO> findAll();


    /**
     * Get the "id" modifiersGroup.
     *
     * @param id the id of the entity
     * @return the entity
     */
    Optional<ModifiersGroupDTO> findOne(String id);

    /**
     * Delete the "id" modifiersGroup.
     *
     * @param id the id of the entity
     */
    void delete(String id);
}
