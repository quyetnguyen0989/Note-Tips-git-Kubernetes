package com.onyx.app.service;

import com.onyx.app.service.dto.PayoutDTO;

import java.util.List;
import java.util.Optional;

/**
 * Service Interface for managing Payout.
 */
public interface PayoutService {

    /**
     * Save a payout.
     *
     * @param payoutDTO the entity to save
     * @return the persisted entity
     */
    PayoutDTO save(PayoutDTO payoutDTO);

    /**
     * Get all the payouts.
     *
     * @return the list of entities
     */
    List<PayoutDTO> findAll();


    /**
     * Get the "id" payout.
     *
     * @param id the id of the entity
     * @return the entity
     */
    Optional<PayoutDTO> findOne(String id);

    /**
     * Delete the "id" payout.
     *
     * @param id the id of the entity
     */
    void delete(String id);
}
