package com.onyx.app.web.rest;

import com.codahale.metrics.annotation.Timed;
import com.onyx.app.service.CtrxService;
import com.onyx.app.web.rest.errors.BadRequestAlertException;
import com.onyx.app.web.rest.util.HeaderUtil;
import com.onyx.app.service.dto.CtrxDTO;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.net.URISyntaxException;

import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing Ctrx.
 */
@RestController
@RequestMapping("/api")
public class CtrxResource {

    private final Logger log = LoggerFactory.getLogger(CtrxResource.class);

    private static final String ENTITY_NAME = "ctrx";

    private final CtrxService ctrxService;

    public CtrxResource(CtrxService ctrxService) {
        this.ctrxService = ctrxService;
    }

    /**
     * POST  /ctrxes : Create a new ctrx.
     *
     * @param ctrxDTO the ctrxDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new ctrxDTO, or with status 400 (Bad Request) if the ctrx has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/ctrxes")
    @Timed
    public ResponseEntity<CtrxDTO> createCtrx(@RequestBody CtrxDTO ctrxDTO) throws URISyntaxException {
        log.debug("REST request to save Ctrx : {}", ctrxDTO);
        if (ctrxDTO.getId() != null) {
            throw new BadRequestAlertException("A new ctrx cannot already have an ID", ENTITY_NAME, "idexists");
        }
        CtrxDTO result = ctrxService.save(ctrxDTO);
        return ResponseEntity.created(new URI("/api/ctrxes/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /ctrxes : Updates an existing ctrx.
     *
     * @param ctrxDTO the ctrxDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated ctrxDTO,
     * or with status 400 (Bad Request) if the ctrxDTO is not valid,
     * or with status 500 (Internal Server Error) if the ctrxDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/ctrxes")
    @Timed
    public ResponseEntity<CtrxDTO> updateCtrx(@RequestBody CtrxDTO ctrxDTO) throws URISyntaxException {
        log.debug("REST request to update Ctrx : {}", ctrxDTO);
        if (ctrxDTO.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        CtrxDTO result = ctrxService.save(ctrxDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, ctrxDTO.getId().toString()))
            .body(result);
    }

    /**
     * GET  /ctrxes : get all the ctrxes.
     *
     * @return the ResponseEntity with status 200 (OK) and the list of ctrxes in body
     */
    @GetMapping("/ctrxes")
    @Timed
    public List<CtrxDTO> getAllCtrxes() {
        log.debug("REST request to get all Ctrxes");
        return ctrxService.findAll();
    }

    /**
     * GET  /ctrxes/:id : get the "id" ctrx.
     *
     * @param id the id of the ctrxDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the ctrxDTO, or with status 404 (Not Found)
     */
    @GetMapping("/ctrxes/{id}")
    @Timed
    public ResponseEntity<CtrxDTO> getCtrx(@PathVariable String id) {
        log.debug("REST request to get Ctrx : {}", id);
        Optional<CtrxDTO> ctrxDTO = ctrxService.findOne(id);
        return ResponseUtil.wrapOrNotFound(ctrxDTO);
    }

    /**
     * DELETE  /ctrxes/:id : delete the "id" ctrx.
     *
     * @param id the id of the ctrxDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/ctrxes/{id}")
    @Timed
    public ResponseEntity<Void> deleteCtrx(@PathVariable String id) {
        log.debug("REST request to delete Ctrx : {}", id);
        ctrxService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id)).build();
    }
}
