package com.onyx.app.web.rest;
import com.onyx.app.domain.Invoice;
import com.onyx.app.repository.InvoiceRepository;
import com.onyx.app.service.InvoiceMobileService;
import com.onyx.app.web.rest.errors.BadRequestAlertException;
import com.onyx.app.web.rest.util.HeaderUtil;
import com.onyx.app.service.dto.InvoiceMobileDTO;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;

import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing InvoiceMobile.
 */
@RestController
@RequestMapping("/api")
public class InvoiceMobileResource {

    private final Logger log = LoggerFactory.getLogger(InvoiceMobileResource.class);

    private static final String ENTITY_NAME = "invoiceMobile";

    private final InvoiceMobileService invoiceMobileService;

    @Autowired
    private InvoiceRepository invoiceRepository;

    public InvoiceMobileResource(InvoiceMobileService invoiceMobileService) {
        this.invoiceMobileService = invoiceMobileService;
    }

    /**
     * POST  /invoice-mobiles : Create a new invoiceMobile.
     *
     * @param invoiceMobileDTO the invoiceMobileDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new invoiceMobileDTO, or with status 400 (Bad Request) if the invoiceMobile has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/invoice-mobiles")
    public ResponseEntity<InvoiceMobileDTO> createInvoiceMobile(@Valid @RequestBody InvoiceMobileDTO invoiceMobileDTO) throws URISyntaxException {
        log.debug("REST request to save InvoiceMobile : {}", invoiceMobileDTO);
        Invoice invoice = new Invoice();
        if (invoiceMobileDTO.getId() != null) {
            throw new BadRequestAlertException("A new invoiceMobile cannot already have an ID", ENTITY_NAME, "idexists");
        }
        InvoiceMobileDTO result = invoiceMobileService.save(invoiceMobileDTO);
        try{
            invoice.setItemnum(invoiceMobileDTO.getItemnum());
            invoice.setItemname(invoiceMobileDTO.getItemname());
            invoice.setStoreid(invoiceMobileDTO.getStoreid());
            invoice.setCustNum(invoiceMobileDTO.getCustNum());
            invoice.setInvnum(invoiceMobileDTO.getInvnum());
            invoice.setInvtime(invoiceMobileDTO.getInvtime());
            invoice.setItemprice(invoiceMobileDTO.getItemprice());
            invoice.setInvdate(invoiceMobileDTO.getInvdate());
            invoice.setDiscount(invoiceMobileDTO.getDiscount());
            invoice.setTotalPrice(invoiceMobileDTO.getTotalPrice());
            invoice.setTotalTax1(invoice.getTaxed1());
            invoice.setGrandTotal(invoiceMobileDTO.getGrandTotal());
            invoice.setAmtChange(invoiceMobileDTO.getAmtChange());
            invoice.setPaymentMethod(invoiceMobileDTO.getPaymentMethod());
            invoice.setTaxedSales(invoiceMobileDTO.getTaxedSales());
            invoice.setNonTaxedsales(invoiceMobileDTO.getNonTaxedsales());
            invoice.setCcamount(invoiceMobileDTO.getCcamount());
            invoice.setStatus(invoiceMobileDTO.getStatus());
            invoiceRepository.save(invoice);
        }catch (Exception e){
            log.error("there an error when create Invoice object " + e.getMessage());
        }
        return ResponseEntity.created(new URI("/api/invoice-mobiles/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /invoice-mobiles : Updates an existing invoiceMobile.
     *
     * @param invoiceMobileDTO the invoiceMobileDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated invoiceMobileDTO,
     * or with status 400 (Bad Request) if the invoiceMobileDTO is not valid,
     * or with status 500 (Internal Server Error) if the invoiceMobileDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/invoice-mobiles")
    public ResponseEntity<InvoiceMobileDTO> updateInvoiceMobile(@Valid @RequestBody InvoiceMobileDTO invoiceMobileDTO) throws URISyntaxException {
        log.debug("REST request to update InvoiceMobile : {}", invoiceMobileDTO);
        if (invoiceMobileDTO.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        InvoiceMobileDTO result = invoiceMobileService.save(invoiceMobileDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, invoiceMobileDTO.getId().toString()))
            .body(result);
    }

    /**
     * GET  /invoice-mobiles : get all the invoiceMobiles.
     *
     * @return the ResponseEntity with status 200 (OK) and the list of invoiceMobiles in body
     */
    @GetMapping("/invoice-mobiles")
    public List<InvoiceMobileDTO> getAllInvoiceMobiles() {
        log.debug("REST request to get all InvoiceMobiles");
        return invoiceMobileService.findAll();
    }

    /**
     * GET  /invoice-mobiles/:id : get the "id" invoiceMobile.
     *
     * @param id the id of the invoiceMobileDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the invoiceMobileDTO, or with status 404 (Not Found)
     */
    @GetMapping("/invoice-mobiles/{id}")
    public ResponseEntity<InvoiceMobileDTO> getInvoiceMobile(@PathVariable String id) {
        log.debug("REST request to get InvoiceMobile : {}", id);
        Optional<InvoiceMobileDTO> invoiceMobileDTO = invoiceMobileService.findOne(id);
        return ResponseUtil.wrapOrNotFound(invoiceMobileDTO);
    }

    /**
     * DELETE  /invoice-mobiles/:id : delete the "id" invoiceMobile.
     *
     * @param id the id of the invoiceMobileDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/invoice-mobiles/{id}")
    public ResponseEntity<Void> deleteInvoiceMobile(@PathVariable String id) {
        log.debug("REST request to delete InvoiceMobile : {}", id);
        invoiceMobileService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id)).build();
    }
}
