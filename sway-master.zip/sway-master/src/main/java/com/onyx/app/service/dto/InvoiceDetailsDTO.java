package com.onyx.app.service.dto;

import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.Objects;

/**
 * A DTO for the InvoiceDetails entity.
 */
public class InvoiceDetailsDTO implements Serializable {

    private String id;

    private String itemNum;

    private String invNum;

    @NotNull
    @Size(max = 10)
    private String itemPrice;

    private Double invoiceLineNum;

    private String invoiceTimeAndDate;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getItemNum() {
        return itemNum;
    }

    public void setItemNum(String itemNum) {
        this.itemNum = itemNum;
    }

    public String getInvNum() {
        return invNum;
    }

    public void setInvNum(String invNum) {
        this.invNum = invNum;
    }

    public String getItemPrice() {
        return itemPrice;
    }

    public void setItemPrice(String itemPrice) {
        this.itemPrice = itemPrice;
    }

    public Double getInvoiceLineNum() {
        return invoiceLineNum;
    }

    public void setInvoiceLineNum(Double invoiceLineNum) {
        this.invoiceLineNum = invoiceLineNum;
    }

    public String getInvoiceTimeAndDate() {
        return invoiceTimeAndDate;
    }

    public void setInvoiceTimeAndDate(String invoiceTimeAndDate) {
        this.invoiceTimeAndDate = invoiceTimeAndDate;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        InvoiceDetailsDTO invoiceDetailsDTO = (InvoiceDetailsDTO) o;
        if (invoiceDetailsDTO.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), invoiceDetailsDTO.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "InvoiceDetailsDTO{" +
            "id=" + getId() +
            ", itemNum='" + getItemNum() + "'" +
            ", invNum='" + getInvNum() + "'" +
            ", itemPrice='" + getItemPrice() + "'" +
            ", invoiceLineNum=" + getInvoiceLineNum() +
            ", invoiceTimeAndDate='" + getInvoiceTimeAndDate() + "'" +
            "}";
    }
}
