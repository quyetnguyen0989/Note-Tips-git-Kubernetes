package com.onyx.app.domain;

import org.springframework.data.annotation.Id;
import com.couchbase.client.java.repository.annotation.Field;
import org.springframework.data.couchbase.core.mapping.Document;
import javax.validation.constraints.*;

import java.io.Serializable;
import java.util.Objects;

/**
 * A InvoiceOnHold.
 */
@Document
public class InvoiceOnHold implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    private String id;

    @Size(max = 25)
    @Field("item_num")
    private String itemNum;

    @Field("inv_num")
    private Integer invNum;

    @NotNull
    @Size(max = 10)
    @Field("item_price")
    private String itemPrice;

    @Field("invoice_on_hold_id")
    private Double invoiceOnHoldId;

    @Field("inv_time")
    private String invTime;

    @Field("on_hold_name")
    private String onHoldName;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getItemNum() {
        return itemNum;
    }

    public InvoiceOnHold itemNum(String itemNum) {
        this.itemNum = itemNum;
        return this;
    }

    public void setItemNum(String itemNum) {
        this.itemNum = itemNum;
    }

    public Integer getInvNum() {
        return invNum;
    }

    public InvoiceOnHold invNum(Integer invNum) {
        this.invNum = invNum;
        return this;
    }

    public void setInvNum(Integer invNum) {
        this.invNum = invNum;
    }

    public String getItemPrice() {
        return itemPrice;
    }

    public InvoiceOnHold itemPrice(String itemPrice) {
        this.itemPrice = itemPrice;
        return this;
    }

    public void setItemPrice(String itemPrice) {
        this.itemPrice = itemPrice;
    }

    public Double getInvoiceOnHoldId() {
        return invoiceOnHoldId;
    }

    public InvoiceOnHold invoiceOnHoldId(Double invoiceOnHoldId) {
        this.invoiceOnHoldId = invoiceOnHoldId;
        return this;
    }

    public void setInvoiceOnHoldId(Double invoiceOnHoldId) {
        this.invoiceOnHoldId = invoiceOnHoldId;
    }

    public String getInvTime() {
        return invTime;
    }

    public InvoiceOnHold invTime(String invTime) {
        this.invTime = invTime;
        return this;
    }

    public void setInvTime(String invTime) {
        this.invTime = invTime;
    }

    public String getOnHoldName() {
        return onHoldName;
    }

    public InvoiceOnHold onHoldName(String onHoldName) {
        this.onHoldName = onHoldName;
        return this;
    }

    public void setOnHoldName(String onHoldName) {
        this.onHoldName = onHoldName;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        InvoiceOnHold invoiceOnHold = (InvoiceOnHold) o;
        if (invoiceOnHold.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), invoiceOnHold.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "InvoiceOnHold{" +
            "id=" + getId() +
            ", itemNum='" + getItemNum() + "'" +
            ", invNum=" + getInvNum() +
            ", itemPrice='" + getItemPrice() + "'" +
            ", invoiceOnHoldId=" + getInvoiceOnHoldId() +
            ", invTime='" + getInvTime() + "'" +
            ", onHoldName='" + getOnHoldName() + "'" +
            "}";
    }
}
