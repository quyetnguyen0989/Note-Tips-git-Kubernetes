package com.onyx.app.service.mapper;

import com.onyx.app.domain.*;
import com.onyx.app.service.dto.FeItemsDTO;

import org.mapstruct.*;

/**
 * Mapper for the entity FeItems and its DTO FeItemsDTO.
 */
@Mapper(componentModel = "spring", uses = {})
public interface FeItemsMapper extends EntityMapper<FeItemsDTO, FeItems> {


}
