package com.onyx.app.domain;

import org.springframework.data.annotation.Id;
import com.couchbase.client.java.repository.annotation.Field;
import org.springframework.data.couchbase.core.mapping.Document;
import org.springframework.data.couchbase.core.mapping.id.GeneratedValue;
import org.springframework.data.couchbase.core.mapping.id.IdPrefix;
import javax.validation.constraints.*;

import java.io.Serializable;
import java.util.Objects;

import com.onyx.app.domain.enumeration.BulkSaleType;

import static com.onyx.app.config.Constants.ID_DELIMITER;
import static org.springframework.data.couchbase.core.mapping.id.GenerationStrategy.UNIQUE;

/**
 * A InventoryBulkPrice.
 */
@Document
public class InventoryBulkPrice implements Serializable {

    private static final long serialVersionUID = 1L;
    public static final String PREFIX = "inventorybulkprice";

    @SuppressWarnings("unused")
    @IdPrefix
    private String prefix = PREFIX;

    @Id
    @GeneratedValue(strategy = UNIQUE, delimiter = ID_DELIMITER)
    private String id;

//    @Size(max = 25)
//    @Field("item_num")
//    private String itemNum;
//
//    @Size(max = 50)
//    @Field("item_name")
//    private String itemName;

    @Field("sale_price")
    private Double salePrice;

    @Field("sale_percent")
    private Double salePercent;

    @Field("type")
    private BulkSaleType type;

    @Field("store_id")
    private Integer storeId;

    @Size(max = 25)
    @Field("bulk_sale_id")
    private String bulkSaleId;

    @NotNull
    @Field("qty")
    private Integer qty;

    @Field("active")
    private Boolean active;

//    private Inventory inventory;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

//    public String getItemNum() {
//        return itemNum;
//    }
//
//    public InventoryBulkPrice itemNum(String itemNum) {
//        this.itemNum = itemNum;
//        return this;
//    }
//
//    public void setItemNum(String itemNum) {
//        this.itemNum = itemNum;
//    }
//
//    public String getItemName() {
//        return itemName;
//    }
//
//    public InventoryBulkPrice itemName(String itemName) {
//        this.itemName = itemName;
//        return this;
//    }
//
//    public void setItemName(String itemName) {
//        this.itemName = itemName;
//    }


//    public Inventory getInventory() {
//        return inventory;
//    }
//
//    public void setInventory(Inventory inventory) {
//        this.inventory = inventory;
//    }

    public Double getSalePrice() {
        return salePrice;
    }

    public InventoryBulkPrice salePrice(Double salePrice) {
        this.salePrice = salePrice;
        return this;
    }

    public void setSalePrice(Double salePrice) {
        this.salePrice = salePrice;
    }

    public Double getSalePercent() {
        return salePercent;
    }

    public InventoryBulkPrice salePercent(Double salePercent) {
        this.salePercent = salePercent;
        return this;
    }

    public void setSalePercent(Double salePercent) {
        this.salePercent = salePercent;
    }

    public BulkSaleType getType() {
        return type;
    }

    public InventoryBulkPrice type(BulkSaleType type) {
        this.type = type;
        return this;
    }

    public void setType(BulkSaleType type) {
        this.type = type;
    }

    public Integer getStoreId() {
        return storeId;
    }

    public InventoryBulkPrice storeId(Integer storeId) {
        this.storeId = storeId;
        return this;
    }

    public void setStoreId(Integer storeId) {
        this.storeId = storeId;
    }

    public String getBulkSaleId() {
        return bulkSaleId;
    }

    public InventoryBulkPrice bulkSaleId(String bulkSaleId) {
        this.bulkSaleId = bulkSaleId;
        return this;
    }

    public void setBulkSaleId(String bulkSaleId) {
        this.bulkSaleId = bulkSaleId;
    }

    public Integer getQty() {
        return qty;
    }

    public InventoryBulkPrice qty(Integer qty) {
        this.qty = qty;
        return this;
    }

    public void setQty(Integer qty) {
        this.qty = qty;
    }

    public Boolean isActive() {
        return active;
    }

    public InventoryBulkPrice active(Boolean active) {
        this.active = active;
        return this;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        InventoryBulkPrice inventoryBulkPrice = (InventoryBulkPrice) o;
        if (inventoryBulkPrice.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), inventoryBulkPrice.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "InventoryBulkPrice{" +
            "id=" + getId() +
//            ", itemNum='" + getItemNum() + "'" +
//            ", itemName='" + getItemName() + "'" +
            ", salePrice=" + getSalePrice() +
            ", salePercent=" + getSalePercent() +
            ", type='" + getType() + "'" +
            ", storeId=" + getStoreId() +
            ", bulkSaleId='" + getBulkSaleId() + "'" +
            ", qty=" + getQty() +
            ", active='" + isActive() + "'" +
            "}";
    }
}
