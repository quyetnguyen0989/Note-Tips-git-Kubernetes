package com.onyx.app.web.rest;

import com.codahale.metrics.annotation.Timed;
import com.onyx.app.service.InventoryBulkPriceService;
import com.onyx.app.web.rest.errors.BadRequestAlertException;
import com.onyx.app.web.rest.util.HeaderUtil;
import com.onyx.app.service.dto.InventoryBulkPriceDTO;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;

import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing InventoryBulkPrice.
 */
@RestController
@RequestMapping("/api")
public class InventoryBulkPriceResource {

    private final Logger log = LoggerFactory.getLogger(InventoryBulkPriceResource.class);

    private static final String ENTITY_NAME = "inventoryBulkPrice";

    private final InventoryBulkPriceService inventoryBulkPriceService;

    public InventoryBulkPriceResource(InventoryBulkPriceService inventoryBulkPriceService) {
        this.inventoryBulkPriceService = inventoryBulkPriceService;
    }

    /**
     * POST  /inventory-bulk-prices : Create a new inventoryBulkPrice.
     *
     * @param inventoryBulkPriceDTO the inventoryBulkPriceDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new inventoryBulkPriceDTO, or with status 400 (Bad Request) if the inventoryBulkPrice has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/inventory-bulk-prices")
    @Timed
    public ResponseEntity<InventoryBulkPriceDTO> createInventoryBulkPrice(@Valid @RequestBody InventoryBulkPriceDTO inventoryBulkPriceDTO) throws URISyntaxException {
        log.debug("REST request to save InventoryBulkPrice : {}", inventoryBulkPriceDTO);
        if (inventoryBulkPriceDTO.getId() != null) {
            throw new BadRequestAlertException("A new inventoryBulkPrice cannot already have an ID", ENTITY_NAME, "idexists");
        }
        InventoryBulkPriceDTO result = inventoryBulkPriceService.save(inventoryBulkPriceDTO);
        return ResponseEntity.created(new URI("/api/inventory-bulk-prices/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /inventory-bulk-prices : Updates an existing inventoryBulkPrice.
     *
     * @param inventoryBulkPriceDTO the inventoryBulkPriceDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated inventoryBulkPriceDTO,
     * or with status 400 (Bad Request) if the inventoryBulkPriceDTO is not valid,
     * or with status 500 (Internal Server Error) if the inventoryBulkPriceDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/inventory-bulk-prices")
    @Timed
    public ResponseEntity<InventoryBulkPriceDTO> updateInventoryBulkPrice(@Valid @RequestBody InventoryBulkPriceDTO inventoryBulkPriceDTO) throws URISyntaxException {
        log.debug("REST request to update InventoryBulkPrice : {}", inventoryBulkPriceDTO);
        if (inventoryBulkPriceDTO.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        InventoryBulkPriceDTO result = inventoryBulkPriceService.save(inventoryBulkPriceDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, inventoryBulkPriceDTO.getId().toString()))
            .body(result);
    }

    /**
     * GET  /inventory-bulk-prices : get all the inventoryBulkPrices.
     *
     * @return the ResponseEntity with status 200 (OK) and the list of inventoryBulkPrices in body
     */
    @GetMapping("/inventory-bulk-prices")
    @Timed
    public List<InventoryBulkPriceDTO> getAllInventoryBulkPrices() {
        log.debug("REST request to get all InventoryBulkPrices");
        return inventoryBulkPriceService.findAll();
    }

    /**
     * GET  /inventory-bulk-prices/:id : get the "id" inventoryBulkPrice.
     *
     * @param id the id of the inventoryBulkPriceDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the inventoryBulkPriceDTO, or with status 404 (Not Found)
     */
    @GetMapping("/inventory-bulk-prices/{id}")
    @Timed
    public ResponseEntity<InventoryBulkPriceDTO> getInventoryBulkPrice(@PathVariable String id) {
        log.debug("REST request to get InventoryBulkPrice : {}", id);
        Optional<InventoryBulkPriceDTO> inventoryBulkPriceDTO = inventoryBulkPriceService.findOne(id);
        return ResponseUtil.wrapOrNotFound(inventoryBulkPriceDTO);
    }

    /**
     * DELETE  /inventory-bulk-prices/:id : delete the "id" inventoryBulkPrice.
     *
     * @param id the id of the inventoryBulkPriceDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/inventory-bulk-prices/{id}")
    @Timed
    public ResponseEntity<Void> deleteInventoryBulkPrice(@PathVariable String id) {
        log.debug("REST request to delete InventoryBulkPrice : {}", id);
        inventoryBulkPriceService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id)).build();
    }
}
