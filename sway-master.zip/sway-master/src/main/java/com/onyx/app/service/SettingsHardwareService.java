package com.onyx.app.service;

import com.onyx.app.service.dto.SettingsHardwareDTO;

import java.util.List;
import java.util.Optional;

/**
 * Service Interface for managing SettingsHardware.
 */
public interface SettingsHardwareService {

    /**
     * Save a settingsHardware.
     *
     * @param settingsHardwareDTO the entity to save
     * @return the persisted entity
     */
    SettingsHardwareDTO save(SettingsHardwareDTO settingsHardwareDTO);

    /**
     * Get all the settingsHardwares.
     *
     * @return the list of entities
     */
    List<SettingsHardwareDTO> findAll();


    /**
     * Get the "id" settingsHardware.
     *
     * @param id the id of the entity
     * @return the entity
     */
    Optional<SettingsHardwareDTO> findOne(String id);

    /**
     * Delete the "id" settingsHardware.
     *
     * @param id the id of the entity
     */
    void delete(String id);
}
