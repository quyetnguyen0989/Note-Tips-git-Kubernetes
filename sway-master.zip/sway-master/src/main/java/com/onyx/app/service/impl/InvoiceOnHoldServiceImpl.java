package com.onyx.app.service.impl;

import com.onyx.app.service.InvoiceOnHoldService;
import com.onyx.app.domain.InvoiceOnHold;
import com.onyx.app.repository.InvoiceOnHoldRepository;
import com.onyx.app.service.dto.InvoiceOnHoldDTO;
import com.onyx.app.service.mapper.InvoiceOnHoldMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.stereotype.Service;

import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
/**
 * Service Implementation for managing InvoiceOnHold.
 */
@Service
public class InvoiceOnHoldServiceImpl implements InvoiceOnHoldService {

    private final Logger log = LoggerFactory.getLogger(InvoiceOnHoldServiceImpl.class);

    private final InvoiceOnHoldRepository invoiceOnHoldRepository;

    private final InvoiceOnHoldMapper invoiceOnHoldMapper;

    public InvoiceOnHoldServiceImpl(InvoiceOnHoldRepository invoiceOnHoldRepository, InvoiceOnHoldMapper invoiceOnHoldMapper) {
        this.invoiceOnHoldRepository = invoiceOnHoldRepository;
        this.invoiceOnHoldMapper = invoiceOnHoldMapper;
    }

    /**
     * Save a invoiceOnHold.
     *
     * @param invoiceOnHoldDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public InvoiceOnHoldDTO save(InvoiceOnHoldDTO invoiceOnHoldDTO) {
        log.debug("Request to save InvoiceOnHold : {}", invoiceOnHoldDTO);
        InvoiceOnHold invoiceOnHold = invoiceOnHoldMapper.toEntity(invoiceOnHoldDTO);
        invoiceOnHold = invoiceOnHoldRepository.save(invoiceOnHold);
        return invoiceOnHoldMapper.toDto(invoiceOnHold);
    }

    /**
     * Get all the invoiceOnHolds.
     *
     * @return the list of entities
     */
    @Override
    public List<InvoiceOnHoldDTO> findAll() {
        log.debug("Request to get all InvoiceOnHolds");
        return invoiceOnHoldRepository.findAll().stream()
            .map(invoiceOnHoldMapper::toDto)
            .collect(Collectors.toCollection(LinkedList::new));
    }


    /**
     * Get one invoiceOnHold by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    public Optional<InvoiceOnHoldDTO> findOne(String id) {
        log.debug("Request to get InvoiceOnHold : {}", id);
        return invoiceOnHoldRepository.findById(id)
            .map(invoiceOnHoldMapper::toDto);
    }

    /**
     * Delete the invoiceOnHold by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(String id) {
        log.debug("Request to delete InvoiceOnHold : {}", id);
        invoiceOnHoldRepository.deleteById(id);
    }
}
