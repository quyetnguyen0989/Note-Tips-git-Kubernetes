package com.onyx.app.service;

import com.onyx.app.service.dto.CustomerTrxDTO;

import java.util.List;
import java.util.Optional;

/**
 * Service Interface for managing CustomerTrx.
 */
public interface CustomerTrxService {

    /**
     * Save a customerTrx.
     *
     * @param customerTrxDTO the entity to save
     * @return the persisted entity
     */
    CustomerTrxDTO save(CustomerTrxDTO customerTrxDTO);

    /**
     * Get all the customerTrxes.
     *
     * @return the list of entities
     */
    List<CustomerTrxDTO> findAll();


    /**
     * Get the "id" customerTrx.
     *
     * @param id the id of the entity
     * @return the entity
     */
    Optional<CustomerTrxDTO> findOne(String id);

    /**
     * Delete the "id" customerTrx.
     *
     * @param id the id of the entity
     */
    void delete(String id);
}
