package com.onyx.app.service.mapper;

import com.onyx.app.domain.*;
import com.onyx.app.service.dto.CTrxDTO;

import org.mapstruct.*;

/**
 * Mapper for the entity CTrx and its DTO CTrxDTO.
 */
@Mapper(componentModel = "spring", uses = {})
public interface CTrxMapper extends EntityMapper<CTrxDTO, CTrx> {


}
