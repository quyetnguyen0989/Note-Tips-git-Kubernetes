package com.onyx.app.service.mapper;

import com.onyx.app.domain.*;
import com.onyx.app.service.dto.InventoryExpDTO;

import org.mapstruct.*;

/**
 * Mapper for the entity InventoryExp and its DTO InventoryExpDTO.
 */
@Mapper(componentModel = "spring", uses = {})
public interface InventoryExpMapper extends EntityMapper<InventoryExpDTO, InventoryExp> {


}
