package com.onyx.app.domain;

import org.springframework.data.annotation.Id;
import com.couchbase.client.java.repository.annotation.Field;
import org.springframework.data.couchbase.core.mapping.Document;

import java.io.Serializable;
import java.util.Objects;

/**
 * A CustomerTrx.
 */
@Document
public class CustomerTrx implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    private String id;

    @Field("cust_num")
    private Integer custNum;

    @Field("inv_num")
    private Integer invNum;

    @Field("store_id")
    private Integer storeId;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getCustNum() {
        return custNum;
    }

    public CustomerTrx custNum(Integer custNum) {
        this.custNum = custNum;
        return this;
    }

    public void setCustNum(Integer custNum) {
        this.custNum = custNum;
    }

    public Integer getInvNum() {
        return invNum;
    }

    public CustomerTrx invNum(Integer invNum) {
        this.invNum = invNum;
        return this;
    }

    public void setInvNum(Integer invNum) {
        this.invNum = invNum;
    }

    public Integer getStoreId() {
        return storeId;
    }

    public CustomerTrx storeId(Integer storeId) {
        this.storeId = storeId;
        return this;
    }

    public void setStoreId(Integer storeId) {
        this.storeId = storeId;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        CustomerTrx customerTrx = (CustomerTrx) o;
        if (customerTrx.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), customerTrx.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "CustomerTrx{" +
            "id=" + getId() +
            ", custNum=" + getCustNum() +
            ", invNum=" + getInvNum() +
            ", storeId=" + getStoreId() +
            "}";
    }
}
