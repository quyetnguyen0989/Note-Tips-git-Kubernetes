package com.onyx.app.service;

import com.onyx.app.service.dto.InventoryBulkPriceDTO;

import java.util.List;
import java.util.Optional;

/**
 * Service Interface for managing InventoryBulkPrice.
 */
public interface InventoryBulkPriceService {

    /**
     * Save a inventoryBulkPrice.
     *
     * @param inventoryBulkPriceDTO the entity to save
     * @return the persisted entity
     */
    InventoryBulkPriceDTO save(InventoryBulkPriceDTO inventoryBulkPriceDTO);

    /**
     * Get all the inventoryBulkPrices.
     *
     * @return the list of entities
     */
    List<InventoryBulkPriceDTO> findAll();


    /**
     * Get the "id" inventoryBulkPrice.
     *
     * @param id the id of the entity
     * @return the entity
     */
    Optional<InventoryBulkPriceDTO> findOne(String id);

    /**
     * Delete the "id" inventoryBulkPrice.
     *
     * @param id the id of the entity
     */
    void delete(String id);
}
