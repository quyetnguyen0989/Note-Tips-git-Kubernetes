package com.onyx.app.service.impl;

import com.onyx.app.service.InventoryExpService;
import com.onyx.app.domain.InventoryExp;
import com.onyx.app.repository.InventoryExpRepository;
import com.onyx.app.service.dto.InventoryExpDTO;
import com.onyx.app.service.mapper.InventoryExpMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.stereotype.Service;

import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
/**
 * Service Implementation for managing InventoryExp.
 */
@Service
public class InventoryExpServiceImpl implements InventoryExpService {

    private final Logger log = LoggerFactory.getLogger(InventoryExpServiceImpl.class);

    private final InventoryExpRepository inventoryExpRepository;

    private final InventoryExpMapper inventoryExpMapper;

    public InventoryExpServiceImpl(InventoryExpRepository inventoryExpRepository, InventoryExpMapper inventoryExpMapper) {
        this.inventoryExpRepository = inventoryExpRepository;
        this.inventoryExpMapper = inventoryExpMapper;
    }

    /**
     * Save a inventoryExp.
     *
     * @param inventoryExpDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public InventoryExpDTO save(InventoryExpDTO inventoryExpDTO) {
        log.debug("Request to save InventoryExp : {}", inventoryExpDTO);
        InventoryExp inventoryExp = inventoryExpMapper.toEntity(inventoryExpDTO);
        inventoryExp = inventoryExpRepository.save(inventoryExp);
        return inventoryExpMapper.toDto(inventoryExp);
    }

    /**
     * Get all the inventoryExps.
     *
     * @return the list of entities
     */
    @Override
    public List<InventoryExpDTO> findAll() {
        log.debug("Request to get all InventoryExps");
        return inventoryExpRepository.findAll().stream()
            .map(inventoryExpMapper::toDto)
            .collect(Collectors.toCollection(LinkedList::new));
    }


    /**
     * Get one inventoryExp by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    public Optional<InventoryExpDTO> findOne(String id) {
        log.debug("Request to get InventoryExp : {}", id);
        return inventoryExpRepository.findById(id)
            .map(inventoryExpMapper::toDto);
    }

    /**
     * Delete the inventoryExp by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(String id) {
        log.debug("Request to delete InventoryExp : {}", id);
        inventoryExpRepository.deleteById(id);
    }
}
