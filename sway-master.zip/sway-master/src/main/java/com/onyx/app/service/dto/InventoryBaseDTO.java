package com.onyx.app.service.dto;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.Objects;

/**
 * A DTO for the Inventory entity.
 */
public class InventoryBaseDTO implements Serializable {

    private String id;
    private Integer itemNum;
    private String sizeList;
    @Size(max = 25)
    private String brand;
    @Size(max = 25)
    private String family;
    @Size(max = 25)
    private String subFamily;
    @Size(max = 50)
    private String itemName;
    @NotNull
    private Double itemPrice;
    private Double stock;
    private String vendorName;
    @Size(max = 10)
    private String itemType;
    private Boolean useBulk;
    // private Double cost;


    // private Double minPrice;

    private String deptName;


    public String getDeptName() {
        return deptName;
    }

    public void setDeptName(String deptName) {
        this.deptName = deptName;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getItemNum() {
        return itemNum;
    }

    public void setItemNum(Integer itemNum) {
        this.itemNum = itemNum;
    }

    public String getSizeList() {
        return sizeList;
    }

    public void setSizeList(String sizeList) {
        this.sizeList = sizeList;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getFamily() {
        return family;
    }

    public void setFamily(String family) {
        this.family = family;
    }

    public String getSubFamily() {
        return subFamily;
    }

    public void setSubFamily(String subFamily) {
        this.subFamily = subFamily;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public Double getItemPrice() {
        return itemPrice;
    }

    public void setItemPrice(Double itemPrice) {
        this.itemPrice = itemPrice;
    }

    public Double getStock() {
        return stock;
    }

    public void setStock(Double stock) {
        this.stock = stock;
    }

    public String getVendorName() {
        return vendorName;
    }

    public void setVendorName(String vendorName) {
        this.vendorName = vendorName;
    }

    public String getItemType() {
        return itemType;
    }

    public void setItemType(String itemType) {
        this.itemType = itemType;
    }

    public Boolean getUseBulk() {
        return useBulk;
    }

    public void setUseBulk(Boolean useBulk) {
        this.useBulk = useBulk;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof InventoryBaseDTO)) return false;
        InventoryBaseDTO that = (InventoryBaseDTO) o;
        return Objects.equals(id, that.id) &&
            Objects.equals(itemNum, that.itemNum) &&
            Objects.equals(sizeList, that.sizeList) &&
            Objects.equals(brand, that.brand) &&
            Objects.equals(family, that.family) &&
            Objects.equals(subFamily, that.subFamily) &&
            Objects.equals(itemName, that.itemName) &&
            Objects.equals(itemPrice, that.itemPrice) &&
            Objects.equals(stock, that.stock) &&
            Objects.equals(vendorName, that.vendorName) &&
            Objects.equals(itemType, that.itemType) &&
            Objects.equals(useBulk, that.useBulk);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, itemNum, sizeList, brand, family, subFamily, itemName, itemPrice, stock, vendorName, itemType, useBulk);
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("InventoryBaseDTO{");
        sb.append("id='").append(id).append('\'');
        sb.append(", itemNum=").append(itemNum);
        sb.append(", sizeList='").append(sizeList).append('\'');
        sb.append(", brand='").append(brand).append('\'');
        sb.append(", family='").append(family).append('\'');
        sb.append(", subFamily='").append(subFamily).append('\'');
        sb.append(", itemName='").append(itemName).append('\'');
        sb.append(", itemPrice=").append(itemPrice);
        sb.append(", stock=").append(stock);
        sb.append(", vendorName='").append(vendorName).append('\'');
        sb.append(", itemType='").append(itemType).append('\'');
        sb.append(", useBulk=").append(useBulk);
        sb.append('}');
        return sb.toString();
    }
}
