package com.onyx.app.service.dto;

import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.Objects;

/**
 * A DTO for the SubFamily entity.
 */
public class SubFamilyDTO implements Serializable {

    private String id;

    private Integer familyId;

    private Integer subFamilyId;

    private String subFamilyName;

    @NotNull
    private Integer storeId;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getFamilyId() {
        return familyId;
    }

    public void setFamilyId(Integer familyId) {
        this.familyId = familyId;
    }

    public Integer getSubFamilyId() {
        return subFamilyId;
    }

    public void setSubFamilyId(Integer subFamilyId) {
        this.subFamilyId = subFamilyId;
    }

    public String getSubFamilyName() {
        return subFamilyName;
    }

    public void setSubFamilyName(String subFamilyName) {
        this.subFamilyName = subFamilyName;
    }

    public Integer getStoreId() {
        return storeId;
    }

    public void setStoreId(Integer storeId) {
        this.storeId = storeId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        SubFamilyDTO subFamilyDTO = (SubFamilyDTO) o;
        if (subFamilyDTO.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), subFamilyDTO.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "SubFamilyDTO{" +
            "id=" + getId() +
            ", familyId=" + getFamilyId() +
            ", subFamilyId=" + getSubFamilyId() +
            ", subFamilyName='" + getSubFamilyName() + "'" +
            ", storeId=" + getStoreId() +
            "}";
    }
}
