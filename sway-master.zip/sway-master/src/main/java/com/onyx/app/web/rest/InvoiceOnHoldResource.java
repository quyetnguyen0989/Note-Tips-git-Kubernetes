package com.onyx.app.web.rest;

import com.codahale.metrics.annotation.Timed;
import com.onyx.app.service.InvoiceOnHoldService;
import com.onyx.app.web.rest.errors.BadRequestAlertException;
import com.onyx.app.web.rest.util.HeaderUtil;
import com.onyx.app.service.dto.InvoiceOnHoldDTO;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;

import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing InvoiceOnHold.
 */
@RestController
@RequestMapping("/api")
public class InvoiceOnHoldResource {

    private final Logger log = LoggerFactory.getLogger(InvoiceOnHoldResource.class);

    private static final String ENTITY_NAME = "invoiceOnHold";

    private final InvoiceOnHoldService invoiceOnHoldService;

    public InvoiceOnHoldResource(InvoiceOnHoldService invoiceOnHoldService) {
        this.invoiceOnHoldService = invoiceOnHoldService;
    }

    /**
     * POST  /invoice-on-holds : Create a new invoiceOnHold.
     *
     * @param invoiceOnHoldDTO the invoiceOnHoldDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new invoiceOnHoldDTO, or with status 400 (Bad Request) if the invoiceOnHold has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/invoice-on-holds")
    @Timed
    public ResponseEntity<InvoiceOnHoldDTO> createInvoiceOnHold(@Valid @RequestBody InvoiceOnHoldDTO invoiceOnHoldDTO) throws URISyntaxException {
        log.debug("REST request to save InvoiceOnHold : {}", invoiceOnHoldDTO);
        if (invoiceOnHoldDTO.getId() != null) {
            throw new BadRequestAlertException("A new invoiceOnHold cannot already have an ID", ENTITY_NAME, "idexists");
        }
        InvoiceOnHoldDTO result = invoiceOnHoldService.save(invoiceOnHoldDTO);
        return ResponseEntity.created(new URI("/api/invoice-on-holds/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /invoice-on-holds : Updates an existing invoiceOnHold.
     *
     * @param invoiceOnHoldDTO the invoiceOnHoldDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated invoiceOnHoldDTO,
     * or with status 400 (Bad Request) if the invoiceOnHoldDTO is not valid,
     * or with status 500 (Internal Server Error) if the invoiceOnHoldDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/invoice-on-holds")
    @Timed
    public ResponseEntity<InvoiceOnHoldDTO> updateInvoiceOnHold(@Valid @RequestBody InvoiceOnHoldDTO invoiceOnHoldDTO) throws URISyntaxException {
        log.debug("REST request to update InvoiceOnHold : {}", invoiceOnHoldDTO);
        if (invoiceOnHoldDTO.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        InvoiceOnHoldDTO result = invoiceOnHoldService.save(invoiceOnHoldDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, invoiceOnHoldDTO.getId().toString()))
            .body(result);
    }

    /**
     * GET  /invoice-on-holds : get all the invoiceOnHolds.
     *
     * @return the ResponseEntity with status 200 (OK) and the list of invoiceOnHolds in body
     */
    @GetMapping("/invoice-on-holds")
    @Timed
    public List<InvoiceOnHoldDTO> getAllInvoiceOnHolds() {
        log.debug("REST request to get all InvoiceOnHolds");
        return invoiceOnHoldService.findAll();
    }

    /**
     * GET  /invoice-on-holds/:id : get the "id" invoiceOnHold.
     *
     * @param id the id of the invoiceOnHoldDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the invoiceOnHoldDTO, or with status 404 (Not Found)
     */
    @GetMapping("/invoice-on-holds/{id}")
    @Timed
    public ResponseEntity<InvoiceOnHoldDTO> getInvoiceOnHold(@PathVariable String id) {
        log.debug("REST request to get InvoiceOnHold : {}", id);
        Optional<InvoiceOnHoldDTO> invoiceOnHoldDTO = invoiceOnHoldService.findOne(id);
        return ResponseUtil.wrapOrNotFound(invoiceOnHoldDTO);
    }

    /**
     * DELETE  /invoice-on-holds/:id : delete the "id" invoiceOnHold.
     *
     * @param id the id of the invoiceOnHoldDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/invoice-on-holds/{id}")
    @Timed
    public ResponseEntity<Void> deleteInvoiceOnHold(@PathVariable String id) {
        log.debug("REST request to delete InvoiceOnHold : {}", id);
        invoiceOnHoldService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id)).build();
    }
}
