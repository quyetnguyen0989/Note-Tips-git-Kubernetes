package com.onyx.app.repository;

import com.onyx.app.domain.CustomerInfo;
import org.springframework.stereotype.Repository;

/**
 * Spring Data Couchbase repository for the CustomerInfo entity.
 */
@SuppressWarnings("unused")
@Repository
public interface CustomerInfoRepository extends N1qlCouchbaseRepository<CustomerInfo, String> {

}
