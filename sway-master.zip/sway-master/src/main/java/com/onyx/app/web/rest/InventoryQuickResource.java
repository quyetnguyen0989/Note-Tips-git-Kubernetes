package com.onyx.app.web.rest;

import com.codahale.metrics.annotation.Timed;
import com.onyx.app.domain.Inventory;
import com.onyx.app.repository.InventoryRepository;
import com.onyx.app.service.InventoryService;
import com.onyx.app.service.dto.InventoryQuick;
import com.onyx.app.service.mapper.InventoryQuickMapper;
import com.onyx.app.web.rest.errors.BadRequestAlertException;
import com.onyx.app.web.rest.util.HeaderUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;


@RestController
@RequestMapping("/api")
public class InventoryQuickResource {

    private final Logger log = LoggerFactory.getLogger(InventoryQuickResource.class);

    @Autowired
    private InventoryRepository inventoryRepository;

    @Autowired
    private InventoryQuickMapper inventoryQuickMapper;

    @Autowired
    private InventoryService inventoryService;

    private static final String ENTITY_NAME = "inventory";

    /**
     * POST  /inventory-quick : Create a new inventory.
     *
     * @param inventoryQuick the inventoryQuick to create
     * @return the ResponseEntity with status 201 (Created) and with body the new inventoryQuick, or with status 400 (Bad Request) if the inventory has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/inventory-quick")
    @Timed
    public ResponseEntity<?> createInventory(@Valid @RequestBody InventoryQuick inventoryQuick) throws URISyntaxException {
        log.debug("REST request to save Inventory : {}" , inventoryQuick);
        if (inventoryQuick.getId() != null) {
            throw new BadRequestAlertException("A new inventory cannot already have an ID", ENTITY_NAME, "idexists");
        }

        Inventory inventory = inventoryQuickMapper.toEntity(inventoryQuick);
        Inventory result = inventoryRepository.save(inventory);
        return ResponseEntity.created(new URI("/api/inventory-quick/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * POST /multiple-inventory-quick : Create multiple of inventory
     *
     * @param inventoryQuicks the list of inventories to create
     */
    @PostMapping("/multiple-inventory-quick")
    @Timed
    public ResponseEntity<?> createListOfInventories(@RequestBody List<InventoryQuick> inventoryQuicks){
        List<Inventory> inventories = new ArrayList<>();
        inventoryQuicks.stream().forEach(inventoryQuick -> {
            try {

                Inventory inventory = inventoryQuickMapper.toEntity(inventoryQuick);
                Inventory result = inventoryRepository.save(inventory);
                if (result != null) {
                    log.info("-------------------> " + result.toString());
                    inventories.add(result);
                }

            }catch (Exception e){
                log.error(e.getMessage());
            }
        });
        return new ResponseEntity<>(inventories , HttpStatus.OK);
    }


    /**
     * PUT  /inventory-quick : Updates an existing inventory.
     *
     * @param inventoryQuick the inventoryQuick to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated inventoryQuick,
     * or with status 400 (Bad Request) if the inventoryQuick is not valid,
     * or with status 500 (Internal Server Error) if the inventoryQuick couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/inventory-quick")
    @Timed
    public ResponseEntity<?> updateInventory(@Valid @RequestBody InventoryQuick inventoryQuick){
        log.debug("REST request to save Inventory : {}" , inventoryQuick);
        if (inventoryQuick.getId() == null) {
            throw new BadRequestAlertException("Invalid ID", ENTITY_NAME, "idexists");
        }

        Inventory inventory = inventoryQuickMapper.toEntity(inventoryQuick);
        Inventory result = inventoryRepository.save(inventory);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, inventoryQuick.getId().toString()))
            .body(result);
    }

    /**
     * GET  /inventory-quick : get all the inventories.
     *
     * @return the ResponseEntity with status 200 (OK) and the list of inventoryQuick in body
     */
    @GetMapping("/inventory-quick")
    @Timed
    public List<InventoryQuick> getAllInventories() {
        log.debug("REST request to get all Inventories");
        List<InventoryQuick> inventoryQuicks = inventoryQuickMapper.toDto(inventoryRepository.findAll());
        return inventoryQuicks;
    }

    /**
     * GET  /inventory-quick/:id : get the "id" inventory.
     *
     * @param id the id of the inventoryQuick to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the inventoryQuick, or with status 404 (Not Found)
     */
    @GetMapping("/inventory-quick/{id}")
    @Timed
    public ResponseEntity<?> getInventory(@PathVariable String id) {
        log.debug("REST request to get Inventory : {}", id);
        InventoryQuick inventoryQuick = inventoryQuickMapper.toDto(inventoryRepository.findById(id).get());
        return new ResponseEntity<InventoryQuick>(inventoryQuick, HttpStatus.OK);
    }

    /**
     * GET  /inventory-quick-store-dept/:store_id/:dept_id : get the inventory by StoreId and DeptId.
     *
     * @param store_id and dept_id of the inventoryQuick to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the inventoryQuick, or with status 404 (Not Found)
     */
//    @GetMapping("/inventory-quick-store-dept/{store_id}/{dept_id}")
//    @Timed
//    public ResponseEntity<List<InventoryQuick>> getInventoryByStoreIdAndDeptId(@PathVariable Integer store_id, @PathVariable Integer dept_id){
//        log.debug("REST request to get Inventory : {}");
//        List<InventoryQuick> inventoryQuicks = inventoryQuickMapper.toDto(inventoryRepository.findAllByStoreidAndDeptid(store_id,dept_id));
//        return new ResponseEntity<>(inventoryQuicks , HttpStatus.OK);
//    }

    /**
     * DELETE  /inventory-quick/:id : delete the "id" inventory.
     *
     * @param id the id of the inventoryQuick to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/inventory-quick/{id}")
    @Timed
    public ResponseEntity<Void> deleteInventory(@PathVariable String id) {
        log.debug("REST request to delete Inventory : {}", id);
        inventoryService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id)).build();
    }

}
