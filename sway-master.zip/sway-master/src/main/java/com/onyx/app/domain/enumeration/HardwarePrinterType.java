package com.onyx.app.domain.enumeration;

/**
 * The HardwarePrinterType enumeration.
 */
public enum HardwarePrinterType {
    EPSON, STAR, BIXILON
}
