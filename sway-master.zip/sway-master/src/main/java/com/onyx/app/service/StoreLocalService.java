package com.onyx.app.service;

import com.onyx.app.service.dto.StoreLocalDTO;

import java.util.List;
import java.util.Optional;

/**
 * Service Interface for managing StoreLocal.
 */
public interface StoreLocalService {

    /**
     * Save a storeLocal.
     *
     * @param storeLocalDTO the entity to save
     * @return the persisted entity
     */
    StoreLocalDTO save(StoreLocalDTO storeLocalDTO);

    /**
     * Get all the storeLocals.
     *
     * @return the list of entities
     */
    List<StoreLocalDTO> findAll();


    /**
     * Get the "id" storeLocal.
     *
     * @param id the id of the entity
     * @return the entity
     */
    Optional<StoreLocalDTO> findOne(String id);

    /**
     * Delete the "id" storeLocal.
     *
     * @param id the id of the entity
     */
    void delete(String id);
}
