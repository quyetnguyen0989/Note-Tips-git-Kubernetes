package com.onyx.app.service.dto;

import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.Objects;

/**
 * A DTO for the Dept entity.
 */
public class DeptDTO implements Serializable {

    private String id;

    @Size(max = 20)
    private String deptId;

    @Size(max = 20)
    private String deptName;

    private Integer categoryId;

    private Integer storeId;

    private String imgUrl;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDeptId() {
        return deptId;
    }

    public void setDeptId(String deptId) {
        this.deptId = deptId;
    }

    public String getDeptName() {
        return deptName;
    }

    public void setDeptName(String deptName) {
        this.deptName = deptName;
    }

    public Integer getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(Integer categoryId) {
        this.categoryId = categoryId;
    }

    public Integer getStoreId() {
        return storeId;
    }

    public void setStoreId(Integer storeId) {
        this.storeId = storeId;
    }

    public String getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        DeptDTO deptDTO = (DeptDTO) o;
        if (deptDTO.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), deptDTO.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "DeptDTO{" +
            "id=" + getId() +
            ", deptId='" + getDeptId() + "'" +
            ", deptName='" + getDeptName() + "'" +
            ", categoryId=" + getCategoryId() +
            ", storeId=" + getStoreId() +
            ", imgUrl='" + getImgUrl() + "'" +
            "}";
    }
}
