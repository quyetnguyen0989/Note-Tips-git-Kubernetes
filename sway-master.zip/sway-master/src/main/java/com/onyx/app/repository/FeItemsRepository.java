package com.onyx.app.repository;

import com.onyx.app.domain.FeItems;
import com.onyx.app.service.dto.FeItemsDTO;

import org.springframework.data.couchbase.core.query.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Spring Data Couchbase repository for the FeItems entity.
 */
@SuppressWarnings("unused")
@Repository
public interface FeItemsRepository extends N1qlCouchbaseRepository<FeItems, String> {

//    @Query(" SELECT * as null  FROM  onyxapp WHERE storeId = $1 AND _class = 'com.onyx.app.domain.FeItems' ")
//    List<FeItemsDTO> findAllByStoreId(Integer storeId);

    List<FeItems> findAllByStoreId(Integer storeId);
}
