package com.onyx.app.service.dto;

import com.onyx.app.domain.Brand;
import com.onyx.app.domain.Category;
import com.onyx.app.domain.Dept;
import com.onyx.app.domain.Family;
import com.onyx.app.domain.InventoryBulkPrice;
import com.onyx.app.domain.Modifier;
import com.onyx.app.domain.ModifiersGroup;
import com.onyx.app.domain.Section;
import com.onyx.app.domain.StoreLocal;
import com.onyx.app.domain.SubFamily;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.Instant;
import javax.validation.constraints.*;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * A DTO for the Inventory entity.
 */
//@Data
//@NoArgsConstructor
//@AllArgsConstructor
public class InventoryDTO implements Serializable {

	private static final long serialVersionUID = -4989532970061679209L;

	private String id;

	private Integer itemnum;

	@Size(max = 50)
	private String itemname;

	private Boolean itemhasMods;

	private Boolean itemImg;

	private Boolean itemSpcl;

	private Boolean itemOnHH;

	@NotNull
	private Double itemprice;

	private Double minprice;

	@Size(max = 10)
	private String itemtype;

	@NotNull
	private Double cost;

	private Double stock;

	private Double reorder;

	private Boolean tax1;

	private Integer vendorpartnumber;

	private Integer points;

	private Integer location;

	private Boolean autoweigh;

	private Integer numpercase;

	private Boolean foodstampable;

	private Boolean checkid;

	private Boolean askprice;

	private Boolean askquantity;

	private Boolean disabled;

	private String unitsize;

	private Boolean askdescription;

	private Boolean checkid2;

	private Boolean countitem;

	private Instant hhTimeStart;

	private Instant hhTimeEnd;

	private Double hhPrice;

	private String imgUrl;
	
	private Double hasBulkprice;

	private Double bulkpricing;

	private Integer qty;

	private Double itemSpclPrice;

	private List<String> modifiersIds ;

	private List<String> modifiersGroupsIds;

	private String brandId;
	
    private String familyId;
    
    private String subfamilyId;
    
    private String sectionId;
    
    private String storeId;
    
    private String departmentId;
    
    private String categoryId;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Integer getItemnum() {
		return itemnum;
	}

	public void setItemnum(Integer itemnum) {
		this.itemnum = itemnum;
	}

	public String getItemname() {
		return itemname;
	}

	public void setItemname(String itemname) {
		this.itemname = itemname;
	}

	public Boolean getItemhasMods() {
		return itemhasMods;
	}

	public void setItemhasMods(Boolean itemhasMods) {
		this.itemhasMods = itemhasMods;
	}

	public Boolean getItemImg() {
		return itemImg;
	}

	public void setItemImg(Boolean itemImg) {
		this.itemImg = itemImg;
	}

	public Boolean getItemSpcl() {
		return itemSpcl;
	}

	public void setItemSpcl(Boolean itemSpcl) {
		this.itemSpcl = itemSpcl;
	}

	public Boolean getItemOnHH() {
		return itemOnHH;
	}

	public void setItemOnHH(Boolean itemOnHH) {
		this.itemOnHH = itemOnHH;
	}

	public Double getItemprice() {
		return itemprice;
	}

	public void setItemprice(Double itemprice) {
		this.itemprice = itemprice;
	}

	public Double getMinprice() {
		return minprice;
	}

	public void setMinprice(Double minprice) {
		this.minprice = minprice;
	}

	public String getItemtype() {
		return itemtype;
	}

	public void setItemtype(String itemtype) {
		this.itemtype = itemtype;
	}

	public Double getCost() {
		return cost;
	}

	public void setCost(Double cost) {
		this.cost = cost;
	}

	public Double getStock() {
		return stock;
	}

	public void setStock(Double stock) {
		this.stock = stock;
	}

	public Double getReorder() {
		return reorder;
	}

	public void setReorder(Double reorder) {
		this.reorder = reorder;
	}

	public Boolean getTax1() {
		return tax1;
	}

	public void setTax1(Boolean tax1) {
		this.tax1 = tax1;
	}

	public Integer getVendorpartnumber() {
		return vendorpartnumber;
	}

	public void setVendorpartnumber(Integer vendorpartnumber) {
		this.vendorpartnumber = vendorpartnumber;
	}

	public Integer getPoints() {
		return points;
	}

	public void setPoints(Integer points) {
		this.points = points;
	}

	public Integer getLocation() {
		return location;
	}

	public void setLocation(Integer location) {
		this.location = location;
	}

	public Boolean getAutoweigh() {
		return autoweigh;
	}

	public void setAutoweigh(Boolean autoweigh) {
		this.autoweigh = autoweigh;
	}

	public Integer getNumpercase() {
		return numpercase;
	}

	public void setNumpercase(Integer numpercase) {
		this.numpercase = numpercase;
	}

	public Boolean getFoodstampable() {
		return foodstampable;
	}

	public void setFoodstampable(Boolean foodstampable) {
		this.foodstampable = foodstampable;
	}

	public Boolean getCheckid() {
		return checkid;
	}

	public void setCheckid(Boolean checkid) {
		this.checkid = checkid;
	}

	public Boolean getAskprice() {
		return askprice;
	}

	public void setAskprice(Boolean askprice) {
		this.askprice = askprice;
	}

	public Boolean getAskquantity() {
		return askquantity;
	}

	public void setAskquantity(Boolean askquantity) {
		this.askquantity = askquantity;
	}

	public Boolean getDisabled() {
		return disabled;
	}

	public void setDisabled(Boolean disabled) {
		this.disabled = disabled;
	}

	public String getUnitsize() {
		return unitsize;
	}

	public void setUnitsize(String unitsize) {
		this.unitsize = unitsize;
	}

	public Boolean getAskdescription() {
		return askdescription;
	}

	public void setAskdescription(Boolean askdescription) {
		this.askdescription = askdescription;
	}

	public Boolean getCheckid2() {
		return checkid2;
	}

	public void setCheckid2(Boolean checkid2) {
		this.checkid2 = checkid2;
	}

	public Boolean getCountitem() {
		return countitem;
	}

	public void setCountitem(Boolean countitem) {
		this.countitem = countitem;
	}

	public Instant getHhTimeStart() {
		return hhTimeStart;
	}

	public void setHhTimeStart(Instant hhTimeStart) {
		this.hhTimeStart = hhTimeStart;
	}

	public Instant getHhTimeEnd() {
		return hhTimeEnd;
	}

	public void setHhTimeEnd(Instant hhTimeEnd) {
		this.hhTimeEnd = hhTimeEnd;
	}

	public Double getHhPrice() {
		return hhPrice;
	}

	public void setHhPrice(Double hhPrice) {
		this.hhPrice = hhPrice;
	}

	public String getImgUrl() {
		return imgUrl;
	}

	public void setImgUrl(String imgUrl) {
		this.imgUrl = imgUrl;
	}

	public Double getBulkpricing() {
		return bulkpricing;
	}

	public void setBulkpricing(Double bulkpricing) {
		this.bulkpricing = bulkpricing;
	}

	public Integer getQty() {
		return qty;
	}

	public void setQty(Integer qty) {
		this.qty = qty;
	}

	public Double getItemSpclPrice() {
		return itemSpclPrice;
	}

	public void setItemSpclPrice(Double itemSpclPrice) {
		this.itemSpclPrice = itemSpclPrice;
	}

	public List<String> getModifiersIds() {
		return modifiersIds;
	}

	public void setModifiersIds(List<String> modifiersIds) {
		this.modifiersIds = modifiersIds;
	}

	public List<String> getModifiersGroupsIds() {
		return modifiersGroupsIds;
	}

	public void setModifiersGroupsIds(List<String> modifiersGroupsIds) {
		this.modifiersGroupsIds = modifiersGroupsIds;
	}

	public Double getHasBulkprice() {
		return hasBulkprice;
	}

	public void setHasBulkprice(Double hasBulkprice) {
		this.hasBulkprice = hasBulkprice;
	}

	public String getBrandId() {
		return brandId;
	}

	public void setBrandId(String brandId) {
		this.brandId = brandId;
	}

	public String getFamilyId() {
		return familyId;
	}

	public void setFamilyId(String familyId) {
		this.familyId = familyId;
	}

	public String getSubfamilyId() {
		return subfamilyId;
	}

	public void setSubfamilyId(String subfamilyId) {
		this.subfamilyId = subfamilyId;
	}

	public String getSectionId() {
		return sectionId;
	}

	public void setSectionId(String sectionId) {
		this.sectionId = sectionId;
	}

	public String getStoreId() {
		return storeId;
	}

	public void setStoreId(String storeId) {
		this.storeId = storeId;
	}

	public String getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(String departmentId) {
		this.departmentId = departmentId;
	}

	public String getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(String categoryId) {
		this.categoryId = categoryId;
	}
	
	

//
//	public Family getFamily() {
//		return family;
//	}
//
//	public void setFamily(Family family) {
//		this.family = family;
//	}
//
//	public SubFamily getSubfamily() {
//		return subfamily;
//	}
//
//	public void setSubfamily(SubFamily subfamily) {
//		this.subfamily = subfamily;
//	}
//
//	public Section getSection() {
//		return section;
//	}
//
//	public void setSection(Section section) {
//		this.section = section;
//	}
//
//	public StoreLocal getStore() {
//		return store;
//	}
//
//	public void setStore(StoreLocal store) {
//		this.store = store;
//	}
//
//	public Dept getDepartment() {
//		return department;
//	}
//
//	public void setDepartment(Dept department) {
//		this.department = department;
//	}
//
//	public Category getCategory() {
//		return category;
//	}
//
//	public void setCategory(Category category) {
//		this.category = category;
//	}

//    private String id;
//
//
//    private Integer itemnum;
//
//    @Size(max = 25)
//    private String brand;
//
//    private Integer brandId;
//
//    @Size(max = 25)
//    private String family;
//
//    private Integer familyId;
//
//    @Size(max = 25)
//    private String subfamily;
//
//    private Integer subfamilyId;
//
//    @Size(max = 25)
//    private String section;
//
//    private Integer sectionId;
//
//    @NotNull
//    private Integer itemid;
//
//    @Size(max = 50)
//    private String itemname;
//
//    @NotNull
//    private Double storeid;
//
//    @NotNull
//    private Double cost;
//
//    @NotNull
//    private Double itemprice;
//
//    private Double minprice;
//
//    private Double stock;
//
//    private Double reorder;
//
//    private Boolean tax1;
//
//    private Integer vendorpartnumber;
//
//    private Integer deptid;
//
//    private Integer points;
//
//    private Double bulkpricing;
//
//    private Integer location;
//
//    private Boolean autoweigh;
//
//    private Integer numpercase;
//
//    private Boolean foodstampable;
//
//    private Boolean checkid;
//
//    @Size(max = 10)
//    private String itemtype;
//
//    private Boolean askprice;
//
//    private Boolean askquantity;
//
//    private Boolean disabled;
//
//    private Double unitsize;
//
//    private Boolean askdescription;
//
//    private Boolean checkid2;
//
//    private Boolean countitem;
//
//    private String categoryName;
//
//    private Integer categoryId;
//
//    private Boolean itemhasMods;
//
//    private Boolean itemImg;
//
//    private Boolean itemSpcl;
//
//    private Boolean itemOnHH;
//
//    private Instant hhTimeStart;
//
//    private Instant hhTimeEnd;
//
//    private Double hhPrice;
//
//    private String imgUrl;
//
//    private Integer modifierID;
//
//    private Integer qty;
//
//    private List<Modifier> modifiers;
//
//    private Double itemSpclPrice;
//
//    public String getId() {
//        return id;
//    }
//
//    public void setId(String id) {
//        this.id = id;
//    }
//
//    public Integer getItemnum() {
//        return itemnum;
//    }
//
//    public void setItemnum(Integer itemnum) {
//        this.itemnum = itemnum;
//    }
//
//    public String getBrand() {
//        return brand;
//    }
//
//    public void setBrand(String brand) {
//        this.brand = brand;
//    }
//
//    public Integer getBrandId() {
//        return brandId;
//    }
//
//    public void setBrandId(Integer brandId) {
//        this.brandId = brandId;
//    }
//
//    public String getFamily() {
//        return family;
//    }
//
//    public void setFamily(String family) {
//        this.family = family;
//    }
//
//    public Integer getFamilyId() {
//        return familyId;
//    }
//
//    public void setFamilyId(Integer familyId) {
//        this.familyId = familyId;
//    }
//
//    public String getSubfamily() {
//        return subfamily;
//    }
//
//    public void setSubfamily(String subfamily) {
//        this.subfamily = subfamily;
//    }
//
//    public Integer getSubfamilyId() {
//        return subfamilyId;
//    }
//
//    public void setSubfamilyId(Integer subfamilyId) {
//        this.subfamilyId = subfamilyId;
//    }
//
//    public String getSection() {
//        return section;
//    }
//
//    public void setSection(String section) {
//        this.section = section;
//    }
//
//    public Integer getSectionId() {
//        return sectionId;
//    }
//
//    public void setSectionId(Integer sectionId) {
//        this.sectionId = sectionId;
//    }
//
//    public Integer getItemid() {
//        return itemid;
//    }
//
//    public void setItemid(Integer itemid) {
//        this.itemid = itemid;
//    }
//
//    public String getItemname() {
//        return itemname;
//    }
//
//    public void setItemname(String itemname) {
//        this.itemname = itemname;
//    }
//
//    public Double getStoreid() {
//        return storeid;
//    }
//
//    public void setStoreid(Double storeid) {
//        this.storeid = storeid;
//    }
//
//    public Double getCost() {
//        return cost;
//    }
//
//    public void setCost(Double cost) {
//        this.cost = cost;
//    }
//
//    public Double getItemprice() {
//        return itemprice;
//    }
//
//    public void setItemprice(Double itemprice) {
//        this.itemprice = itemprice;
//    }
//
//    public Double getMinprice() {
//        return minprice;
//    }
//
//    public void setMinprice(Double minprice) {
//        this.minprice = minprice;
//    }
//
//    public Double getStock() {
//        return stock;
//    }
//
//    public void setStock(Double stock) {
//        this.stock = stock;
//    }
//
//    public Double getReorder() {
//        return reorder;
//    }
//
//    public void setReorder(Double reorder) {
//        this.reorder = reorder;
//    }
//
//    public Boolean isTax1() {
//        return tax1;
//    }
//
//    public void setTax1(Boolean tax1) {
//        this.tax1 = tax1;
//    }
//
//    public Integer getVendorpartnumber() {
//        return vendorpartnumber;
//    }
//
//    public void setVendorpartnumber(Integer vendorpartnumber) {
//        this.vendorpartnumber = vendorpartnumber;
//    }
//
//    public Integer getDeptid() {
//        return deptid;
//    }
//
//    public void setDeptid(Integer deptid) {
//        this.deptid = deptid;
//    }
//
//    public Integer getPoints() {
//        return points;
//    }
//
//    public void setPoints(Integer points) {
//        this.points = points;
//    }
//
//    public Double getBulkpricing() {
//        return bulkpricing;
//    }
//
//    public List<Modifier> getModifiers() {
//        return modifiers;
//    }
//
//    public void setModifiers(List<Modifier> modifiers) {
//        this.modifiers = modifiers;
//    }
//
//    public void setBulkpricing(Double bulkpricing) {
//        this.bulkpricing = bulkpricing;
//    }
//
//    public Integer getLocation() {
//        return location;
//    }
//
//    public void setLocation(Integer location) {
//        this.location = location;
//    }
//
//    public Boolean isAutoweigh() {
//        return autoweigh;
//    }
//
//    public void setAutoweigh(Boolean autoweigh) {
//        this.autoweigh = autoweigh;
//    }
//
//    public Integer getNumpercase() {
//        return numpercase;
//    }
//
//    public void setNumpercase(Integer numpercase) {
//        this.numpercase = numpercase;
//    }
//
//    public Boolean isFoodstampable() {
//        return foodstampable;
//    }
//
//    public void setFoodstampable(Boolean foodstampable) {
//        this.foodstampable = foodstampable;
//    }
//
//    public Boolean isCheckid() {
//        return checkid;
//    }
//
//    public void setCheckid(Boolean checkid) {
//        this.checkid = checkid;
//    }
//
//    public String getItemtype() {
//        return itemtype;
//    }
//
//    public void setItemtype(String itemtype) {
//        this.itemtype = itemtype;
//    }
//
//    public Boolean isAskprice() {
//        return askprice;
//    }
//
//    public void setAskprice(Boolean askprice) {
//        this.askprice = askprice;
//    }
//
//    public Boolean isAskquantity() {
//        return askquantity;
//    }
//
//    public void setAskquantity(Boolean askquantity) {
//        this.askquantity = askquantity;
//    }
//
//    public Boolean isDisabled() {
//        return disabled;
//    }
//
//    public void setDisabled(Boolean disabled) {
//        this.disabled = disabled;
//    }
//
//    public Double getUnitsize() {
//        return unitsize;
//    }
//
//    public void setUnitsize(Double unitsize) {
//        this.unitsize = unitsize;
//    }
//
//    public Boolean isAskdescription() {
//        return askdescription;
//    }
//
//    public void setAskdescription(Boolean askdescription) {
//        this.askdescription = askdescription;
//    }
//
//    public Boolean isCheckid2() {
//        return checkid2;
//    }
//
//    public void setCheckid2(Boolean checkid2) {
//        this.checkid2 = checkid2;
//    }
//
//    public Boolean isCountitem() {
//        return countitem;
//    }
//
//    public void setCountitem(Boolean countitem) {
//        this.countitem = countitem;
//    }
//
//    public String getCategoryName() {
//        return categoryName;
//    }
//
//    public void setCategoryName(String categoryName) {
//        this.categoryName = categoryName;
//    }
//
//    public Integer getCategoryId() {
//        return categoryId;
//    }
//
//    public void setCategoryId(Integer categoryId) {
//        this.categoryId = categoryId;
//    }
//
//    public Boolean isItemhasMods() {
//        return itemhasMods;
//    }
//
//    public void setItemhasMods(Boolean itemhasMods) {
//        this.itemhasMods = itemhasMods;
//    }
//
//    public Boolean isItemImg() {
//        return itemImg;
//    }
//
//    public void setItemImg(Boolean itemImg) {
//        this.itemImg = itemImg;
//    }
//
//    public Boolean isItemSpcl() {
//        return itemSpcl;
//    }
//
//    public void setItemSpcl(Boolean itemSpcl) {
//        this.itemSpcl = itemSpcl;
//    }
//
//    public Boolean isItemOnHH() {
//        return itemOnHH;
//    }
//
//    public void setItemOnHH(Boolean itemOnHH) {
//        this.itemOnHH = itemOnHH;
//    }
//
//    public Instant getHhTimeStart() {
//        return hhTimeStart;
//    }
//
//    public void setHhTimeStart(Instant hhTimeStart) {
//        this.hhTimeStart = hhTimeStart;
//    }
//
//    public Instant getHhTimeEnd() {
//        return hhTimeEnd;
//    }
//
//    public void setHhTimeEnd(Instant hhTimeEnd) {
//        this.hhTimeEnd = hhTimeEnd;
//    }
//
//    public Double getHhPrice() {
//        return hhPrice;
//    }
//
//    public void setHhPrice(Double hhPrice) {
//        this.hhPrice = hhPrice;
//    }
//
//    public String getImgUrl() {
//        return imgUrl;
//    }
//
//    public void setImgUrl(String imgUrl) {
//        this.imgUrl = imgUrl;
//    }
//
//    public Integer getModifierID() {
//        return modifierID;
//    }
//
//    public Integer getQty() {
//        return qty;
//    }
//
//    public void setQty(Integer qty) {
//        this.qty = qty;
//    }
//
//    public void setModifierID(Integer modifierID) {
//        this.modifierID = modifierID;
//    }
//
//    public Double getItemSpclPrice() {
//        return itemSpclPrice;
//    }
//
//    public void setItemSpclPrice(Double itemSpclPrice) {
//        this.itemSpclPrice = itemSpclPrice;
//    }
//
//    @Override
//    public boolean equals(Object o) {
//        if (this == o) {
//            return true;
//        }
//        if (o == null || getClass() != o.getClass()) {
//            return false;
//        }
//
//        InventoryDTO inventoryDTO = (InventoryDTO) o;
//        if (inventoryDTO.getId() == null || getId() == null) {
//            return false;
//        }
//        return Objects.equals(getId(), inventoryDTO.getId());
//    }
//
//    @Override
//    public int hashCode() {
//        return Objects.hashCode(getId());
//    }
//
//    @Override
//    public String toString() {
//        return "InventoryDTO{" +
//            "id=" + getId() +
//            ", itemnum=" + getItemnum() +
//            ", brand='" + getBrand() + "'" +
//            ", brandId=" + getBrandId() +
//            ", family='" + getFamily() + "'" +
//            ", familyId=" + getFamilyId() +
//            ", subfamily='" + getSubfamily() + "'" +
//            ", subfamilyId=" + getSubfamilyId() +
//            ", section='" + getSection() + "'" +
//            ", sectionId=" + getSectionId() +
//            ", itemid=" + getItemid() +
//            ", itemname='" + getItemname() + "'" +
//            ", storeid=" + getStoreid() +
//            ", cost=" + getCost() +
//            ", itemprice=" + getItemprice() +
//            ", minprice=" + getMinprice() +
//            ", stock=" + getStock() +
//            ", reorder=" + getReorder() +
//            ", tax1='" + isTax1() + "'" +
//            ", vendorpartnumber=" + getVendorpartnumber() +
//            ", deptid=" + getDeptid() +
//            ", points=" + getPoints() +
//            ", bulkpricing=" + getBulkpricing() +
//            ", location=" + getLocation() +
//            ", autoweigh='" + isAutoweigh() + "'" +
//            ", numpercase=" + getNumpercase() +
//            ", foodstampable='" + isFoodstampable() + "'" +
//            ", checkid='" + isCheckid() + "'" +
//            ", itemtype='" + getItemtype() + "'" +
//            ", askprice='" + isAskprice() + "'" +
//            ", askquantity='" + isAskquantity() + "'" +
//            ", disabled='" + isDisabled() + "'" +
//            ", unitsize=" + getUnitsize() +
//            ", askdescription='" + isAskdescription() + "'" +
//            ", checkid2='" + isCheckid2() + "'" +
//            ", countitem='" + isCountitem() + "'" +
//            ", categoryName='" + getCategoryName() + "'" +
//            ", categoryId=" + getCategoryId() +
//            ", itemhasMods='" + isItemhasMods() + "'" +
//            ", itemImg='" + isItemImg() + "'" +
//            ", itemSpcl='" + isItemSpcl() + "'" +
//            ", itemOnHH='" + isItemOnHH() + "'" +
//            ", hhTimeStart='" + getHhTimeStart() + "'" +
//            ", hhTimeEnd='" + getHhTimeEnd() + "'" +
//            ", hhPrice='" + getHhPrice() + "'" +
//            ", imgUrl='" + getImgUrl() + "'" +
//            "}";
//    }
}
