package com.onyx.app.service.impl;

import com.onyx.app.service.InventoryBulkPriceService;
import com.onyx.app.domain.InventoryBulkPrice;
import com.onyx.app.repository.InventoryBulkPriceRepository;
import com.onyx.app.service.dto.InventoryBulkPriceDTO;
import com.onyx.app.service.mapper.InventoryBulkPriceMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.stereotype.Service;

import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
/**
 * Service Implementation for managing InventoryBulkPrice.
 */
@Service
public class InventoryBulkPriceServiceImpl implements InventoryBulkPriceService {

    private final Logger log = LoggerFactory.getLogger(InventoryBulkPriceServiceImpl.class);

    private final InventoryBulkPriceRepository inventoryBulkPriceRepository;

    private final InventoryBulkPriceMapper inventoryBulkPriceMapper;

    public InventoryBulkPriceServiceImpl(InventoryBulkPriceRepository inventoryBulkPriceRepository, InventoryBulkPriceMapper inventoryBulkPriceMapper) {
        this.inventoryBulkPriceRepository = inventoryBulkPriceRepository;
        this.inventoryBulkPriceMapper = inventoryBulkPriceMapper;
    }

    /**
     * Save a inventoryBulkPrice.
     *
     * @param inventoryBulkPriceDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public InventoryBulkPriceDTO save(InventoryBulkPriceDTO inventoryBulkPriceDTO) {
        log.debug("Request to save InventoryBulkPrice : {}", inventoryBulkPriceDTO);
        InventoryBulkPrice inventoryBulkPrice = inventoryBulkPriceMapper.toEntity(inventoryBulkPriceDTO);
        inventoryBulkPrice = inventoryBulkPriceRepository.save(inventoryBulkPrice);
        return inventoryBulkPriceMapper.toDto(inventoryBulkPrice);
    }

    /**
     * Get all the inventoryBulkPrices.
     *
     * @return the list of entities
     */
    @Override
    public List<InventoryBulkPriceDTO> findAll() {
        log.debug("Request to get all InventoryBulkPrices");
        return inventoryBulkPriceRepository.findAll().stream()
            .map(inventoryBulkPriceMapper::toDto)
            .collect(Collectors.toCollection(LinkedList::new));
    }


    /**
     * Get one inventoryBulkPrice by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    public Optional<InventoryBulkPriceDTO> findOne(String id) {
        log.debug("Request to get InventoryBulkPrice : {}", id);
        return inventoryBulkPriceRepository.findById(id)
            .map(inventoryBulkPriceMapper::toDto);
    }

    /**
     * Delete the inventoryBulkPrice by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(String id) {
        log.debug("Request to delete InventoryBulkPrice : {}", id);
        inventoryBulkPriceRepository.deleteById(id);
    }
}
