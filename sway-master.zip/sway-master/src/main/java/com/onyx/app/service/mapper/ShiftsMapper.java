package com.onyx.app.service.mapper;

import com.onyx.app.domain.*;
import com.onyx.app.service.dto.ShiftsDTO;

import org.mapstruct.*;

/**
 * Mapper for the entity Shifts and its DTO ShiftsDTO.
 */
@Mapper(componentModel = "spring", uses = {})
public interface ShiftsMapper extends EntityMapper<ShiftsDTO, Shifts> {


}
