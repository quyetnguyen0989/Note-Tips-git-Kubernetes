package com.onyx.app.repository;

import com.onyx.app.domain.Inventory;
import com.onyx.app.service.dto.InventoryDTO;

import org.springframework.data.couchbase.core.query.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Spring Data Couchbase repository for the Inventory entity.
 */
@SuppressWarnings("unused")
@Repository
public interface InventoryRepository extends N1qlCouchbaseRepository<Inventory, String> {

//	@Query("")
//    List<Inventory> findAllByDeptid(Integer deptId);
//
//	@Query("")
//    List<Inventory> findAllByStoreidAndDeptid(Integer store_id, Integer dept_id);
//
//	 @Query("")
//	 List<Inventory>
//	    findAllByItemnumOrItemnameContainingOrBrandOrFamilyOrSubfamilyOrUnitsizeOrVendorpartnumberOrDeptid(
//	        Integer itemNum, String itemName, String brand , String family , String subFamily , Double unitSize,
//	        Integer vendorPartNumber , Integer deptId
//	 );
}
