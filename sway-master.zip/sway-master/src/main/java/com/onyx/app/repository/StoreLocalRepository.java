package com.onyx.app.repository;

import com.onyx.app.domain.StoreLocal;
import org.springframework.stereotype.Repository;

/**
 * Spring Data Couchbase repository for the StoreLocal entity.
 */
@SuppressWarnings("unused")
@Repository
public interface StoreLocalRepository extends N1qlCouchbaseRepository<StoreLocal, String> {

}
