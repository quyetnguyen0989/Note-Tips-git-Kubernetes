package com.onyx.app.service.dto;

import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.Objects;

/**
 * A DTO for the InventoryExp entity.
 */
public class InventoryExpDTO implements Serializable {

    private String id;

    @Size(max = 25)
    private String itemNum;

    @Size(max = 50)
    private String itemName;

    private Integer storeId;

    private String expirationDate;

    private String receivedDate;

    private Boolean noteOnExpiration;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getItemNum() {
        return itemNum;
    }

    public void setItemNum(String itemNum) {
        this.itemNum = itemNum;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public Integer getStoreId() {
        return storeId;
    }

    public void setStoreId(Integer storeId) {
        this.storeId = storeId;
    }

    public String getExpirationDate() {
        return expirationDate;
    }

    public void setExpirationDate(String expirationDate) {
        this.expirationDate = expirationDate;
    }

    public String getReceivedDate() {
        return receivedDate;
    }

    public void setReceivedDate(String receivedDate) {
        this.receivedDate = receivedDate;
    }

    public Boolean isNoteOnExpiration() {
        return noteOnExpiration;
    }

    public void setNoteOnExpiration(Boolean noteOnExpiration) {
        this.noteOnExpiration = noteOnExpiration;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        InventoryExpDTO inventoryExpDTO = (InventoryExpDTO) o;
        if (inventoryExpDTO.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), inventoryExpDTO.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "InventoryExpDTO{" +
            "id=" + getId() +
            ", itemNum='" + getItemNum() + "'" +
            ", itemName='" + getItemName() + "'" +
            ", storeId=" + getStoreId() +
            ", expirationDate='" + getExpirationDate() + "'" +
            ", receivedDate='" + getReceivedDate() + "'" +
            ", noteOnExpiration='" + isNoteOnExpiration() + "'" +
            "}";
    }
}
