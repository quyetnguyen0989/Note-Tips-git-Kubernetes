package com.onyx.app.service.impl;

import com.onyx.app.service.PayoutService;
import com.onyx.app.domain.Payout;
import com.onyx.app.repository.PayoutRepository;
import com.onyx.app.service.dto.PayoutDTO;
import com.onyx.app.service.mapper.PayoutMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.stereotype.Service;

import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
/**
 * Service Implementation for managing Payout.
 */
@Service
public class PayoutServiceImpl implements PayoutService {

    private final Logger log = LoggerFactory.getLogger(PayoutServiceImpl.class);

    private final PayoutRepository payoutRepository;

    private final PayoutMapper payoutMapper;

    public PayoutServiceImpl(PayoutRepository payoutRepository, PayoutMapper payoutMapper) {
        this.payoutRepository = payoutRepository;
        this.payoutMapper = payoutMapper;
    }

    /**
     * Save a payout.
     *
     * @param payoutDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public PayoutDTO save(PayoutDTO payoutDTO) {
        log.debug("Request to save Payout : {}", payoutDTO);
        Payout payout = payoutMapper.toEntity(payoutDTO);
        payout = payoutRepository.save(payout);
        return payoutMapper.toDto(payout);
    }

    /**
     * Get all the payouts.
     *
     * @return the list of entities
     */
    @Override
    public List<PayoutDTO> findAll() {
        log.debug("Request to get all Payouts");
        return payoutRepository.findAll().stream()
            .map(payoutMapper::toDto)
            .collect(Collectors.toCollection(LinkedList::new));
    }


    /**
     * Get one payout by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    public Optional<PayoutDTO> findOne(String id) {
        log.debug("Request to get Payout : {}", id);
        return payoutRepository.findById(id)
            .map(payoutMapper::toDto);
    }

    /**
     * Delete the payout by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(String id) {
        log.debug("Request to delete Payout : {}", id);
        payoutRepository.deleteById(id);
    }
}
