package com.onyx.app.domain;

import org.springframework.data.annotation.Id;
import com.couchbase.client.java.repository.annotation.Field;
import org.springframework.data.couchbase.core.mapping.Document;
import org.springframework.data.couchbase.core.mapping.id.GeneratedValue;
import org.springframework.data.couchbase.core.mapping.id.IdPrefix;
import javax.validation.constraints.*;

import java.io.Serializable;
import java.util.Objects;

import static com.onyx.app.config.Constants.ID_DELIMITER;
import static org.springframework.data.couchbase.core.mapping.id.GenerationStrategy.UNIQUE;

/**
 * A CustomerInfo.
 */
@Document
public class CustomerInfo implements Serializable {

    private static final long serialVersionUID = 1L;
    public static final String PREFIX = "customerinfo";

    @SuppressWarnings("unused")
    @IdPrefix
    private String prefix = PREFIX;

    @Id
    @GeneratedValue(strategy = UNIQUE, delimiter = ID_DELIMITER)
    private String id;

    @Field("store_id")
    private Integer storeId;

    @Field("cust_num")
    private Integer custNum;

    @Size(max = 20)
    @Field("first_name")
    private String firstName;

    @Size(max = 20)
    @Field("last_name")
    private String lastName;

    @Size(max = 30)
    @Field("address_1")
    private String address1;

    @Size(max = 30)
    @Field("address_2")
    private String address2;

    @Size(max = 20)
    @Field("city")
    private String city;

    @Size(max = 10)
    @Field("state")
    private String state;

    @Field("zip_code")
    private Integer zipCode;

    @Field("phone_1")
    private Integer phone1;

    @Field("mobile_num")
    private Integer mobileNum;

    @Field("discount_level")
    private Integer discountLevel;

    @Field("discount_percent")
    private Integer discountPercent;

    @Field("acct_open_date")
    private String acctOpenDate;

    @Field("acct_balance")
    private Integer acctBalance;

    @Field("acct_max_balance")
    private Integer acctMaxBalance;

    @Field("reward_plan")
    private String rewardPlan;

    @Field("reward_points")
    private Integer rewardPoints;

    @Field("online_user_name")
    private String onlineUserName;

    @Field("birthday")
    private String birthday;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getStoreId() {
        return storeId;
    }

    public CustomerInfo storeId(Integer storeId) {
        this.storeId = storeId;
        return this;
    }

    public void setStoreId(Integer storeId) {
        this.storeId = storeId;
    }

    public Integer getCustNum() {
        return custNum;
    }

    public CustomerInfo custNum(Integer custNum) {
        this.custNum = custNum;
        return this;
    }

    public void setCustNum(Integer custNum) {
        this.custNum = custNum;
    }

    public String getFirstName() {
        return firstName;
    }

    public CustomerInfo firstName(String firstName) {
        this.firstName = firstName;
        return this;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public CustomerInfo lastName(String lastName) {
        this.lastName = lastName;
        return this;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getAddress1() {
        return address1;
    }

    public CustomerInfo address1(String address1) {
        this.address1 = address1;
        return this;
    }

    public void setAddress1(String address1) {
        this.address1 = address1;
    }

    public String getAddress2() {
        return address2;
    }

    public CustomerInfo address2(String address2) {
        this.address2 = address2;
        return this;
    }

    public void setAddress2(String address2) {
        this.address2 = address2;
    }

    public String getCity() {
        return city;
    }

    public CustomerInfo city(String city) {
        this.city = city;
        return this;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public CustomerInfo state(String state) {
        this.state = state;
        return this;
    }

    public void setState(String state) {
        this.state = state;
    }

    public Integer getZipCode() {
        return zipCode;
    }

    public CustomerInfo zipCode(Integer zipCode) {
        this.zipCode = zipCode;
        return this;
    }

    public void setZipCode(Integer zipCode) {
        this.zipCode = zipCode;
    }

    public Integer getPhone1() {
        return phone1;
    }

    public CustomerInfo phone1(Integer phone1) {
        this.phone1 = phone1;
        return this;
    }

    public void setPhone1(Integer phone1) {
        this.phone1 = phone1;
    }

    public Integer getMobileNum() {
        return mobileNum;
    }

    public CustomerInfo mobileNum(Integer mobileNum) {
        this.mobileNum = mobileNum;
        return this;
    }

    public void setMobileNum(Integer mobileNum) {
        this.mobileNum = mobileNum;
    }

    public Integer getDiscountLevel() {
        return discountLevel;
    }

    public CustomerInfo discountLevel(Integer discountLevel) {
        this.discountLevel = discountLevel;
        return this;
    }

    public void setDiscountLevel(Integer discountLevel) {
        this.discountLevel = discountLevel;
    }

    public Integer getDiscountPercent() {
        return discountPercent;
    }

    public CustomerInfo discountPercent(Integer discountPercent) {
        this.discountPercent = discountPercent;
        return this;
    }

    public void setDiscountPercent(Integer discountPercent) {
        this.discountPercent = discountPercent;
    }

    public String getAcctOpenDate() {
        return acctOpenDate;
    }

    public CustomerInfo acctOpenDate(String acctOpenDate) {
        this.acctOpenDate = acctOpenDate;
        return this;
    }

    public void setAcctOpenDate(String acctOpenDate) {
        this.acctOpenDate = acctOpenDate;
    }

    public Integer getAcctBalance() {
        return acctBalance;
    }

    public CustomerInfo acctBalance(Integer acctBalance) {
        this.acctBalance = acctBalance;
        return this;
    }

    public void setAcctBalance(Integer acctBalance) {
        this.acctBalance = acctBalance;
    }

    public Integer getAcctMaxBalance() {
        return acctMaxBalance;
    }

    public CustomerInfo acctMaxBalance(Integer acctMaxBalance) {
        this.acctMaxBalance = acctMaxBalance;
        return this;
    }

    public void setAcctMaxBalance(Integer acctMaxBalance) {
        this.acctMaxBalance = acctMaxBalance;
    }

    public String getRewardPlan() {
        return rewardPlan;
    }

    public CustomerInfo rewardPlan(String rewardPlan) {
        this.rewardPlan = rewardPlan;
        return this;
    }

    public void setRewardPlan(String rewardPlan) {
        this.rewardPlan = rewardPlan;
    }

    public Integer getRewardPoints() {
        return rewardPoints;
    }

    public CustomerInfo rewardPoints(Integer rewardPoints) {
        this.rewardPoints = rewardPoints;
        return this;
    }

    public void setRewardPoints(Integer rewardPoints) {
        this.rewardPoints = rewardPoints;
    }

    public String getOnlineUserName() {
        return onlineUserName;
    }

    public CustomerInfo onlineUserName(String onlineUserName) {
        this.onlineUserName = onlineUserName;
        return this;
    }

    public void setOnlineUserName(String onlineUserName) {
        this.onlineUserName = onlineUserName;
    }

    public String getBirthday() {
        return birthday;
    }

    public CustomerInfo birthday(String birthday) {
        this.birthday = birthday;
        return this;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        CustomerInfo customerInfo = (CustomerInfo) o;
        if (customerInfo.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), customerInfo.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "CustomerInfo{" +
            "id=" + getId() +
            ", storeId=" + getStoreId() +
            ", custNum=" + getCustNum() +
            ", firstName='" + getFirstName() + "'" +
            ", lastName='" + getLastName() + "'" +
            ", address1='" + getAddress1() + "'" +
            ", address2='" + getAddress2() + "'" +
            ", city='" + getCity() + "'" +
            ", state='" + getState() + "'" +
            ", zipCode=" + getZipCode() +
            ", phone1=" + getPhone1() +
            ", mobileNum=" + getMobileNum() +
            ", discountLevel=" + getDiscountLevel() +
            ", discountPercent=" + getDiscountPercent() +
            ", acctOpenDate='" + getAcctOpenDate() + "'" +
            ", acctBalance=" + getAcctBalance() +
            ", acctMaxBalance=" + getAcctMaxBalance() +
            ", rewardPlan='" + getRewardPlan() + "'" +
            ", rewardPoints=" + getRewardPoints() +
            ", onlineUserName='" + getOnlineUserName() + "'" +
            ", birthday='" + getBirthday() + "'" +
            "}";
    }
}
