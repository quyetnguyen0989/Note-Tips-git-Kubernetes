package com.onyx.app.repository;

import org.springframework.stereotype.Repository;

import com.onyx.app.domain.Category;

/**
 * Spring Data MongoDB repository for the Category entity.
 */
@SuppressWarnings("unused")
@Repository
public interface CategoryRepository extends N1qlCouchbaseRepository<Category, String> {

}
