package com.onyx.app.service.dto;

import java.time.Instant;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.Objects;

/**
 * A DTO for the Inventory entity.
 */
public class InventoryQuick implements Serializable {

    private String id;

    private Long itemnum;

    @NotNull
    private Integer itemid;

    @Size(max = 50)
    private String itemname;

    @NotNull
    private Integer storeid;

    @NotNull
    private Double cost;

    @NotNull
    private Double itemprice;

    private Integer deptid;

    private Boolean itemhasMods;

    private Boolean itemImg;

    private Boolean itemSpcl;

    private Boolean itemOnHH;

    private Instant hhTimeStart;

    private Instant hhTimeEnd;

    private Double hhPrice;

    private String imgUrl;

    private Integer modifierID;

    private Double itemSpclPrice;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Long getItemnum() {
        return itemnum;
    }

    public void setItemnum(Long itemnum) {
        this.itemnum = itemnum;
    }

    public Integer getItemid() {
        return itemid;
    }

    public void setItemid(Integer itemid) {
        this.itemid = itemid;
    }

    public String getItemname() {
        return itemname;
    }

    public void setItemname(String itemname) {
        this.itemname = itemname;
    }

    public Integer getStoreid() {
        return storeid;
    }

    public void setStoreid(Integer storeid) {
        this.storeid = storeid;
    }

    public Double getItemprice() {
        return itemprice;
    }

    public void setItemprice(Double itemprice) {
        this.itemprice = itemprice;
    }

    public Integer getDeptid() {
        return deptid;
    }

    public void setDeptid(Integer deptid) {
        this.deptid = deptid;
    }

    public Boolean getItemhasMods() {
        return itemhasMods;
    }

    public void setItemhasMods(Boolean itemhasMods) {
        this.itemhasMods = itemhasMods;
    }

    public Boolean getItemImg() {
        return itemImg;
    }

    public void setItemImg(Boolean itemImg) {
        this.itemImg = itemImg;
    }

    public Boolean getItemSpcl() {
        return itemSpcl;
    }

    public void setItemSpcl(Boolean itemSpcl) {
        this.itemSpcl = itemSpcl;
    }

    public Boolean getItemOnHH() {
        return itemOnHH;
    }

    public void setItemOnHH(Boolean itemOnHH) {
        this.itemOnHH = itemOnHH;
    }

    public Instant getHhTimeStart() {
        return hhTimeStart;
    }

    public void setHhTimeStart(Instant hhTimeStart) {
        this.hhTimeStart = hhTimeStart;
    }

    public Instant getHhTimeEnd() {
        return hhTimeEnd;
    }

    public void setHhTimeEnd(Instant hhTimeEnd) {
        this.hhTimeEnd = hhTimeEnd;
    }

    public Double getCost() {
        return cost;
    }

    public void setCost(Double cost) {
        this.cost = cost;
    }

    public Double getHhPrice() {
        return hhPrice;
    }

    public void setHhPrice(Double hhPrice) {
        this.hhPrice = hhPrice;
    }

    public String getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }

    public Integer getModifierID() {
        return modifierID;
    }

    public void setModifierID(Integer modifierID) {
        this.modifierID = modifierID;
    }

    public Double getItemSpclPrice() {
        return itemSpclPrice;
    }

    public void setItemSpclPrice(Double itemSpclPrice) {
        this.itemSpclPrice = itemSpclPrice;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        InventoryQuick inventoryQuick = (InventoryQuick) o;
        if (inventoryQuick.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), inventoryQuick.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "InventoryQuick{" +
            "id='" + id + '\'' +
            ", itemnum=" + itemnum +
            ", itemid=" + itemid +
            ", itemname='" + itemname + '\'' +
            ", storeid=" + storeid +
            ", cost=" + cost +
            ", itemprice=" + itemprice +
            ", deptid=" + deptid +
            ", itemhasMods=" + itemhasMods +
            ", itemImg=" + itemImg +
            ", itemSpcl=" + itemSpcl +
            ", itemOnHH=" + itemOnHH +
            ", hhTimeStart=" + hhTimeStart +
            ", hhTimeEnd=" + hhTimeEnd +
            ", hhPrice='" + getHhPrice() + "'" +
            ", imgUrl='" + getImgUrl() + "'" +
            '}';
    }
}
