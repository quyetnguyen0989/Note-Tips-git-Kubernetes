package com.onyx.app.repository;

import org.springframework.stereotype.Repository;

import com.onyx.app.domain.Payout;

/**
 * Spring Data MongoDB repository for the Payout entity.
 */
@SuppressWarnings("unused")
@Repository
public interface PayoutRepository extends N1qlCouchbaseRepository<Payout, String> {

}
