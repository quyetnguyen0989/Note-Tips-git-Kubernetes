package com.onyx.app.repository;

import com.onyx.app.domain.InvoiceCheckout;
import org.springframework.data.couchbase.core.query.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface InvoiceCheckoutRepository extends N1qlCouchbaseRepository<InvoiceCheckout , String>{

    @Query("{'modifiers.id : ?0'}")
    InvoiceCheckout findByModifiers_Id(String id);

    @Query("SELECT META().* FROM onyxapp WHERE inventories.itemid = $1 AND _class = 'com.onyx.app.domain.InvoiceCheckout'")
    InvoiceCheckout findByInventories_Id(Integer id);
}
