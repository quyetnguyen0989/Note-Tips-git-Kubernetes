package com.onyx.app.web.rest.errors;

public class BrandException extends RuntimeException{

	private static final long serialVersionUID = 6354795800781321186L;
	
	public BrandException(String message) {
		super(message);
	}

}
