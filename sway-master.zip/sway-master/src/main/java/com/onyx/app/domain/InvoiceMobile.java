package com.onyx.app.domain;


import org.springframework.data.annotation.Id;
import com.couchbase.client.java.repository.annotation.Field;
import org.springframework.data.couchbase.core.mapping.Document;
import org.springframework.data.couchbase.core.mapping.id.GeneratedValue;
import org.springframework.data.couchbase.core.mapping.id.IdPrefix;
import javax.validation.constraints.*;

import java.io.Serializable;
import java.time.Instant;
import java.time.LocalDate;
import java.util.Objects;

import static com.onyx.app.config.Constants.ID_DELIMITER;
import static org.springframework.data.couchbase.core.mapping.id.GenerationStrategy.UNIQUE;

/**
 * A InvoiceMobile.
 */
@Document
public class InvoiceMobile implements Serializable {

    private static final long serialVersionUID = 1L;
    public static final String PREFIX = "invoicemobile";

    @SuppressWarnings("unused")
    @IdPrefix
    private String prefix = PREFIX;

    @Id
    @GeneratedValue(strategy = UNIQUE, delimiter = ID_DELIMITER)
    private String id;

    @Field("itemnum")
    private Integer itemnum;

    @Size(max = 50)
    @Field("itemname")
    private String itemname;

    @Field("storeid")
    private Integer storeid;

    @Field("cusname")
    private String cusname;

    @Field("cust_num")
    private Long custNum;

    @Field("invnum")
    private Integer invnum;

    @Field("invtime")
    private Instant invtime;

    @NotNull
    @Field("itemprice")
    private Double itemprice;

    @Field("invdate")
    private LocalDate invdate;

    @Field("discount")
    private Double discount;

    @Field("total_price")
    private Double totalPrice;

    @Field("total_tax_1")
    private Double totalTax1;

    @Field("grand_total")
    private Double grandTotal;

    @Field("amt_change")
    private Double amtChange;

    @Field("payment_method")
    private String paymentMethod;

    @Field("taxed_sales")
    private Double taxedSales;

    @Field("non_taxedsales")
    private Double nonTaxedsales;

    @Field("ccamount")
    private Double ccamount;

    @Field("status")
    private String status;

    @Field("modifier_id")
    private Integer modifierID;

    @Field("modifier_name")
    private String modifierName;

    @Field("modifier_num")
    private Long modifierNum;

    public InvoiceMobile() {
    }

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getItemnum() {
        return itemnum;
    }

    public InvoiceMobile itemnum(Integer itemnum) {
        this.itemnum = itemnum;
        return this;
    }

    public void setItemnum(Integer itemnum) {
        this.itemnum = itemnum;
    }

    public String getItemname() {
        return itemname;
    }

    public InvoiceMobile itemname(String itemname) {
        this.itemname = itemname;
        return this;
    }

    public void setItemname(String itemname) {
        this.itemname = itemname;
    }

    public Integer getStoreid() {
        return storeid;
    }

    public InvoiceMobile storeid(Integer storeid) {
        this.storeid = storeid;
        return this;
    }

    public void setStoreid(Integer storeid) {
        this.storeid = storeid;
    }

    public String getCusname() {
        return cusname;
    }

    public InvoiceMobile cusname(String cusname) {
        this.cusname = cusname;
        return this;
    }

    public void setCusname(String cusname) {
        this.cusname = cusname;
    }

    public Long getCustNum() {
        return custNum;
    }

    public InvoiceMobile custNum(Long custNum) {
        this.custNum = custNum;
        return this;
    }

    public void setCustNum(Long custNum) {
        this.custNum = custNum;
    }

    public Integer getInvnum() {
        return invnum;
    }

    public InvoiceMobile invnum(Integer invnum) {
        this.invnum = invnum;
        return this;
    }

    public void setInvnum(Integer invnum) {
        this.invnum = invnum;
    }

    public Instant getInvtime() {
        return invtime;
    }

    public InvoiceMobile invtime(Instant invtime) {
        this.invtime = invtime;
        return this;
    }

    public void setInvtime(Instant invtime) {
        this.invtime = invtime;
    }

    public Double getItemprice() {
        return itemprice;
    }

    public InvoiceMobile itemprice(Double itemprice) {
        this.itemprice = itemprice;
        return this;
    }

    public void setItemprice(Double itemprice) {
        this.itemprice = itemprice;
    }

    public LocalDate getInvdate() {
        return invdate;
    }

    public InvoiceMobile invdate(LocalDate invdate) {
        this.invdate = invdate;
        return this;
    }

    public void setInvdate(LocalDate invdate) {
        this.invdate = invdate;
    }

    public Double getDiscount() {
        return discount;
    }

    public InvoiceMobile discount(Double discount) {
        this.discount = discount;
        return this;
    }

    public void setDiscount(Double discount) {
        this.discount = discount;
    }

    public Double getTotalPrice() {
        return totalPrice;
    }

    public InvoiceMobile totalPrice(Double totalPrice) {
        this.totalPrice = totalPrice;
        return this;
    }

    public void setTotalPrice(Double totalPrice) {
        this.totalPrice = totalPrice;
    }

    public Double getTotalTax1() {
        return totalTax1;
    }

    public InvoiceMobile totalTax1(Double totalTax1) {
        this.totalTax1 = totalTax1;
        return this;
    }

    public void setTotalTax1(Double totalTax1) {
        this.totalTax1 = totalTax1;
    }

    public Double getGrandTotal() {
        return grandTotal;
    }

    public InvoiceMobile grandTotal(Double grandTotal) {
        this.grandTotal = grandTotal;
        return this;
    }

    public void setGrandTotal(Double grandTotal) {
        this.grandTotal = grandTotal;
    }

    public Double getAmtChange() {
        return amtChange;
    }

    public InvoiceMobile amtChange(Double amtChange) {
        this.amtChange = amtChange;
        return this;
    }

    public void setAmtChange(Double amtChange) {
        this.amtChange = amtChange;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public InvoiceMobile paymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
        return this;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public Double getTaxedSales() {
        return taxedSales;
    }

    public InvoiceMobile taxedSales(Double taxedSales) {
        this.taxedSales = taxedSales;
        return this;
    }

    public void setTaxedSales(Double taxedSales) {
        this.taxedSales = taxedSales;
    }

    public Double getNonTaxedsales() {
        return nonTaxedsales;
    }

    public InvoiceMobile nonTaxedsales(Double nonTaxedsales) {
        this.nonTaxedsales = nonTaxedsales;
        return this;
    }

    public void setNonTaxedsales(Double nonTaxedsales) {
        this.nonTaxedsales = nonTaxedsales;
    }

    public Double getCcamount() {
        return ccamount;
    }

    public InvoiceMobile ccamount(Double ccamount) {
        this.ccamount = ccamount;
        return this;
    }

    public void setCcamount(Double ccamount) {
        this.ccamount = ccamount;
    }

    public String getStatus() {
        return status;
    }

    public InvoiceMobile status(String status) {
        this.status = status;
        return this;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Integer getModifierID() {
        return modifierID;
    }

    public InvoiceMobile modifierID(Integer modifierID) {
        this.modifierID = modifierID;
        return this;
    }

    public void setModifierID(Integer modifierID) {
        this.modifierID = modifierID;
    }

    public String getModifierName() {
        return modifierName;
    }

    public InvoiceMobile modifierName(String modifierName) {
        this.modifierName = modifierName;
        return this;
    }

    public void setModifierName(String modifierName) {
        this.modifierName = modifierName;
    }

    public Long getModifierNum() {
        return modifierNum;
    }

    public InvoiceMobile modifierNum(Long modifierNum) {
        this.modifierNum = modifierNum;
        return this;
    }

    public void setModifierNum(Long modifierNum) {
        this.modifierNum = modifierNum;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        InvoiceMobile invoiceMobile = (InvoiceMobile) o;
        if (invoiceMobile.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), invoiceMobile.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "InvoiceMobile{" +
            "id=" + getId() +
            ", itemnum=" + getItemnum() +
            ", itemname='" + getItemname() + "'" +
            ", storeid=" + getStoreid() +
            ", cusname='" + getCusname() + "'" +
            ", custNum=" + getCustNum() +
            ", invnum=" + getInvnum() +
            ", invtime='" + getInvtime() + "'" +
            ", itemprice=" + getItemprice() +
            ", invdate='" + getInvdate() + "'" +
            ", discount=" + getDiscount() +
            ", totalPrice=" + getTotalPrice() +
            ", totalTax1=" + getTotalTax1() +
            ", grandTotal=" + getGrandTotal() +
            ", amtChange=" + getAmtChange() +
            ", paymentMethod='" + getPaymentMethod() + "'" +
            ", taxedSales=" + getTaxedSales() +
            ", nonTaxedsales=" + getNonTaxedsales() +
            ", ccamount=" + getCcamount() +
            ", status='" + getStatus() + "'" +
            ", modifierID=" + getModifierID() +
            ", modifierName='" + getModifierName() + "'" +
            ", modifierNum=" + getModifierNum() +
            "}";
    }
}
