package com.onyx.app.domain;

import com.couchbase.client.java.repository.annotation.Field;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Reference;
import org.springframework.data.couchbase.core.mapping.Document;
import org.springframework.data.couchbase.core.mapping.id.GeneratedValue;

import javax.validation.constraints.Size;
import java.io.Serializable;
import java.time.Instant;
import java.time.LocalDate;
import java.util.List;

import static com.onyx.app.config.Constants.ID_DELIMITER;
import static org.springframework.data.couchbase.core.mapping.id.GenerationStrategy.UNIQUE;

@Document
public class InvoiceCheckout implements Serializable {


    private static final long serialVersionUID = 3632680382386138198L;

    @Id
    @GeneratedValue(strategy = UNIQUE, delimiter = ID_DELIMITER)
    private String id;

    private List<Inventory> inventories;

    @Field("invnum")
    private Integer invnum;

    @Field("invtime")
    private Instant invtime;

    @Field("invdate")
    private LocalDate invdate;

    @Field("total_cost")
    private Double totalCost;

    @Field("discount")
    private Double discount;

    @Field("total_price")
    private Double totalPrice;

    @Field("total_tax_1")
    private Double totalTax1;

    @Field("total_tax_2")
    private Double totalTax2;

    @Field("total_tax_3")
    private Double totalTax3;

    @Field("grand_total")
    private Double grandTotal;

    @Field("amt_tendered")
    private Double amtTendered;

    @Field("amt_change")
    private Double amtChange;

    @Size(max = 200)
    @Field("notes")
    private String notes;

    @Field("status")
    private String status;

    @Field("cashierid")
    private Integer cashierid;

    @Field("cashiername")
    private String cashiername;

    @Field("stationid")
    private Integer stationid;

    @Field("payment_method")
    private String paymentMethod;

    @Field("taxed_1")
    private Double taxed1;

    @Field("taxed_sales")
    private Double taxedSales;

    @Field("non_taxedsales")
    private Double nonTaxedsales;

    @Field("taxexemptsales")
    private Double taxexemptsales;

    @Field("caamount")
    private Double caamount;

    @Field("ccamount")
    private Double ccamount;

    @Field("oaamount")
    private Double oaamount;

    @Field("dcamount")
    private Double dcamount;

    @Field("tipamount")
    private Double tipamount;

    @Field("fsamount")
    private Double fsamount;

    @Field("taxrateid")
    private String taxrateid;

    @Field("taxrate_1_percent")
    private Double taxrate1percent;

    @Field("layaway")
    private String layaway;

    @Field("amtdeposit")
    private Double amtdeposit;

    @Field("layawayamount")
    private Double layawayamount;

    @Field("onlineorderid")
    private Integer onlineorderid;

    @Field("order_source")
    private String orderSource;

    @Field("modifieddate")
    private String modifieddate;

    @Field("createdate")
    private String createdate;

    @Field("kioskid")
    private String kioskid;

    @Field("modifier_id")
    private Integer modifierID;

    @Field("modifier_name")
    private String modifierName;

    @Field("modifier_num")
    private Long modifierNum;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }


    public List<Inventory> getInventories() {
        return inventories;
    }

    public void setInventories(List<Inventory> inventories) {
        this.inventories = inventories;
    }

    public Integer getInvnum() {
        return invnum;
    }

    public void setInvnum(Integer invnum) {
        this.invnum = invnum;
    }

    public Instant getInvtime() {
        return invtime;
    }

    public void setInvtime(Instant invtime) {
        this.invtime = invtime;
    }

    public LocalDate getInvdate() {
        return invdate;
    }

    public void setInvdate(LocalDate invdate) {
        this.invdate = invdate;
    }

    public Double getTotalCost() {
        return totalCost;
    }

    public void setTotalCost(Double totalCost) {
        this.totalCost = totalCost;
    }

    public Double getDiscount() {
        return discount;
    }

    public void setDiscount(Double discount) {
        this.discount = discount;
    }

    public Double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(Double totalPrice) {
        this.totalPrice = totalPrice;
    }

    public Double getTotalTax1() {
        return totalTax1;
    }

    public void setTotalTax1(Double totalTax1) {
        this.totalTax1 = totalTax1;
    }

    public Double getTotalTax2() {
        return totalTax2;
    }

    public void setTotalTax2(Double totalTax2) {
        this.totalTax2 = totalTax2;
    }

    public Double getTotalTax3() {
        return totalTax3;
    }

    public void setTotalTax3(Double totalTax3) {
        this.totalTax3 = totalTax3;
    }

    public Double getGrandTotal() {
        return grandTotal;
    }

    public void setGrandTotal(Double grandTotal) {
        this.grandTotal = grandTotal;
    }

    public Double getAmtTendered() {
        return amtTendered;
    }

    public void setAmtTendered(Double amtTendered) {
        this.amtTendered = amtTendered;
    }

    public Double getAmtChange() {
        return amtChange;
    }

    public void setAmtChange(Double amtChange) {
        this.amtChange = amtChange;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Integer getCashierid() {
        return cashierid;
    }

    public void setCashierid(Integer cashierid) {
        this.cashierid = cashierid;
    }

    public String getCashiername() {
        return cashiername;
    }

    public void setCashiername(String cashiername) {
        this.cashiername = cashiername;
    }

    public Integer getStationid() {
        return stationid;
    }

    public void setStationid(Integer stationid) {
        this.stationid = stationid;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public Double getTaxed1() {
        return taxed1;
    }

    public void setTaxed1(Double taxed1) {
        this.taxed1 = taxed1;
    }

    public Double getTaxedSales() {
        return taxedSales;
    }

    public void setTaxedSales(Double taxedSales) {
        this.taxedSales = taxedSales;
    }

    public Double getNonTaxedsales() {
        return nonTaxedsales;
    }

    public void setNonTaxedsales(Double nonTaxedsales) {
        this.nonTaxedsales = nonTaxedsales;
    }

    public Double getTaxexemptsales() {
        return taxexemptsales;
    }

    public void setTaxexemptsales(Double taxexemptsales) {
        this.taxexemptsales = taxexemptsales;
    }

    public Double getCaamount() {
        return caamount;
    }

    public void setCaamount(Double caamount) {
        this.caamount = caamount;
    }

    public Double getCcamount() {
        return ccamount;
    }

    public void setCcamount(Double ccamount) {
        this.ccamount = ccamount;
    }

    public Double getOaamount() {
        return oaamount;
    }

    public void setOaamount(Double oaamount) {
        this.oaamount = oaamount;
    }

    public Double getDcamount() {
        return dcamount;
    }

    public void setDcamount(Double dcamount) {
        this.dcamount = dcamount;
    }

    public Double getTipamount() {
        return tipamount;
    }

    public void setTipamount(Double tipamount) {
        this.tipamount = tipamount;
    }

    public Double getFsamount() {
        return fsamount;
    }

    public void setFsamount(Double fsamount) {
        this.fsamount = fsamount;
    }

    public String getTaxrateid() {
        return taxrateid;
    }

    public void setTaxrateid(String taxrateid) {
        this.taxrateid = taxrateid;
    }

    public Double getTaxrate1percent() {
        return taxrate1percent;
    }

    public void setTaxrate1percent(Double taxrate1percent) {
        this.taxrate1percent = taxrate1percent;
    }

    public String getLayaway() {
        return layaway;
    }

    public void setLayaway(String layaway) {
        this.layaway = layaway;
    }

    public Double getAmtdeposit() {
        return amtdeposit;
    }

    public void setAmtdeposit(Double amtdeposit) {
        this.amtdeposit = amtdeposit;
    }

    public Double getLayawayamount() {
        return layawayamount;
    }

    public void setLayawayamount(Double layawayamount) {
        this.layawayamount = layawayamount;
    }

    public Integer getOnlineorderid() {
        return onlineorderid;
    }

    public void setOnlineorderid(Integer onlineorderid) {
        this.onlineorderid = onlineorderid;
    }

    public String getOrderSource() {
        return orderSource;
    }

    public void setOrderSource(String orderSource) {
        this.orderSource = orderSource;
    }

    public String getModifieddate() {
        return modifieddate;
    }

    public void setModifieddate(String modifieddate) {
        this.modifieddate = modifieddate;
    }

    public String getCreatedate() {
        return createdate;
    }

    public void setCreatedate(String createdate) {
        this.createdate = createdate;
    }

    public String getKioskid() {
        return kioskid;
    }

    public void setKioskid(String kioskid) {
        this.kioskid = kioskid;
    }

    public Integer getModifierID() {
        return modifierID;
    }

    public void setModifierID(Integer modifierID) {
        this.modifierID = modifierID;
    }

    public String getModifierName() {
        return modifierName;
    }

    public void setModifierName(String modifierName) {
        this.modifierName = modifierName;
    }

    public Long getModifierNum() {
        return modifierNum;
    }

    public void setModifierNum(Long modifierNum) {
        this.modifierNum = modifierNum;
    }

    @Override
    public String toString() {
        return "InvoiceCheckout{" +
            "id='" + id + '\'' +
            ", inventories=" + inventories +
            ", invnum=" + invnum +
            ", invtime=" + invtime +
            ", invdate=" + invdate +
            ", totalCost=" + totalCost +
            ", discount=" + discount +
            ", totalPrice=" + totalPrice +
            ", totalTax1=" + totalTax1 +
            ", totalTax2=" + totalTax2 +
            ", totalTax3=" + totalTax3 +
            ", grandTotal=" + grandTotal +
            ", amtTendered=" + amtTendered +
            ", amtChange=" + amtChange +
            ", notes='" + notes + '\'' +
            ", status='" + status + '\'' +
            ", cashierid=" + cashierid +
            ", cashiername='" + cashiername + '\'' +
            ", stationid=" + stationid +
            ", paymentMethod='" + paymentMethod + '\'' +
            ", taxed1=" + taxed1 +
            ", taxedSales=" + taxedSales +
            ", nonTaxedsales=" + nonTaxedsales +
            ", taxexemptsales=" + taxexemptsales +
            ", caamount=" + caamount +
            ", ccamount=" + ccamount +
            ", oaamount=" + oaamount +
            ", dcamount=" + dcamount +
            ", tipamount=" + tipamount +
            ", fsamount=" + fsamount +
            ", taxrateid='" + taxrateid + '\'' +
            ", taxrate1percent=" + taxrate1percent +
            ", layaway='" + layaway + '\'' +
            ", amtdeposit=" + amtdeposit +
            ", layawayamount=" + layawayamount +
            ", onlineorderid=" + onlineorderid +
            ", orderSource='" + orderSource + '\'' +
            ", modifieddate='" + modifieddate + '\'' +
            ", createdate='" + createdate + '\'' +
            ", kioskid='" + kioskid + '\'' +
            '}';
    }
}
