package com.onyx.app.service.mapper;

import com.onyx.app.domain.*;
import com.onyx.app.service.dto.GroupsDTO;

import org.mapstruct.*;

/**
 * Mapper for the entity Groups and its DTO GroupsDTO.
 */
@Mapper(componentModel = "spring", uses = {})
public interface GroupsMapper extends EntityMapper<GroupsDTO, Groups> {


}
