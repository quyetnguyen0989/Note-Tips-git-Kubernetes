package com.onyx.app.web.rest;

import com.codahale.metrics.annotation.Timed;
import com.onyx.app.service.SubFamilyService;
import com.onyx.app.web.rest.errors.BadRequestAlertException;
import com.onyx.app.web.rest.util.HeaderUtil;
import com.onyx.app.service.dto.SubFamilyDTO;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;

import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing SubFamily.
 */
@RestController
@RequestMapping("/api")
public class SubFamilyResource {

    private final Logger log = LoggerFactory.getLogger(SubFamilyResource.class);

    private static final String ENTITY_NAME = "subFamily";

    private final SubFamilyService subFamilyService;

    public SubFamilyResource(SubFamilyService subFamilyService) {
        this.subFamilyService = subFamilyService;
    }

    /**
     * POST  /sub-families : Create a new subFamily.
     *
     * @param subFamilyDTO the subFamilyDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new subFamilyDTO, or with status 400 (Bad Request) if the subFamily has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/sub-families")
    @Timed
    public ResponseEntity<SubFamilyDTO> createSubFamily(@Valid @RequestBody SubFamilyDTO subFamilyDTO) throws URISyntaxException {
        log.debug("REST request to save SubFamily : {}", subFamilyDTO);
        if (subFamilyDTO.getId() != null) {
            throw new BadRequestAlertException("A new subFamily cannot already have an ID", ENTITY_NAME, "idexists");
        }
        SubFamilyDTO result = subFamilyService.save(subFamilyDTO);
        return ResponseEntity.created(new URI("/api/sub-families/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /sub-families : Updates an existing subFamily.
     *
     * @param subFamilyDTO the subFamilyDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated subFamilyDTO,
     * or with status 400 (Bad Request) if the subFamilyDTO is not valid,
     * or with status 500 (Internal Server Error) if the subFamilyDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/sub-families")
    @Timed
    public ResponseEntity<SubFamilyDTO> updateSubFamily(@Valid @RequestBody SubFamilyDTO subFamilyDTO) throws URISyntaxException {
        log.debug("REST request to update SubFamily : {}", subFamilyDTO);
        if (subFamilyDTO.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        SubFamilyDTO result = subFamilyService.save(subFamilyDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, subFamilyDTO.getId().toString()))
            .body(result);
    }

    /**
     * GET  /sub-families : get all the subFamilies.
     *
     * @return the ResponseEntity with status 200 (OK) and the list of subFamilies in body
     */
    @GetMapping("/sub-families")
    @Timed
    public List<SubFamilyDTO> getAllSubFamilies() {
        log.debug("REST request to get all SubFamilies");
        return subFamilyService.findAll();
    }

    /**
     * GET  /sub-families/:id : get the "id" subFamily.
     *
     * @param id the id of the subFamilyDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the subFamilyDTO, or with status 404 (Not Found)
     */
    @GetMapping("/sub-families/{id}")
    @Timed
    public ResponseEntity<SubFamilyDTO> getSubFamily(@PathVariable String id) {
        log.debug("REST request to get SubFamily : {}", id);
        Optional<SubFamilyDTO> subFamilyDTO = subFamilyService.findOne(id);
        return ResponseUtil.wrapOrNotFound(subFamilyDTO);
    }

    /**
     * DELETE  /sub-families/:id : delete the "id" subFamily.
     *
     * @param id the id of the subFamilyDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/sub-families/{id}")
    @Timed
    public ResponseEntity<Void> deleteSubFamily(@PathVariable String id) {
        log.debug("REST request to delete SubFamily : {}", id);
        subFamilyService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id)).build();
    }
}
