package com.onyx.app.service.impl;

import com.onyx.app.service.InvoiceKioskService;
import com.onyx.app.domain.InvoiceKiosk;
import com.onyx.app.repository.InvoiceKioskRepository;
import com.onyx.app.service.dto.InvoiceKioskDTO;
import com.onyx.app.service.mapper.InvoiceKioskMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.stereotype.Service;

import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
/**
 * Service Implementation for managing InvoiceKiosk.
 */
@Service
public class InvoiceKioskServiceImpl implements InvoiceKioskService {

    private final Logger log = LoggerFactory.getLogger(InvoiceKioskServiceImpl.class);

    private final InvoiceKioskRepository invoiceKioskRepository;

    private final InvoiceKioskMapper invoiceKioskMapper;

    public InvoiceKioskServiceImpl(InvoiceKioskRepository invoiceKioskRepository, InvoiceKioskMapper invoiceKioskMapper) {
        this.invoiceKioskRepository = invoiceKioskRepository;
        this.invoiceKioskMapper = invoiceKioskMapper;
    }

    /**
     * Save a invoiceKiosk.
     *
     * @param invoiceKioskDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public InvoiceKioskDTO save(InvoiceKioskDTO invoiceKioskDTO) {
        log.debug("Request to save InvoiceKiosk : {}", invoiceKioskDTO);
        InvoiceKiosk invoiceKiosk = invoiceKioskMapper.toEntity(invoiceKioskDTO);
        invoiceKiosk = invoiceKioskRepository.save(invoiceKiosk);
        return invoiceKioskMapper.toDto(invoiceKiosk);
    }

    /**
     * Get all the invoiceKiosks.
     *
     * @return the list of entities
     */
    @Override
    public List<InvoiceKioskDTO> findAll() {
        log.debug("Request to get all InvoiceKiosks");
        return invoiceKioskRepository.findAll().stream()
            .map(invoiceKioskMapper::toDto)
            .collect(Collectors.toCollection(LinkedList::new));
    }


    /**
     * Get one invoiceKiosk by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    public Optional<InvoiceKioskDTO> findOne(String id) {
        log.debug("Request to get InvoiceKiosk : {}", id);
        return invoiceKioskRepository.findById(id)
            .map(invoiceKioskMapper::toDto);
    }

    /**
     * Delete the invoiceKiosk by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(String id) {
        log.debug("Request to delete InvoiceKiosk : {}", id);
        invoiceKioskRepository.deleteById(id);
    }
}
