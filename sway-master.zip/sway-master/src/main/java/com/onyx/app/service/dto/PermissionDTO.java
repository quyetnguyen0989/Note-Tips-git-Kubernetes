package com.onyx.app.service.dto;

import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import com.onyx.app.domain.enumeration.Language;

/**
 * A DTO for the Employee entity.
 */
public class PermissionDTO implements Serializable {

	private static final long serialVersionUID = -3117875236447377622L;

	private String id;

	@NotNull
	private Boolean setupAccess;

	@NotNull
	private Boolean inventory;

	@NotNull
	private Boolean vendors;

	@NotNull
	private Boolean deptsAdd;

	@NotNull
	private Boolean custmorsAccount;

	@NotNull
	private Boolean reports1;

	@NotNull
	private Boolean reports2;

	@NotNull
	private Boolean invoiceDiscount;

	@NotNull
	private Boolean invoicePricechange;

	@NotNull
	private Boolean invoiceDeleteitems;

	@NotNull
	private Boolean invoiceVoid;

	@NotNull
	private Boolean refundItem;

	@NotNull
	private Boolean transferTable;

	@NotNull
	private Boolean addCcTips;

	@NotNull
	private Boolean disabled;

	@NotNull
	private Boolean printHold;

	@NotNull
	private Boolean openCashDrawer;

	@NotNull
	private Boolean requiredClockin;

	@NotNull
	private Boolean splitChecks;

	@NotNull
	private Boolean transferTables;

	@NotNull
	private Boolean extraItem;

	@NotNull
	private Boolean taxExempt;

	@NotNull
	private Boolean gcSell;

	@NotNull
	private Boolean gcRedeem;

	@NotNull
	private Boolean sellSpecialItem;

	@NotNull
	private Boolean vendorPayout;

	@NotNull
	private Boolean applyGratuity;

	private Boolean picture;

	@NotNull
	private Boolean currentCash;

	@NotNull
	private Boolean cashAlerts;

	@NotNull
	private Boolean cashPickup;

	@NotNull
	private Boolean issueCreditSlip;

	@NotNull
	private Boolean redeemCreditSlip;

	@NotNull
	private Boolean drawerTransfer;

	@NotNull
	private Boolean approveCashcount;

	@NotNull
	private Boolean timeWorkedThisPeriod;

	@NotNull
	private Boolean overtimeThreshold;

	@NotNull
	private Boolean pullbackInvoice;

	@NotNull
	private Boolean performEndofday;

	@NotNull
	private Boolean invoiceDeletesent;

	@NotNull
	private Boolean inventoryAccess1;

	@NotNull
	private Boolean inventoryAccess2;

	@NotNull
	private Boolean comp;

	@NotNull
	private Boolean desConfig;

	@NotNull
	private Boolean transferServer;

	@NotNull
	private Boolean kitchenReprint;

	@NotNull
	private Boolean setupReceiptNotes;

	@NotNull
	private Boolean setupEmployees;

	@NotNull
	private Boolean inventoryPromotions;

	@NotNull
	private Boolean invoiceDiscountsLimit;

	@NotNull
	private Boolean empTimeScheduler;

	@NotNull
	private Boolean negativePriceChange;

	@NotNull
	private Boolean closeShift;

	@NotNull
	private Boolean reprintReceipt;

	private Boolean isAdmin;

	private Boolean isManager;

	private String accessLevel;

	private String accessLevelId;

	private List<String> employees = new ArrayList<>();

	@NotNull
	@Size(max = 8)
	private String pinCode;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Boolean isSetupAccess() {
		return setupAccess;
	}

	public void setSetupAccess(Boolean setupAccess) {
		this.setupAccess = setupAccess;
	}

	public Boolean isInventory() {
		return inventory;
	}

	public void setInventory(Boolean inventory) {
		this.inventory = inventory;
	}

	public Boolean isVendors() {
		return vendors;
	}

	public void setVendors(Boolean vendors) {
		this.vendors = vendors;
	}

	public Boolean isDeptsAdd() {
		return deptsAdd;
	}

	public void setDeptsAdd(Boolean deptsAdd) {
		this.deptsAdd = deptsAdd;
	}

	public Boolean isCustmorsAccount() {
		return custmorsAccount;
	}

	public void setCustmorsAccount(Boolean custmorsAccount) {
		this.custmorsAccount = custmorsAccount;
	}

	public Boolean isReports1() {
		return reports1;
	}

	public void setReports1(Boolean reports1) {
		this.reports1 = reports1;
	}

	public Boolean isReports2() {
		return reports2;
	}

	public void setReports2(Boolean reports2) {
		this.reports2 = reports2;
	}

	public Boolean isInvoiceDiscount() {
		return invoiceDiscount;
	}

	public void setInvoiceDiscount(Boolean invoiceDiscount) {
		this.invoiceDiscount = invoiceDiscount;
	}

	public Boolean isInvoicePricechange() {
		return invoicePricechange;
	}

	public void setInvoicePricechange(Boolean invoicePricechange) {
		this.invoicePricechange = invoicePricechange;
	}

	public Boolean isInvoiceDeleteitems() {
		return invoiceDeleteitems;
	}

	public void setInvoiceDeleteitems(Boolean invoiceDeleteitems) {
		this.invoiceDeleteitems = invoiceDeleteitems;
	}

	public Boolean isInvoiceVoid() {
		return invoiceVoid;
	}

	public void setInvoiceVoid(Boolean invoiceVoid) {
		this.invoiceVoid = invoiceVoid;
	}

	public Boolean isRefundItem() {
		return refundItem;
	}

	public void setRefundItem(Boolean refundItem) {
		this.refundItem = refundItem;
	}

	public Boolean isTransferTable() {
		return transferTable;
	}

	public void setTransferTable(Boolean transferTable) {
		this.transferTable = transferTable;
	}

	public Boolean isAddCcTips() {
		return addCcTips;
	}

	public void setAddCcTips(Boolean addCcTips) {
		this.addCcTips = addCcTips;
	}

	public Boolean isDisabled() {
		return disabled;
	}

	public void setDisabled(Boolean disabled) {
		this.disabled = disabled;
	}

	public Boolean isPrintHold() {
		return printHold;
	}

	public void setPrintHold(Boolean printHold) {
		this.printHold = printHold;
	}

	public Boolean isOpenCashDrawer() {
		return openCashDrawer;
	}

	public void setOpenCashDrawer(Boolean openCashDrawer) {
		this.openCashDrawer = openCashDrawer;
	}

	public Boolean isRequiredClockin() {
		return requiredClockin;
	}

	public void setRequiredClockin(Boolean requiredClockin) {
		this.requiredClockin = requiredClockin;
	}

	public Boolean isSplitChecks() {
		return splitChecks;
	}

	public void setSplitChecks(Boolean splitChecks) {
		this.splitChecks = splitChecks;
	}

	public Boolean isTransferTables() {
		return transferTables;
	}

	public void setTransferTables(Boolean transferTables) {
		this.transferTables = transferTables;
	}

	public Boolean isExtraItem() {
		return extraItem;
	}

	public void setExtraItem(Boolean extraItem) {
		this.extraItem = extraItem;
	}

	public Boolean isTaxExempt() {
		return taxExempt;
	}

	public void setTaxExempt(Boolean taxExempt) {
		this.taxExempt = taxExempt;
	}

	public Boolean isGcSell() {
		return gcSell;
	}

	public void setGcSell(Boolean gcSell) {
		this.gcSell = gcSell;
	}

	public Boolean isGcRedeem() {
		return gcRedeem;
	}

	public void setGcRedeem(Boolean gcRedeem) {
		this.gcRedeem = gcRedeem;
	}

	public Boolean isSellSpecialItem() {
		return sellSpecialItem;
	}

	public void setSellSpecialItem(Boolean sellSpecialItem) {
		this.sellSpecialItem = sellSpecialItem;
	}

	public Boolean isVendorPayout() {
		return vendorPayout;
	}

	public void setVendorPayout(Boolean vendorPayout) {
		this.vendorPayout = vendorPayout;
	}

	public Boolean isApplyGratuity() {
		return applyGratuity;
	}

	public void setApplyGratuity(Boolean applyGratuity) {
		this.applyGratuity = applyGratuity;
	}

	public Boolean isPicture() {
		return picture;
	}

	public void setPicture(Boolean picture) {
		this.picture = picture;
	}

	public Boolean isCurrentCash() {
		return currentCash;
	}

	public void setCurrentCash(Boolean currentCash) {
		this.currentCash = currentCash;
	}

	public Boolean isCashAlerts() {
		return cashAlerts;
	}

	public void setCashAlerts(Boolean cashAlerts) {
		this.cashAlerts = cashAlerts;
	}

	public Boolean isCashPickup() {
		return cashPickup;
	}

	public void setCashPickup(Boolean cashPickup) {
		this.cashPickup = cashPickup;
	}

	public Boolean isIssueCreditSlip() {
		return issueCreditSlip;
	}

	public void setIssueCreditSlip(Boolean issueCreditSlip) {
		this.issueCreditSlip = issueCreditSlip;
	}

	public Boolean isRedeemCreditSlip() {
		return redeemCreditSlip;
	}

	public void setRedeemCreditSlip(Boolean redeemCreditSlip) {
		this.redeemCreditSlip = redeemCreditSlip;
	}

	public Boolean isDrawerTransfer() {
		return drawerTransfer;
	}

	public void setDrawerTransfer(Boolean drawerTransfer) {
		this.drawerTransfer = drawerTransfer;
	}

	public Boolean isApproveCashcount() {
		return approveCashcount;
	}

	public void setApproveCashcount(Boolean approveCashcount) {
		this.approveCashcount = approveCashcount;
	}

	public Boolean isTimeWorkedThisPeriod() {
		return timeWorkedThisPeriod;
	}

	public void setTimeWorkedThisPeriod(Boolean timeWorkedThisPeriod) {
		this.timeWorkedThisPeriod = timeWorkedThisPeriod;
	}

	public Boolean isOvertimeThreshold() {
		return overtimeThreshold;
	}

	public void setOvertimeThreshold(Boolean overtimeThreshold) {
		this.overtimeThreshold = overtimeThreshold;
	}

	public Boolean isPullbackInvoice() {
		return pullbackInvoice;
	}

	public void setPullbackInvoice(Boolean pullbackInvoice) {
		this.pullbackInvoice = pullbackInvoice;
	}

	public Boolean isPerformEndofday() {
		return performEndofday;
	}

	public void setPerformEndofday(Boolean performEndofday) {
		this.performEndofday = performEndofday;
	}

	public Boolean isInvoiceDeletesent() {
		return invoiceDeletesent;
	}

	public void setInvoiceDeletesent(Boolean invoiceDeletesent) {
		this.invoiceDeletesent = invoiceDeletesent;
	}

	public Boolean isInventoryAccess1() {
		return inventoryAccess1;
	}

	public void setInventoryAccess1(Boolean inventoryAccess1) {
		this.inventoryAccess1 = inventoryAccess1;
	}

	public Boolean isInventoryAccess2() {
		return inventoryAccess2;
	}

	public void setInventoryAccess2(Boolean inventoryAccess2) {
		this.inventoryAccess2 = inventoryAccess2;
	}

	public Boolean isComp() {
		return comp;
	}

	public void setComp(Boolean comp) {
		this.comp = comp;
	}

	public Boolean isDesConfig() {
		return desConfig;
	}

	public void setDesConfig(Boolean desConfig) {
		this.desConfig = desConfig;
	}

	public Boolean isTransferServer() {
		return transferServer;
	}

	public void setTransferServer(Boolean transferServer) {
		this.transferServer = transferServer;
	}

	public Boolean isKitchenReprint() {
		return kitchenReprint;
	}

	public void setKitchenReprint(Boolean kitchenReprint) {
		this.kitchenReprint = kitchenReprint;
	}

	public Boolean isSetupReceiptNotes() {
		return setupReceiptNotes;
	}

	public void setSetupReceiptNotes(Boolean setupReceiptNotes) {
		this.setupReceiptNotes = setupReceiptNotes;
	}

	public Boolean isSetupEmployees() {
		return setupEmployees;
	}

	public void setSetupEmployees(Boolean setupEmployees) {
		this.setupEmployees = setupEmployees;
	}

	public Boolean isInventoryPromotions() {
		return inventoryPromotions;
	}

	public void setInventoryPromotions(Boolean inventoryPromotions) {
		this.inventoryPromotions = inventoryPromotions;
	}

	public Boolean isInvoiceDiscountsLimit() {
		return invoiceDiscountsLimit;
	}

	public void setInvoiceDiscountsLimit(Boolean invoiceDiscountsLimit) {
		this.invoiceDiscountsLimit = invoiceDiscountsLimit;
	}

	public Boolean isEmpTimeScheduler() {
		return empTimeScheduler;
	}

	public void setEmpTimeScheduler(Boolean empTimeScheduler) {
		this.empTimeScheduler = empTimeScheduler;
	}

	public Boolean isNegativePriceChange() {
		return negativePriceChange;
	}

	public void setNegativePriceChange(Boolean negativePriceChange) {
		this.negativePriceChange = negativePriceChange;
	}

	public Boolean isCloseShift() {
		return closeShift;
	}

	public void setCloseShift(Boolean closeShift) {
		this.closeShift = closeShift;
	}

	public Boolean isReprintReceipt() {
		return reprintReceipt;
	}

	public void setReprintReceipt(Boolean reprintReceipt) {
		this.reprintReceipt = reprintReceipt;
	}

	public Boolean isIsAdmin() {
		return isAdmin;
	}

	public void setIsAdmin(Boolean isAdmin) {
		this.isAdmin = isAdmin;
	}

	public Boolean isIsManager() {
		return isManager;
	}

	public void setIsManager(Boolean isManager) {
		this.isManager = isManager;
	}

	public String getPinCode() {
		return pinCode;
	}

	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}

	public String getAccessLevel() {
		return accessLevel;
	}

	public void setAccessLevel(String accessLevel) {
		this.accessLevel = accessLevel;
	}

	public String getAccessLevelId() {
		return accessLevelId;
	}

	public void setAccessLevelId(String accessLevelId) {
		this.accessLevelId = accessLevelId;
	}

	public List<String> getEmployees() {
		return employees;
	}

	public void setEmployees(List<String> employees) {
		this.employees = employees;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}

		PermissionDTO employeeDTO = (PermissionDTO) o;
		if (employeeDTO.getId() == null || getId() == null) {
			return false;
		}
		return Objects.equals(getId(), employeeDTO.getId());
	}

	@Override
	public int hashCode() {
		return Objects.hashCode(getId());
	}

	@Override
	public String toString() {
		return "EmployeeDTO{" + "id=" + getId() + ", setupAccess='" + isSetupAccess() + "'" + ", inventory='"
				+ isInventory() + "'" + ", vendors='" + isVendors() + "'" + ", deptsAdd='" + isDeptsAdd() + "'"
				+ ", custmorsAccount='" + isCustmorsAccount() + "'" + ", reports1='" + isReports1() + "'"
				+ ", reports2='" + isReports2() + "'" + ", invoiceDiscount='" + isInvoiceDiscount() + "'"
				+ ", invoicePricechange='" + isInvoicePricechange() + "'" + ", invoiceDeleteitems='"
				+ isInvoiceDeleteitems() + "'" + ", invoiceVoid='" + isInvoiceVoid() + "'" + ", refundItem='"
				+ isRefundItem() + "'" + ", transferTable='" + isTransferTable() + "'" + ", addCcTips='" + isAddCcTips()
				+ "'" + ", disabled='" + isDisabled() + "'" + ", printHold='" + isPrintHold() + "'"
				+ ", openCashDrawer='" + isOpenCashDrawer() + "'" + ", requiredClockin='" + isRequiredClockin() + "'"
				+ ", splitChecks='" + isSplitChecks() + "'" + ", transferTables='" + isTransferTables() + "'"
				+ ", extraItem='" + isExtraItem() + "'" + ", taxExempt='" + isTaxExempt() + "'" + ", gcSell='"
				+ isGcSell() + "'" + ", gcRedeem='" + isGcRedeem() + "'" + ", sellSpecialItem='" + isSellSpecialItem()
				+ "'" + ", vendorPayout='" + isVendorPayout() + "'" + ", applyGratuity='" + isApplyGratuity() + "'"
				+ ", picture='" + isPicture() + "'" + ", currentCash='" + isCurrentCash() + "'" + ", cashAlerts='"
				+ isCashAlerts() + "'" + ", cashPickup='" + isCashPickup() + "'" + ", issueCreditSlip='"
				+ isIssueCreditSlip() + "'" + ", redeemCreditSlip='" + isRedeemCreditSlip() + "'" + ", drawerTransfer='"
				+ isDrawerTransfer() + "'" + ", approveCashcount='" + isApproveCashcount() + "'"
				+ ", timeWorkedThisPeriod='" + isTimeWorkedThisPeriod() + "'" + ", overtimeThreshold='"
				+ isOvertimeThreshold() + "'" + ", pullbackInvoice='" + isPullbackInvoice() + "'"
				+ ", performEndofday='" + isPerformEndofday() + "'" + ", invoiceDeletesent='" + isInvoiceDeletesent()
				+ "'" + ", inventoryAccess1='" + isInventoryAccess1() + "'" + ", inventoryAccess2='"
				+ isInventoryAccess2() + "'" + ", comp='" + isComp() + "'" + ", desConfig='" + isDesConfig() + "'"
				+ ", transferServer='" + isTransferServer() + "'" + ", kitchenReprint='" + isKitchenReprint() + "'"
				+ ", setupReceiptNotes='" + isSetupReceiptNotes() + "'" + ", setupEmployees='" + isSetupEmployees()
				+ "'" + ", inventoryPromotions='" + isInventoryPromotions() + "'" + ", invoiceDiscountsLimit='"
				+ isInvoiceDiscountsLimit() + "'" + ", empTimeScheduler='" + isEmpTimeScheduler() + "'"
				+ ", negativePriceChange='" + isNegativePriceChange() + "'" + ", closeShift='" + isCloseShift() + "'"
				+ ", reprintReceipt='" + isReprintReceipt() + "'" + ", isAdmin='" + isIsAdmin() + "'" + ", isManager='"
				+ isIsManager() + "'" + ", pinCode='" + getPinCode() + "'" + "}";
	}
}
