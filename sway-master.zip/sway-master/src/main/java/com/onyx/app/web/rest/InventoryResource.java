package com.onyx.app.web.rest;

import com.codahale.metrics.annotation.Timed;
import com.onyx.app.domain.Inventory;
import com.onyx.app.domain.Modifier;
import com.onyx.app.repository.InventoryRepository;
import com.onyx.app.repository.ModifierRepository;
import com.onyx.app.service.InventoryService;
import com.onyx.app.web.rest.errors.BadRequestAlertException;
import com.onyx.app.web.rest.errors.BrandException;
import com.onyx.app.web.rest.errors.ErrorMessages;
import com.onyx.app.web.rest.util.HeaderUtil;
import com.onyx.app.service.dto.CustomerInventory;
import com.onyx.app.service.dto.InventoryDTO;
import io.github.jhipster.web.util.ResponseUtil;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * REST controller for managing Inventory.
 */
@RestController
@RequestMapping("/api")
public class InventoryResource {

    private final Logger log = LoggerFactory.getLogger(InventoryResource.class);

    private static final String ENTITY_NAME = "inventory";

    private final InventoryService inventoryService;


    @Autowired
    private InventoryRepository inventoryRepository;
    
    @Autowired
    private ModifierRepository modifierRepository;

    public InventoryResource(InventoryService inventoryService) {
        this.inventoryService = inventoryService;
    }

    /**
     * POST  /inventories : Create a new inventory.
     *
     * @param inventoryDTO the inventoryDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new inventoryDTO, or with status 400 (Bad Request) if the inventory has already an ID
     * @throws Exception 
     */
    @PostMapping("/inventories")
    @Timed
    public ResponseEntity<InventoryDTO> createInventory(@Valid @RequestBody InventoryDTO inventoryDTO) throws Exception {
        log.debug("REST request to save Inventory : {}", inventoryDTO);
        if (inventoryDTO.getId() != null) {
            throw new BadRequestAlertException("A new inventory cannot already have an ID", ENTITY_NAME, "idexists");
        }
        InventoryDTO result = inventoryService.save(inventoryDTO);
        return ResponseEntity.created(new URI("/api/inventories/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /inventories : Updates an existing inventory.
     *
     * @param inventoryDTO the inventoryDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated inventoryDTO,
     * or with status 400 (Bad Request) if the inventoryDTO is not valid,
     * or with status 500 (Internal Server Error) if the inventoryDTO couldn't be updated
     * @throws Exception 
     */
    @PutMapping("/inventories")
    @Timed
    public ResponseEntity<InventoryDTO> updateInventory(@Valid @RequestBody InventoryDTO inventoryDTO) throws Exception {
        log.debug("REST request to update Inventory : {}", inventoryDTO);
        if (inventoryDTO.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        InventoryDTO result = inventoryService.save(inventoryDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, inventoryDTO.getId().toString()))
            .body(result);
    }

    /**
     * GET  /inventories : get all the inventories.
     *
     * @return the ResponseEntity with status 200 (OK) and the list of inventories in body
     */
    @GetMapping("/inventories")
    @Timed
    public List<InventoryDTO> getAllInventories() {
        log.debug("REST request to get all Inventories");
        return inventoryService.findAll();
    }


    /**
     * GET /inventories-dept/:deptId : get all the inventories based on deptId
     * @return the ResponseEntity with status 200 (OK) and the list of inventories in body
     */
    @GetMapping("/inventories-dept/{deptId}")
    @Timed
    public List<Inventory> getAllInventoriesOfDept(@PathVariable Integer deptId){
        log.debug("REST request to get all Inventories of the department");
//        return inventoryRepository.findAllByDeptid(deptId);
        return inventoryRepository.findAll();
    }

//    @GetMapping("/inventories-like")
//    @Timed
//    public List<Inventory> searchOfInventory(@RequestParam (required = false) Integer itemNum ,
//                                             @RequestParam (required = false) String itemName ,
//                                             @RequestParam (required = false) String brand ,
//                                             @RequestParam (required = false) String family ,
//                                             @RequestParam (required = false) String subFamily ,
//                                             @RequestParam (required = false) Double unitSize ,
//                                             @RequestParam (required = false) Integer vendor ,
//                                             @RequestParam (required = false) Integer deptName
//                                             ){
////        if (itemNum == null && itemName.isEmpty() && brand.isEmpty() &&
////            family.isEmpty() && subFamily.isEmpty() && unitSize == null && vendor ==  null && deptName == null) {
////            List<Inventory> inventories = new ArrayList<>();
////            List<InventoryDTO> inventoryDTOS = inventoryService.findAll();
////            BeanUtils.copyProperties(inventoryDTOS , inventories);
////            return  inventories;
////
////        }
//        return inventoryRepository.findAllByItemnumOrItemnameContainingOrBrandOrFamilyOrSubfamilyOrUnitsizeOrVendorpartnumberOrDeptid(
//            itemNum, itemName , brand , family , subFamily , unitSize , vendor , deptName
//        );
//    }

    /**
     * GET  /inventories/:id : get the "id" inventory.
     *
     * @param id the id of the inventoryDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the inventoryDTO, or with status 404 (Not Found)
     */
    @GetMapping("/inventories/{id}")
    @Timed
    public ResponseEntity<InventoryDTO> getInventory(@PathVariable String id) {
        log.debug("REST request to get Inventory : {}", id);
        Optional<InventoryDTO> inventoryDTO = inventoryService.findOne(id);
        return ResponseUtil.wrapOrNotFound(inventoryDTO);
    }
    
    @GetMapping("/inventories/custome/{id}")
    @Timed
    public ResponseEntity<CustomerInventory> getCustomerInventory(@PathVariable String id) {
    	ModelMapper mapper = new ModelMapper();
    	CustomerInventory returnValue = null;
    	List<Modifier> modifiers = new ArrayList<>();
        log.debug("REST request to get Inventory : {}", id);
        Optional<InventoryDTO> inventoryDTO = inventoryService.findOne(id);
        
        if(inventoryDTO.get() != null) {
        	returnValue = mapper.map(inventoryDTO.get(), CustomerInventory.class);
        	for (String  modifierId : inventoryDTO.get().getModifiersIds()) {
        		modifiers.add(modifierRepository.findById(modifierId).orElseThrow(
						() -> new BrandException(ErrorMessages.MODIFIER_NOT_FOUND.getErrorMessage())));
			}
        }
        returnValue.setModifiers(modifiers);
        return ResponseEntity.status(HttpStatus.OK).body(returnValue);
    }
    
    /**
     * DELETE  /inventories/:id : delete the "id" inventory.
     *
     * @param id the id of the inventoryDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/inventories/{id}")
    @Timed
    public ResponseEntity<Void> deleteInventory(@PathVariable String id) {
        log.debug("REST request to delete Inventory : {}", id);
        inventoryService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id)).build();
    }
}
