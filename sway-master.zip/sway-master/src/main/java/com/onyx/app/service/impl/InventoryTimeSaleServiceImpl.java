package com.onyx.app.service.impl;

import com.onyx.app.service.InventoryTimeSaleService;
import com.onyx.app.domain.InventoryTimeSale;
import com.onyx.app.repository.InventoryTimeSaleRepository;
import com.onyx.app.service.dto.InventoryTimeSaleDTO;
import com.onyx.app.service.mapper.InventoryTimeSaleMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.stereotype.Service;

import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
/**
 * Service Implementation for managing InventoryTimeSale.
 */
@Service
public class InventoryTimeSaleServiceImpl implements InventoryTimeSaleService {

    private final Logger log = LoggerFactory.getLogger(InventoryTimeSaleServiceImpl.class);

    private final InventoryTimeSaleRepository inventoryTimeSaleRepository;

    private final InventoryTimeSaleMapper inventoryTimeSaleMapper;

    public InventoryTimeSaleServiceImpl(InventoryTimeSaleRepository inventoryTimeSaleRepository, InventoryTimeSaleMapper inventoryTimeSaleMapper) {
        this.inventoryTimeSaleRepository = inventoryTimeSaleRepository;
        this.inventoryTimeSaleMapper = inventoryTimeSaleMapper;
    }

    /**
     * Save a inventoryTimeSale.
     *
     * @param inventoryTimeSaleDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public InventoryTimeSaleDTO save(InventoryTimeSaleDTO inventoryTimeSaleDTO) {
        log.debug("Request to save InventoryTimeSale : {}", inventoryTimeSaleDTO);
        InventoryTimeSale inventoryTimeSale = inventoryTimeSaleMapper.toEntity(inventoryTimeSaleDTO);
        inventoryTimeSale = inventoryTimeSaleRepository.save(inventoryTimeSale);
        return inventoryTimeSaleMapper.toDto(inventoryTimeSale);
    }

    /**
     * Get all the inventoryTimeSales.
     *
     * @return the list of entities
     */
    @Override
    public List<InventoryTimeSaleDTO> findAll() {
        log.debug("Request to get all InventoryTimeSales");
        return inventoryTimeSaleRepository.findAll().stream()
            .map(inventoryTimeSaleMapper::toDto)
            .collect(Collectors.toCollection(LinkedList::new));
    }


    /**
     * Get one inventoryTimeSale by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    public Optional<InventoryTimeSaleDTO> findOne(String id) {
        log.debug("Request to get InventoryTimeSale : {}", id);
        return inventoryTimeSaleRepository.findById(id)
            .map(inventoryTimeSaleMapper::toDto);
    }

    /**
     * Delete the inventoryTimeSale by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(String id) {
        log.debug("Request to delete InventoryTimeSale : {}", id);
        inventoryTimeSaleRepository.deleteById(id);
    }
}
