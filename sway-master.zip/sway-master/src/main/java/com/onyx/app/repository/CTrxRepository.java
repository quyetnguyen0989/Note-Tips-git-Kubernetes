package com.onyx.app.repository;

import org.springframework.stereotype.Repository;

import com.onyx.app.domain.CTrx;

/**
 * Spring Data MongoDB repository for the CTrx entity.
 */
@SuppressWarnings("unused")
@Repository
public interface CTrxRepository extends N1qlCouchbaseRepository<CTrx, String> {

}
