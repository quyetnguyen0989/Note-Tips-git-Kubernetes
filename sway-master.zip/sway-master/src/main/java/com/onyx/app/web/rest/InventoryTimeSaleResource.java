package com.onyx.app.web.rest;

import com.codahale.metrics.annotation.Timed;
import com.onyx.app.service.InventoryTimeSaleService;
import com.onyx.app.web.rest.errors.BadRequestAlertException;
import com.onyx.app.web.rest.util.HeaderUtil;
import com.onyx.app.service.dto.InventoryTimeSaleDTO;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;

import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing InventoryTimeSale.
 */
@RestController
@RequestMapping("/api")
public class InventoryTimeSaleResource {

    private final Logger log = LoggerFactory.getLogger(InventoryTimeSaleResource.class);

    private static final String ENTITY_NAME = "inventoryTimeSale";

    private final InventoryTimeSaleService inventoryTimeSaleService;

    public InventoryTimeSaleResource(InventoryTimeSaleService inventoryTimeSaleService) {
        this.inventoryTimeSaleService = inventoryTimeSaleService;
    }

    /**
     * POST  /inventory-time-sales : Create a new inventoryTimeSale.
     *
     * @param inventoryTimeSaleDTO the inventoryTimeSaleDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new inventoryTimeSaleDTO, or with status 400 (Bad Request) if the inventoryTimeSale has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/inventory-time-sales")
    @Timed
    public ResponseEntity<InventoryTimeSaleDTO> createInventoryTimeSale(@Valid @RequestBody InventoryTimeSaleDTO inventoryTimeSaleDTO) throws URISyntaxException {
        log.debug("REST request to save InventoryTimeSale : {}", inventoryTimeSaleDTO);
        if (inventoryTimeSaleDTO.getId() != null) {
            throw new BadRequestAlertException("A new inventoryTimeSale cannot already have an ID", ENTITY_NAME, "idexists");
        }
        InventoryTimeSaleDTO result = inventoryTimeSaleService.save(inventoryTimeSaleDTO);
        return ResponseEntity.created(new URI("/api/inventory-time-sales/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /inventory-time-sales : Updates an existing inventoryTimeSale.
     *
     * @param inventoryTimeSaleDTO the inventoryTimeSaleDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated inventoryTimeSaleDTO,
     * or with status 400 (Bad Request) if the inventoryTimeSaleDTO is not valid,
     * or with status 500 (Internal Server Error) if the inventoryTimeSaleDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/inventory-time-sales")
    @Timed
    public ResponseEntity<InventoryTimeSaleDTO> updateInventoryTimeSale(@Valid @RequestBody InventoryTimeSaleDTO inventoryTimeSaleDTO) throws URISyntaxException {
        log.debug("REST request to update InventoryTimeSale : {}", inventoryTimeSaleDTO);
        if (inventoryTimeSaleDTO.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        InventoryTimeSaleDTO result = inventoryTimeSaleService.save(inventoryTimeSaleDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, inventoryTimeSaleDTO.getId().toString()))
            .body(result);
    }

    /**
     * GET  /inventory-time-sales : get all the inventoryTimeSales.
     *
     * @return the ResponseEntity with status 200 (OK) and the list of inventoryTimeSales in body
     */
    @GetMapping("/inventory-time-sales")
    @Timed
    public List<InventoryTimeSaleDTO> getAllInventoryTimeSales() {
        log.debug("REST request to get all InventoryTimeSales");
        return inventoryTimeSaleService.findAll();
    }

    /**
     * GET  /inventory-time-sales/:id : get the "id" inventoryTimeSale.
     *
     * @param id the id of the inventoryTimeSaleDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the inventoryTimeSaleDTO, or with status 404 (Not Found)
     */
    @GetMapping("/inventory-time-sales/{id}")
    @Timed
    public ResponseEntity<InventoryTimeSaleDTO> getInventoryTimeSale(@PathVariable String id) {
        log.debug("REST request to get InventoryTimeSale : {}", id);
        Optional<InventoryTimeSaleDTO> inventoryTimeSaleDTO = inventoryTimeSaleService.findOne(id);
        return ResponseUtil.wrapOrNotFound(inventoryTimeSaleDTO);
    }

    /**
     * DELETE  /inventory-time-sales/:id : delete the "id" inventoryTimeSale.
     *
     * @param id the id of the inventoryTimeSaleDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/inventory-time-sales/{id}")
    @Timed
    public ResponseEntity<Void> deleteInventoryTimeSale(@PathVariable String id) {
        log.debug("REST request to delete InventoryTimeSale : {}", id);
        inventoryTimeSaleService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id)).build();
    }
}
