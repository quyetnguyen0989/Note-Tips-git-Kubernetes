package com.onyx.app.repository;

import com.onyx.app.domain.Dept;
import com.onyx.app.service.dto.DeptDTO;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Spring Data Couchbase repository for the Dept entity.
 */
@SuppressWarnings("unused")
@Repository
public interface DeptRepository extends N1qlCouchbaseRepository<Dept, String> {

    List<Dept> findAllByStoreId(Integer storeId);
}
