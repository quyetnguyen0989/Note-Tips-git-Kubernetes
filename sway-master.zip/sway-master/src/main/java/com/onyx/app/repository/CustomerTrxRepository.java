package com.onyx.app.repository;

import org.springframework.stereotype.Repository;

import com.onyx.app.domain.CustomerTrx;

/**
 * Spring Data MongoDB repository for the CustomerTrx entity.
 */
@SuppressWarnings("unused")
@Repository
public interface CustomerTrxRepository extends N1qlCouchbaseRepository<CustomerTrx, String> {

}
