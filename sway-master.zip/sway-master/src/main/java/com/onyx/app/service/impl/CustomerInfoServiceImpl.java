package com.onyx.app.service.impl;

import com.onyx.app.service.CustomerInfoService;
import com.onyx.app.domain.CustomerInfo;
import com.onyx.app.repository.CustomerInfoRepository;
import com.onyx.app.service.dto.CustomerInfoDTO;
import com.onyx.app.service.mapper.CustomerInfoMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.stereotype.Service;

import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
/**
 * Service Implementation for managing CustomerInfo.
 */
@Service
public class CustomerInfoServiceImpl implements CustomerInfoService {

    private final Logger log = LoggerFactory.getLogger(CustomerInfoServiceImpl.class);

    private final CustomerInfoRepository customerInfoRepository;

    private final CustomerInfoMapper customerInfoMapper;

    public CustomerInfoServiceImpl(CustomerInfoRepository customerInfoRepository, CustomerInfoMapper customerInfoMapper) {
        this.customerInfoRepository = customerInfoRepository;
        this.customerInfoMapper = customerInfoMapper;
    }

    /**
     * Save a customerInfo.
     *
     * @param customerInfoDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public CustomerInfoDTO save(CustomerInfoDTO customerInfoDTO) {
        log.debug("Request to save CustomerInfo : {}", customerInfoDTO);
        CustomerInfo customerInfo = customerInfoMapper.toEntity(customerInfoDTO);
        customerInfo = customerInfoRepository.save(customerInfo);
        return customerInfoMapper.toDto(customerInfo);
    }

    /**
     * Get all the customerInfos.
     *
     * @return the list of entities
     */
    @Override
    public List<CustomerInfoDTO> findAll() {
        log.debug("Request to get all CustomerInfos");
        return customerInfoRepository.findAll().stream()
            .map(customerInfoMapper::toDto)
            .collect(Collectors.toCollection(LinkedList::new));
    }


    /**
     * Get one customerInfo by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    public Optional<CustomerInfoDTO> findOne(String id) {
        log.debug("Request to get CustomerInfo : {}", id);
        return customerInfoRepository.findById(id)
            .map(customerInfoMapper::toDto);
    }

    /**
     * Delete the customerInfo by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(String id) {
        log.debug("Request to delete CustomerInfo : {}", id);
        customerInfoRepository.deleteById(id);
    }
}
