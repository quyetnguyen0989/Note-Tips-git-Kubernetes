package com.onyx.app.web.rest;
import com.onyx.app.domain.StoreLocal;
import com.onyx.app.repository.StoreLocalRepository;
import com.onyx.app.repository.StoreTimeRepository;
import com.onyx.app.service.StoreLocalService;
import com.onyx.app.web.rest.errors.BadRequestAlertException;
import com.onyx.app.web.rest.util.HeaderUtil;
import com.onyx.app.service.dto.StoreLocalDTO;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing StoreLocal.
 */
@RestController
@RequestMapping("/api")
public class StoreLocalResource {

    private final Logger log = LoggerFactory.getLogger(StoreLocalResource.class);

    private static final String ENTITY_NAME = "storeLocal";

    private final StoreLocalService storeLocalService;

    @Autowired
    private StoreTimeRepository storeTimeRepository;

    @Autowired
    private StoreLocalRepository storeLocalRepository;

    public StoreLocalResource(StoreLocalService storeLocalService) {
        this.storeLocalService = storeLocalService;
    }

    /**
     * POST  /store-locals : Create a new storeLocal.
     *
     * @param storeLocalDTO the storeLocalDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new storeLocalDTO, or with status 400 (Bad Request) if the storeLocal has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/store-locals")
    public ResponseEntity<StoreLocalDTO> createStoreLocal(@Valid @RequestBody StoreLocalDTO storeLocalDTO) throws URISyntaxException {
        log.debug("REST request to save StoreLocal : {}", storeLocalDTO);
        if (storeLocalDTO.getId() != null) {
            throw new BadRequestAlertException("A new storeLocal cannot already have an ID", ENTITY_NAME, "idexists");
        }
        StoreLocalDTO result = storeLocalService.save(storeLocalDTO);
        return ResponseEntity.created(new URI("/api/store-locals/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /store-locals : Updates an existing storeLocal.
     *
     * @param storeLocalDTO the storeLocalDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated storeLocalDTO,
     * or with status 400 (Bad Request) if the storeLocalDTO is not valid,
     * or with status 500 (Internal Server Error) if the storeLocalDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/store-locals")
    public ResponseEntity<StoreLocalDTO> updateStoreLocal(@Valid @RequestBody StoreLocalDTO storeLocalDTO) throws URISyntaxException {
        log.debug("REST request to update StoreLocal : {}", storeLocalDTO);
        if (storeLocalDTO.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        StoreLocalDTO result = storeLocalService.save(storeLocalDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, storeLocalDTO.getId().toString()))
            .body(result);
    }

    /**
     * GET  /store-locals : get all the storeLocals.
     *
     * @return the ResponseEntity with status 200 (OK) and the list of storeLocals in body
     */
    @GetMapping("/store-locals")
    public ResponseEntity<List<StoreLocal>> getAllStoreLocals() {
        log.debug("REST request to get all StoreLocals");
        List<StoreLocal> storeLocals = storeLocalRepository.findAll();
        List<StoreLocal> results = new ArrayList<>();
        storeLocals.stream().forEach(storeLocalDTO -> {
            storeTimeRepository.findAllByStoreId(storeLocalDTO.getStoreId()).stream().forEach(storeTime -> {
                LocalTime startTime = storeTime.getFrom().atZone(ZoneOffset.UTC).toLocalTime();
                LocalTime endTime = storeTime.getTo().atZone(ZoneOffset.UTC).toLocalTime();
                LocalTime now = LocalTime.now();
                String day = LocalDate.now().getDayOfWeek().name();
                if (day.equals(storeTime.getDay().name())) {
                    if (now.isBefore(endTime) && now.isAfter(startTime)) {
//                        isFlag = true;
                        storeLocalDTO.setOpen(true);
                        storeLocalDTO.setTimeText("Close " + endTime.format(DateTimeFormatter.ofPattern("hh:mm a")));
                        StoreLocal result = storeLocalRepository.save(storeLocalDTO);
                        results.add(result);

                    }else {
                            storeLocalDTO.setOpen(false);
                            storeLocalDTO.setTimeText("Open " + startTime.format(DateTimeFormatter.ofPattern("hh:mm a")));
                            StoreLocal result = storeLocalRepository.save(storeLocalDTO);
                            results.add(result);
                    }
                }
            });
        });
        return new ResponseEntity<>(results , HttpStatus.OK);
    }

    /**
     * GET  /store-locals/:id : get the "id" storeLocal.
     *
     * @param id the id of the storeLocalDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the storeLocalDTO, or with status 404 (Not Found)
     */
    @GetMapping("/store-locals/{id}")
    public ResponseEntity<StoreLocalDTO> getStoreLocal(@PathVariable String id) {
        log.debug("REST request to get StoreLocal : {}", id);
        Optional<StoreLocalDTO> storeLocalDTO = storeLocalService.findOne(id);
        return ResponseUtil.wrapOrNotFound(storeLocalDTO);
    }

    /**
     * DELETE  /store-locals/:id : delete the "id" storeLocal.
     *
     * @param id the id of the storeLocalDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/store-locals/{id}")
    public ResponseEntity<Void> deleteStoreLocal(@PathVariable String id) {
        log.debug("REST request to delete StoreLocal : {}", id);
        storeLocalService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id)).build();
    }
}
