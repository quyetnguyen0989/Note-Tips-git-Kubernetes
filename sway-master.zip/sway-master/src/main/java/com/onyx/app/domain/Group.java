package com.onyx.app.domain;

import org.springframework.data.annotation.Id;
import com.couchbase.client.java.repository.annotation.Field;
import org.springframework.data.couchbase.core.mapping.Document;
import javax.validation.constraints.*;

import java.io.Serializable;
import java.util.Objects;

/**
 * A Group.
 */
@Document
public class Group implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    private String id;

    @Size(max = 25)
    @Field("item_num")
    private String itemNum;

    @Size(max = 50)
    @Field("item_name")
    private String itemName;

    @NotNull
    @Field("store_id")
    private Integer storeId;

    @Field("group_id")
    private Integer groupID;

    @Field("group_line")
    private Integer groupLine;

    @Field("group_name")
    private String groupName;

    @Field("item_type")
    private String itemType;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getItemNum() {
        return itemNum;
    }

    public Group itemNum(String itemNum) {
        this.itemNum = itemNum;
        return this;
    }

    public void setItemNum(String itemNum) {
        this.itemNum = itemNum;
    }

    public String getItemName() {
        return itemName;
    }

    public Group itemName(String itemName) {
        this.itemName = itemName;
        return this;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public Integer getStoreId() {
        return storeId;
    }

    public Group storeId(Integer storeId) {
        this.storeId = storeId;
        return this;
    }

    public void setStoreId(Integer storeId) {
        this.storeId = storeId;
    }

    public Integer getGroupID() {
        return groupID;
    }

    public Group groupID(Integer groupID) {
        this.groupID = groupID;
        return this;
    }

    public void setGroupID(Integer groupID) {
        this.groupID = groupID;
    }

    public Integer getGroupLine() {
        return groupLine;
    }

    public Group groupLine(Integer groupLine) {
        this.groupLine = groupLine;
        return this;
    }

    public void setGroupLine(Integer groupLine) {
        this.groupLine = groupLine;
    }

    public String getGroupName() {
        return groupName;
    }

    public Group groupName(String groupName) {
        this.groupName = groupName;
        return this;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public String getItemType() {
        return itemType;
    }

    public Group itemType(String itemType) {
        this.itemType = itemType;
        return this;
    }

    public void setItemType(String itemType) {
        this.itemType = itemType;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Group group = (Group) o;
        if (group.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), group.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "Group{" +
            "id=" + getId() +
            ", itemNum='" + getItemNum() + "'" +
            ", itemName='" + getItemName() + "'" +
            ", storeId=" + getStoreId() +
            ", groupID=" + getGroupID() +
            ", groupLine=" + getGroupLine() +
            ", groupName='" + getGroupName() + "'" +
            ", itemType='" + getItemType() + "'" +
            "}";
    }
}
