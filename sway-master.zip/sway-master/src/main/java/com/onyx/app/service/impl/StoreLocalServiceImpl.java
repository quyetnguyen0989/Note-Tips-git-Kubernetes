package com.onyx.app.service.impl;

import com.onyx.app.service.StoreLocalService;
import com.onyx.app.domain.StoreLocal;
import com.onyx.app.repository.StoreLocalRepository;
import com.onyx.app.service.dto.StoreLocalDTO;
import com.onyx.app.service.mapper.StoreLocalMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.stereotype.Service;

import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Service Implementation for managing StoreLocal.
 */
@Service
public class StoreLocalServiceImpl implements StoreLocalService {

    private final Logger log = LoggerFactory.getLogger(StoreLocalServiceImpl.class);

    private final StoreLocalRepository storeLocalRepository;

    private final StoreLocalMapper storeLocalMapper;

    public StoreLocalServiceImpl(StoreLocalRepository storeLocalRepository, StoreLocalMapper storeLocalMapper) {
        this.storeLocalRepository = storeLocalRepository;
        this.storeLocalMapper = storeLocalMapper;
    }

    /**
     * Save a storeLocal.
     *
     * @param storeLocalDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public StoreLocalDTO save(StoreLocalDTO storeLocalDTO) {
        log.debug("Request to save StoreLocal : {}", storeLocalDTO);
        StoreLocal storeLocal = storeLocalMapper.toEntity(storeLocalDTO);
        if (storeLocalDTO.getOpen() != null) {
            storeLocal.setOpen(storeLocalDTO.getOpen());
        }
        storeLocal = storeLocalRepository.save(storeLocal);
        return storeLocalMapper.toDto(storeLocal);
    }

    /**
     * Get all the storeLocals.
     *
     * @return the list of entities
     */
    @Override
    public List<StoreLocalDTO> findAll() {
        log.debug("Request to get all StoreLocals");
        return storeLocalRepository.findAll().stream()
            .map(storeLocalMapper::toDto)
            .collect(Collectors.toCollection(LinkedList::new));
    }


    /**
     * Get one storeLocal by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    public Optional<StoreLocalDTO> findOne(String id) {
        log.debug("Request to get StoreLocal : {}", id);
        return storeLocalRepository.findById(id)
            .map(storeLocalMapper::toDto);
    }

    /**
     * Delete the storeLocal by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(String id) {
        log.debug("Request to delete StoreLocal : {}", id);
        storeLocalRepository.deleteById(id);
    }
}
