package com.onyx.app.repository;

import com.onyx.app.domain.InventoryAttribute;
import org.springframework.stereotype.Repository;

/**
 * Spring Data Couchbase repository for the InventoryAttribute entity.
 */
@SuppressWarnings("unused")
@Repository
public interface InventoryAttributeRepository extends N1qlCouchbaseRepository<InventoryAttribute, String> {

}
