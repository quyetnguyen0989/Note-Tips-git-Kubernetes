package com.onyx.app.service.mapper;

import com.onyx.app.domain.*;
import com.onyx.app.service.dto.SubFamilyDTO;

import org.mapstruct.*;

/**
 * Mapper for the entity SubFamily and its DTO SubFamilyDTO.
 */
@Mapper(componentModel = "spring", uses = {})
public interface SubFamilyMapper extends EntityMapper<SubFamilyDTO, SubFamily> {


}
