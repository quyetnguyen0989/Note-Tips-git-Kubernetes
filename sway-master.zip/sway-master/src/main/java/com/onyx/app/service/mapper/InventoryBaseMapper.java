package com.onyx.app.service.mapper;

import com.onyx.app.domain.Inventory;
import com.onyx.app.service.dto.InventoryBaseDTO;
import org.mapstruct.Mapper;

/**
 * Mapper for the entity Inventory and its DTO InventoryQuick.
 */
@Mapper(componentModel = "spring", uses = {})
public interface InventoryBaseMapper extends EntityMapper<InventoryBaseDTO, Inventory> {


}
