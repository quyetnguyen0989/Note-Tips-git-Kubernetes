package com.onyx.app.service.dto;
import java.time.Instant;
import java.io.Serializable;
import java.util.Objects;

/**
 * A DTO for the FeItems entity.
 */
public class FeItemsDTO implements Serializable {

    private String id;

    private Integer storeId;

    private String deptId;

    private String itemName;

    private Long itemNum;

    private Double cost;

    private Integer itemId;

    private Double itemPrice;

    private Boolean itemhasMods;

    private Boolean itemImg;

    private Boolean itemSpcl;

    private Boolean itemOnHH;

    private Instant hhTimeStart;

    private Instant hhTimeEnd;

    private Double hhPrice;

    private String imgUrl;

    private Double itemSpclPrice;


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getStoreId() {
        return storeId;
    }

    public void setStoreId(Integer storeId) {
        this.storeId = storeId;
    }

    public String getDeptId() {
        return deptId;
    }

    public void setDeptId(String deptId) {
        this.deptId = deptId;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public Long getItemNum() {
        return itemNum;
    }

    public void setItemNum(Long itemNum) {
        this.itemNum = itemNum;
    }

    public Double getCost() {
        return cost;
    }

    public void setCost(Double cost) {
        this.cost = cost;
    }

    public Integer getItemId() {
        return itemId;
    }

    public void setItemId(Integer itemId) {
        this.itemId = itemId;
    }

    public Double getItemPrice() {
        return itemPrice;
    }

    public void setItemPrice(Double itemPrice) {
        this.itemPrice = itemPrice;
    }

    public Boolean isItemhasMods() {
        return itemhasMods;
    }

    public void setItemhasMods(Boolean itemhasMods) {
        this.itemhasMods = itemhasMods;
    }

    public Boolean isItemImg() {
        return itemImg;
    }

    public void setItemImg(Boolean itemImg) {
        this.itemImg = itemImg;
    }

    public Boolean isItemSpcl() {
        return itemSpcl;
    }

    public void setItemSpcl(Boolean itemSpcl) {
        this.itemSpcl = itemSpcl;
    }

    public Boolean isItemOnHH() {
        return itemOnHH;
    }

    public void setItemOnHH(Boolean itemOnHH) {
        this.itemOnHH = itemOnHH;
    }

    public Instant getHhTimeStart() {
        return hhTimeStart;
    }

    public void setHhTimeStart(Instant hhTimeStart) {
        this.hhTimeStart = hhTimeStart;
    }

    public Instant getHhTimeEnd() {
        return hhTimeEnd;
    }

    public void setHhTimeEnd(Instant hhTimeEnd)
    {
        this.hhTimeEnd = hhTimeEnd;
    }

    public Double getHhPrice() {
        return hhPrice;
    }

    public void setHhPrice(Double hhPrice) {
        this.hhPrice = hhPrice;
    }

    public String getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }

    public Double getItemSpclPrice() {
        return itemSpclPrice;
    }

    public void setItemSpclPrice(Double itemSpclPrice) {
        this.itemSpclPrice = itemSpclPrice;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        FeItemsDTO feItemsDTO = (FeItemsDTO) o;
        if (feItemsDTO.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), feItemsDTO.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "FeItemsDTO{" +
            "id=" + getId() +
            ", storeId=" + getStoreId() +
            ", deptId='" + getDeptId() + "'" +
            ", itemName='" + getItemName() + "'" +
            ", itemNum=" + getItemNum() +
            ", cost=" + getCost() +
            ", itemId=" + getItemId() +
            ", itemPrice=" + getItemPrice() +
            ", itemhasMods='" + isItemhasMods() + "'" +
            ", itemImg='" + isItemImg() + "'" +
            ", itemSpcl='" + isItemSpcl() + "'" +
            ", itemOnHH='" + isItemOnHH() + "'" +
            ", hhTimeStart='" + getHhTimeStart() + "'" +
            ", hhTimeEnd='" + getHhTimeEnd() + "'" +
            ", hhPrice='" + getHhPrice() + "'" +
            ", imgUrl='" + getImgUrl() + "'" +
            "}";
    }
}
