package com.onyx.app.web.rest;

import com.codahale.metrics.annotation.Timed;
import com.onyx.app.service.InventoryAttributeService;
import com.onyx.app.web.rest.errors.BadRequestAlertException;
import com.onyx.app.web.rest.util.HeaderUtil;
import com.onyx.app.service.dto.InventoryAttributeDTO;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;

import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing InventoryAttribute.
 */
@RestController
@RequestMapping("/api")
public class InventoryAttributeResource {

    private final Logger log = LoggerFactory.getLogger(InventoryAttributeResource.class);

    private static final String ENTITY_NAME = "inventoryAttribute";

    private final InventoryAttributeService inventoryAttributeService;

    public InventoryAttributeResource(InventoryAttributeService inventoryAttributeService) {
        this.inventoryAttributeService = inventoryAttributeService;
    }

    /**
     * POST  /inventory-attributes : Create a new inventoryAttribute.
     *
     * @param inventoryAttributeDTO the inventoryAttributeDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new inventoryAttributeDTO, or with status 400 (Bad Request) if the inventoryAttribute has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/inventory-attributes")
    @Timed
    public ResponseEntity<InventoryAttributeDTO> createInventoryAttribute(@Valid @RequestBody InventoryAttributeDTO inventoryAttributeDTO) throws URISyntaxException {
        log.debug("REST request to save InventoryAttribute : {}", inventoryAttributeDTO);
        if (inventoryAttributeDTO.getId() != null) {
            throw new BadRequestAlertException("A new inventoryAttribute cannot already have an ID", ENTITY_NAME, "idexists");
        }
        InventoryAttributeDTO result = inventoryAttributeService.save(inventoryAttributeDTO);
        return ResponseEntity.created(new URI("/api/inventory-attributes/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /inventory-attributes : Updates an existing inventoryAttribute.
     *
     * @param inventoryAttributeDTO the inventoryAttributeDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated inventoryAttributeDTO,
     * or with status 400 (Bad Request) if the inventoryAttributeDTO is not valid,
     * or with status 500 (Internal Server Error) if the inventoryAttributeDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/inventory-attributes")
    @Timed
    public ResponseEntity<InventoryAttributeDTO> updateInventoryAttribute(@Valid @RequestBody InventoryAttributeDTO inventoryAttributeDTO) throws URISyntaxException {
        log.debug("REST request to update InventoryAttribute : {}", inventoryAttributeDTO);
        if (inventoryAttributeDTO.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        InventoryAttributeDTO result = inventoryAttributeService.save(inventoryAttributeDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, inventoryAttributeDTO.getId().toString()))
            .body(result);
    }

    /**
     * GET  /inventory-attributes : get all the inventoryAttributes.
     *
     * @return the ResponseEntity with status 200 (OK) and the list of inventoryAttributes in body
     */
    @GetMapping("/inventory-attributes")
    @Timed
    public List<InventoryAttributeDTO> getAllInventoryAttributes() {
        log.debug("REST request to get all InventoryAttributes");
        return inventoryAttributeService.findAll();
    }

    /**
     * GET  /inventory-attributes/:id : get the "id" inventoryAttribute.
     *
     * @param id the id of the inventoryAttributeDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the inventoryAttributeDTO, or with status 404 (Not Found)
     */
    @GetMapping("/inventory-attributes/{id}")
    @Timed
    public ResponseEntity<InventoryAttributeDTO> getInventoryAttribute(@PathVariable String id) {
        log.debug("REST request to get InventoryAttribute : {}", id);
        Optional<InventoryAttributeDTO> inventoryAttributeDTO = inventoryAttributeService.findOne(id);
        return ResponseUtil.wrapOrNotFound(inventoryAttributeDTO);
    }

    /**
     * DELETE  /inventory-attributes/:id : delete the "id" inventoryAttribute.
     *
     * @param id the id of the inventoryAttributeDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/inventory-attributes/{id}")
    @Timed
    public ResponseEntity<Void> deleteInventoryAttribute(@PathVariable String id) {
        log.debug("REST request to delete InventoryAttribute : {}", id);
        inventoryAttributeService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id)).build();
    }
}
