package com.onyx.app.repository;

import com.onyx.app.domain.Customertrx;
import org.springframework.stereotype.Repository;

/**
 * Spring Data Couchbase repository for the Customertrx entity.
 */
@SuppressWarnings("unused")
@Repository
public interface CustomertrxRepository extends N1qlCouchbaseRepository<Customertrx, String> {

}
