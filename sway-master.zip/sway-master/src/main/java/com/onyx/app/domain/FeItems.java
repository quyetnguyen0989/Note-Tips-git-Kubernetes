package com.onyx.app.domain;


import org.springframework.data.annotation.Id;
import com.couchbase.client.java.repository.annotation.Field;
import org.springframework.data.couchbase.core.mapping.Document;
import org.springframework.data.couchbase.core.mapping.id.GeneratedValue;
import org.springframework.data.couchbase.core.mapping.id.IdPrefix;

import java.io.Serializable;
import java.time.Instant;
import java.util.Objects;

import static com.onyx.app.config.Constants.ID_DELIMITER;
import static org.springframework.data.couchbase.core.mapping.id.GenerationStrategy.UNIQUE;

/**
 * A FeItems.
 */
@Document
public class FeItems implements Serializable {

    private static final long serialVersionUID = 1L;
    public static final String PREFIX = "feitems";

    @SuppressWarnings("unused")
    @IdPrefix
    private String prefix = PREFIX;

    @Id
    @GeneratedValue(strategy = UNIQUE, delimiter = ID_DELIMITER)
    private String id;

    @Field("store_id")
    private Integer storeId;

    @Field("dept_id")
    private String deptId;

    @Field("item_name")
    private String itemName;

    @Field("item_num")
    private Long itemNum;

    @Field("cost")
    private Double cost;

    @Field("item_id")
    private Integer itemId;

    @Field("item_price")
    private Double itemPrice;

    @Field("itemhas_mods")
    private Boolean itemhasMods;

    @Field("item_img")
    private Boolean itemImg;

    @Field("item_spcl")
    private Boolean itemSpcl;

    @Field("item_on_hh")
    private Boolean itemOnHH;

    @Field("hh_time_start")
    private Instant hhTimeStart;

    @Field("hh_time_end")
    private Instant hhTimeEnd;

    @Field("hh_price")
    private Double hhPrice;

    @Field("img_url")
    private String imgUrl;

    @Field("item_spcl_price")
    private Double itemSpclPrice;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getStoreId() {
        return storeId;
    }

    public FeItems storeId(Integer storeId) {
        this.storeId = storeId;
        return this;
    }

    public void setStoreId(Integer storeId) {
        this.storeId = storeId;
    }

    public String getDeptId() {
        return deptId;
    }

    public FeItems deptId(String deptId) {
        this.deptId = deptId;
        return this;
    }

    public void setDeptId(String deptId) {
        this.deptId = deptId;
    }

    public String getItemName() {
        return itemName;
    }

    public FeItems itemName(String itemName) {
        this.itemName = itemName;
        return this;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public Long getItemNum() {
        return itemNum;
    }

    public FeItems itemNum(Long itemNum) {
        this.itemNum = itemNum;
        return this;
    }

    public void setItemNum(Long itemNum) {
        this.itemNum = itemNum;
    }

    public Double getCost() {
        return cost;
    }

    public FeItems cost(Double cost) {
        this.cost = cost;
        return this;
    }

    public void setCost(Double cost) {
        this.cost = cost;
    }

    public Integer getItemId() {
        return itemId;
    }

    public FeItems itemId(Integer itemId) {
        this.itemId = itemId;
        return this;
    }

    public void setItemId(Integer itemId) {
        this.itemId = itemId;
    }

    public Double getItemPrice() {
        return itemPrice;
    }

    public FeItems itemPrice(Double itemPrice) {
        this.itemPrice = itemPrice;
        return this;
    }

    public void setItemPrice(Double itemPrice) {
        this.itemPrice = itemPrice;
    }

    public Boolean isItemhasMods() {
        return itemhasMods;
    }

    public FeItems itemhasMods(Boolean itemhasMods) {
        this.itemhasMods = itemhasMods;
        return this;
    }

    public void setItemhasMods(Boolean itemhasMods) {
        this.itemhasMods = itemhasMods;
    }

    public Boolean isItemImg() {
        return itemImg;
    }

    public FeItems itemImg(Boolean itemImg) {
        this.itemImg = itemImg;
        return this;
    }

    public void setItemImg(Boolean itemImg) {
        this.itemImg = itemImg;
    }

    public Boolean isItemSpcl() {
        return itemSpcl;
    }

    public FeItems itemSpcl(Boolean itemSpcl) {
        this.itemSpcl = itemSpcl;
        return this;
    }

    public void setItemSpcl(Boolean itemSpcl) {
        this.itemSpcl = itemSpcl;
    }

    public Boolean isItemOnHH() {
        return itemOnHH;
    }

    public FeItems itemOnHH(Boolean itemOnHH) {
        this.itemOnHH = itemOnHH;
        return this;
    }

    public void setItemOnHH(Boolean itemOnHH) {
        this.itemOnHH = itemOnHH;
    }

    public Instant getHhTimeStart() {
        return hhTimeStart;
    }

    public FeItems hhTimeStart(Instant hhTimeStart) {
        this.hhTimeStart = hhTimeStart;
        return this;
    }

    public void setHhTimeStart(Instant hhTimeStart) {
        this.hhTimeStart = hhTimeStart;
    }

    public Instant getHhTimeEnd() {
        return hhTimeEnd;
    }

    public FeItems hhTimeEnd(Instant hhTimeEnd) {
        this.hhTimeEnd = hhTimeEnd;
        return this;
    }

    public String getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }

    public void setHhTimeEnd(Instant hhTimeEnd) {
        this.hhTimeEnd = hhTimeEnd;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove


    public Double getHhPrice() {
        return hhPrice;
    }

    public void setHhPrice(Double hhPrice) {
        this.hhPrice = hhPrice;
    }

    public Double getItemSpclPrice() {
        return itemSpclPrice;
    }

    public void setItemSpclPrice(Double itemSpclPrice) {
        this.itemSpclPrice = itemSpclPrice;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        FeItems feItems = (FeItems) o;
        if (feItems.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), feItems.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "FeItems{" +
            "id=" + getId() +
            ", storeId=" + getStoreId() +
            ", deptId='" + getDeptId() + "'" +
            ", itemName='" + getItemName() + "'" +
            ", itemNum=" + getItemNum() +
            ", cost=" + getCost() +
            ", itemId=" + getItemId() +
            ", itemPrice=" + getItemPrice() +
            ", itemhasMods='" + isItemhasMods() + "'" +
            ", itemImg='" + isItemImg() + "'" +
            ", itemSpcl='" + isItemSpcl() + "'" +
            ", itemOnHH='" + isItemOnHH() + "'" +
            ", hhTimeStart='" + getHhTimeStart() + "'" +
            ", hhTimeEnd='" + getHhTimeEnd() + "'" +
            ", hhPrice='" + getHhPrice() + "'" +
            ", imgUrl='" + getImgUrl() + "'" +
            "}";
    }
}
