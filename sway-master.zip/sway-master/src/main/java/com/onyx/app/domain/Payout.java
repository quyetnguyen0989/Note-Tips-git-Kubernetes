package com.onyx.app.domain;

import org.springframework.data.annotation.Id;
import com.couchbase.client.java.repository.annotation.Field;
import org.springframework.data.couchbase.core.mapping.Document;

import java.io.Serializable;
import java.time.ZonedDateTime;
import java.util.Objects;

/**
 * A Payout.
 */
@Document
public class Payout implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    private String id;

    @Field("payout_id")
    private Integer payoutId;

    @Field("store_id")
    private Integer storeId;

    @Field("cashier_id")
    private Integer cashierId;

    @Field("datetime")
    private ZonedDateTime datetime;

    @Field("vendor_number")
    private String vendorNumber;

    @Field("amount")
    private Double amount;

    @Field("station_id")
    private Integer stationId;

    @Field("description")
    private String description;

    @Field("payment_method")
    private String paymentMethod;

    @Field("type")
    private String type;

    @Field("override_id")
    private String overrideId;

    @Field("item_num")
    private String itemNum;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getPayoutId() {
        return payoutId;
    }

    public Payout payoutId(Integer payoutId) {
        this.payoutId = payoutId;
        return this;
    }

    public void setPayoutId(Integer payoutId) {
        this.payoutId = payoutId;
    }

    public Integer getStoreId() {
        return storeId;
    }

    public Payout storeId(Integer storeId) {
        this.storeId = storeId;
        return this;
    }

    public void setStoreId(Integer storeId) {
        this.storeId = storeId;
    }

    public Integer getCashierId() {
        return cashierId;
    }

    public Payout cashierId(Integer cashierId) {
        this.cashierId = cashierId;
        return this;
    }

    public void setCashierId(Integer cashierId) {
        this.cashierId = cashierId;
    }

    public ZonedDateTime getDatetime() {
        return datetime;
    }

    public Payout datetime(ZonedDateTime datetime) {
        this.datetime = datetime;
        return this;
    }

    public void setDatetime(ZonedDateTime datetime) {
        this.datetime = datetime;
    }

    public String getVendorNumber() {
        return vendorNumber;
    }

    public Payout vendorNumber(String vendorNumber) {
        this.vendorNumber = vendorNumber;
        return this;
    }

    public void setVendorNumber(String vendorNumber) {
        this.vendorNumber = vendorNumber;
    }

    public Double getAmount() {
        return amount;
    }

    public Payout amount(Double amount) {
        this.amount = amount;
        return this;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public Integer getStationId() {
        return stationId;
    }

    public Payout stationId(Integer stationId) {
        this.stationId = stationId;
        return this;
    }

    public void setStationId(Integer stationId) {
        this.stationId = stationId;
    }

    public String getDescription() {
        return description;
    }

    public Payout description(String description) {
        this.description = description;
        return this;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public Payout paymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
        return this;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public String getType() {
        return type;
    }

    public Payout type(String type) {
        this.type = type;
        return this;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getOverrideId() {
        return overrideId;
    }

    public Payout overrideId(String overrideId) {
        this.overrideId = overrideId;
        return this;
    }

    public void setOverrideId(String overrideId) {
        this.overrideId = overrideId;
    }

    public String getItemNum() {
        return itemNum;
    }

    public Payout itemNum(String itemNum) {
        this.itemNum = itemNum;
        return this;
    }

    public void setItemNum(String itemNum) {
        this.itemNum = itemNum;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Payout payout = (Payout) o;
        if (payout.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), payout.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "Payout{" +
            "id=" + getId() +
            ", payoutId=" + getPayoutId() +
            ", storeId=" + getStoreId() +
            ", cashierId=" + getCashierId() +
            ", datetime='" + getDatetime() + "'" +
            ", vendorNumber='" + getVendorNumber() + "'" +
            ", amount=" + getAmount() +
            ", stationId=" + getStationId() +
            ", description='" + getDescription() + "'" +
            ", paymentMethod='" + getPaymentMethod() + "'" +
            ", type='" + getType() + "'" +
            ", overrideId='" + getOverrideId() + "'" +
            ", itemNum='" + getItemNum() + "'" +
            "}";
    }
}
