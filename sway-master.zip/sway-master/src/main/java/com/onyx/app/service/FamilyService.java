package com.onyx.app.service;

import com.onyx.app.service.dto.FamilyDTO;

import java.util.List;
import java.util.Optional;

/**
 * Service Interface for managing Family.
 */
public interface FamilyService {

    /**
     * Save a family.
     *
     * @param familyDTO the entity to save
     * @return the persisted entity
     */
    FamilyDTO save(FamilyDTO familyDTO);

    /**
     * Get all the families.
     *
     * @return the list of entities
     */
    List<FamilyDTO> findAll();


    /**
     * Get the "id" family.
     *
     * @param id the id of the entity
     * @return the entity
     */
    Optional<FamilyDTO> findOne(String id);

    /**
     * Delete the "id" family.
     *
     * @param id the id of the entity
     */
    void delete(String id);
}
