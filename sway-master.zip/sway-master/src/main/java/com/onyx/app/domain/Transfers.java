package com.onyx.app.domain;

import org.springframework.data.annotation.Id;
import com.couchbase.client.java.repository.annotation.Field;
import org.springframework.data.couchbase.core.mapping.Document;
import org.springframework.data.couchbase.core.mapping.id.GeneratedValue;
import org.springframework.data.couchbase.core.mapping.id.IdPrefix;
import javax.validation.constraints.*;

import java.io.Serializable;
import java.time.ZonedDateTime;
import java.util.Objects;

import static com.onyx.app.config.Constants.ID_DELIMITER;
import static org.springframework.data.couchbase.core.mapping.id.GenerationStrategy.UNIQUE;

/**
 * A Transfers.
 */
@Document
public class Transfers implements Serializable {

    private static final long serialVersionUID = 1L;
    public static final String PREFIX = "transfers";

    @SuppressWarnings("unused")
    @IdPrefix
    private String prefix = PREFIX;

    @Id
    @GeneratedValue(strategy = UNIQUE, delimiter = ID_DELIMITER)
    private String id;

    @Field("store_id_org")
    private Integer storeIdOrg;

    @Field("store_id_des")
    private Integer storeIdDes;

    @Field("cashier_id")
    private Integer cashierId;

    @Field("transfer_id")
    private Integer transferId;

    @Field("created_time")
    private ZonedDateTime createdTime;

    @NotNull
    @Field("item_num")
    private Integer itemNum;

    @Field("item_qty_out")
    private Integer itemQtyOut;

    @Field("item_qty_in")
    private Integer itemQtyIn;

    @Field("item_name")
    private String itemName;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getStoreIdOrg() {
        return storeIdOrg;
    }

    public Transfers storeIdOrg(Integer storeIdOrg) {
        this.storeIdOrg = storeIdOrg;
        return this;
    }

    public void setStoreIdOrg(Integer storeIdOrg) {
        this.storeIdOrg = storeIdOrg;
    }

    public Integer getStoreIdDes() {
        return storeIdDes;
    }

    public Transfers storeIdDes(Integer storeIdDes) {
        this.storeIdDes = storeIdDes;
        return this;
    }

    public void setStoreIdDes(Integer storeIdDes) {
        this.storeIdDes = storeIdDes;
    }

    public Integer getCashierId() {
        return cashierId;
    }

    public Transfers cashierId(Integer cashierId) {
        this.cashierId = cashierId;
        return this;
    }

    public void setCashierId(Integer cashierId) {
        this.cashierId = cashierId;
    }

    public Integer getTransferId() {
        return transferId;
    }

    public Transfers transferId(Integer transferId) {
        this.transferId = transferId;
        return this;
    }

    public void setTransferId(Integer transferId) {
        this.transferId = transferId;
    }

    public ZonedDateTime getCreatedTime() {
        return createdTime;
    }

    public Transfers createdTime(ZonedDateTime createdTime) {
        this.createdTime = createdTime;
        return this;
    }

    public void setCreatedTime(ZonedDateTime createdTime) {
        this.createdTime = createdTime;
    }

    public Integer getItemNum() {
        return itemNum;
    }

    public Transfers itemNum(Integer itemNum) {
        this.itemNum = itemNum;
        return this;
    }

    public void setItemNum(Integer itemNum) {
        this.itemNum = itemNum;
    }

    public Integer getItemQtyOut() {
        return itemQtyOut;
    }

    public Transfers itemQtyOut(Integer itemQtyOut) {
        this.itemQtyOut = itemQtyOut;
        return this;
    }

    public void setItemQtyOut(Integer itemQtyOut) {
        this.itemQtyOut = itemQtyOut;
    }

    public Integer getItemQtyIn() {
        return itemQtyIn;
    }

    public Transfers itemQtyIn(Integer itemQtyIn) {
        this.itemQtyIn = itemQtyIn;
        return this;
    }

    public void setItemQtyIn(Integer itemQtyIn) {
        this.itemQtyIn = itemQtyIn;
    }

    public String getItemName() {
        return itemName;
    }

    public Transfers itemName(String itemName) {
        this.itemName = itemName;
        return this;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Transfers transfers = (Transfers) o;
        if (transfers.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), transfers.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "Transfers{" +
            "id=" + getId() +
            ", storeIdOrg=" + getStoreIdOrg() +
            ", storeIdDes=" + getStoreIdDes() +
            ", cashierId=" + getCashierId() +
            ", transferId=" + getTransferId() +
            ", createdTime='" + getCreatedTime() + "'" +
            ", itemNum=" + getItemNum() +
            ", itemQtyOut=" + getItemQtyOut() +
            ", itemQtyIn=" + getItemQtyIn() +
            ", itemName='" + getItemName() + "'" +
            "}";
    }
}
