package com.onyx.app.service.mapper;

import com.onyx.app.domain.*;
import com.onyx.app.service.dto.PaymentCCInfoDTO;

import org.mapstruct.*;

/**
 * Mapper for the entity PaymentCCInfo and its DTO PaymentCCInfoDTO.
 */
@Mapper(componentModel = "spring", uses = {})
public interface PaymentCCInfoMapper extends EntityMapper<PaymentCCInfoDTO, PaymentCCInfo> {


}
