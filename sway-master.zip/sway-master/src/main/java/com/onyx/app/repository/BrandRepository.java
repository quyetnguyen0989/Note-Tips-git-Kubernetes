package com.onyx.app.repository;

import org.springframework.stereotype.Repository;

import com.onyx.app.domain.Brand;

/**
 * Spring Data MongoDB repository for the Brand entity.
 */
@SuppressWarnings("unused")
@Repository
public interface BrandRepository extends N1qlCouchbaseRepository<Brand, String> {

}
