package com.onyx.app.service.mapper;

import com.onyx.app.domain.*;
import com.onyx.app.service.dto.CustomerTrxDTO;

import org.mapstruct.*;

/**
 * Mapper for the entity CustomerTrx and its DTO CustomerTrxDTO.
 */
@Mapper(componentModel = "spring", uses = {})
public interface CustomerTrxMapper extends EntityMapper<CustomerTrxDTO, CustomerTrx> {


}
