package com.onyx.app.repository;

import com.onyx.app.domain.SettingsHardware;
import org.springframework.stereotype.Repository;

/**
 * Spring Data Couchbase repository for the SettingsHardware entity.
 */
@SuppressWarnings("unused")
@Repository
public interface SettingsHardwareRepository extends N1qlCouchbaseRepository<SettingsHardware, String> {

}
