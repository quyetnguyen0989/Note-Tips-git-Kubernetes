package com.onyx.app.service.dto;
import java.time.Instant;
import java.time.LocalDate;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.Objects;

/**
 * A DTO for the InvoiceMobile entity.
 */
public class InvoiceMobileDTO implements Serializable {

    private String id;

    private Integer itemnum;

    @Size(max = 50)
    private String itemname;

    private Integer storeid;

    private String cusname;

    private Long custNum;

    private Integer invnum;

    private Instant invtime;

    @NotNull
    private Double itemprice;

    private LocalDate invdate;

    private Double discount;

    private Double totalPrice;

    private Double totalTax1;

    private Double grandTotal;

    private Double amtChange;

    private String paymentMethod;

    private Double taxedSales;

    private Double nonTaxedsales;

    private Double ccamount;

    private String status;

    private Integer modifierID;

    private String modifierName;

    private Long modifierNum;


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getItemnum() {
        return itemnum;
    }

    public void setItemnum(Integer itemnum) {
        this.itemnum = itemnum;
    }

    public String getItemname() {
        return itemname;
    }

    public void setItemname(String itemname) {
        this.itemname = itemname;
    }

    public Integer getStoreid() {
        return storeid;
    }

    public void setStoreid(Integer storeid) {
        this.storeid = storeid;
    }

    public String getCusname() {
        return cusname;
    }

    public void setCusname(String cusname) {
        this.cusname = cusname;
    }

    public Long getCustNum() {
        return custNum;
    }

    public void setCustNum(Long custNum) {
        this.custNum = custNum;
    }

    public Integer getInvnum() {
        return invnum;
    }

    public void setInvnum(Integer invnum) {
        this.invnum = invnum;
    }

    public Instant getInvtime() {
        return invtime;
    }

    public void setInvtime(Instant invtime) {
        this.invtime = invtime;
    }

    public Double getItemprice() {
        return itemprice;
    }

    public void setItemprice(Double itemprice) {
        this.itemprice = itemprice;
    }

    public LocalDate getInvdate() {
        return invdate;
    }

    public void setInvdate(LocalDate invdate) {
        this.invdate = invdate;
    }

    public Double getDiscount() {
        return discount;
    }

    public void setDiscount(Double discount) {
        this.discount = discount;
    }

    public Double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(Double totalPrice) {
        this.totalPrice = totalPrice;
    }

    public Double getTotalTax1() {
        return totalTax1;
    }

    public void setTotalTax1(Double totalTax1) {
        this.totalTax1 = totalTax1;
    }

    public Double getGrandTotal() {
        return grandTotal;
    }

    public void setGrandTotal(Double grandTotal) {
        this.grandTotal = grandTotal;
    }

    public Double getAmtChange() {
        return amtChange;
    }

    public void setAmtChange(Double amtChange) {
        this.amtChange = amtChange;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public Double getTaxedSales() {
        return taxedSales;
    }

    public void setTaxedSales(Double taxedSales) {
        this.taxedSales = taxedSales;
    }

    public Double getNonTaxedsales() {
        return nonTaxedsales;
    }

    public void setNonTaxedsales(Double nonTaxedsales) {
        this.nonTaxedsales = nonTaxedsales;
    }

    public Double getCcamount() {
        return ccamount;
    }

    public void setCcamount(Double ccamount) {
        this.ccamount = ccamount;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Integer getModifierID() {
        return modifierID;
    }

    public void setModifierID(Integer modifierID) {
        this.modifierID = modifierID;
    }

    public String getModifierName() {
        return modifierName;
    }

    public void setModifierName(String modifierName) {
        this.modifierName = modifierName;
    }

    public Long getModifierNum() {
        return modifierNum;
    }

    public void setModifierNum(Long modifierNum) {
        this.modifierNum = modifierNum;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        InvoiceMobileDTO invoiceMobileDTO = (InvoiceMobileDTO) o;
        if (invoiceMobileDTO.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), invoiceMobileDTO.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "InvoiceMobileDTO{" +
            "id=" + getId() +
            ", itemnum=" + getItemnum() +
            ", itemname='" + getItemname() + "'" +
            ", storeid=" + getStoreid() +
            ", cusname='" + getCusname() + "'" +
            ", custNum=" + getCustNum() +
            ", invnum=" + getInvnum() +
            ", invtime='" + getInvtime() + "'" +
            ", itemprice=" + getItemprice() +
            ", invdate='" + getInvdate() + "'" +
            ", discount=" + getDiscount() +
            ", totalPrice=" + getTotalPrice() +
            ", totalTax1=" + getTotalTax1() +
            ", grandTotal=" + getGrandTotal() +
            ", amtChange=" + getAmtChange() +
            ", paymentMethod='" + getPaymentMethod() + "'" +
            ", taxedSales=" + getTaxedSales() +
            ", nonTaxedsales=" + getNonTaxedsales() +
            ", ccamount=" + getCcamount() +
            ", status='" + getStatus() + "'" +
            ", modifierID=" + getModifierID() +
            ", modifierName='" + getModifierName() + "'" +
            ", modifierNum=" + getModifierNum() +
            "}";
    }
}
