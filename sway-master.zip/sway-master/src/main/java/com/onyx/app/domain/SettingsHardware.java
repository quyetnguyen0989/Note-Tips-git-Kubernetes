package com.onyx.app.domain;

import org.springframework.data.annotation.Id;
import com.couchbase.client.java.repository.annotation.Field;
import org.springframework.data.couchbase.core.mapping.Document;
import org.springframework.data.couchbase.core.mapping.id.GeneratedValue;
import org.springframework.data.couchbase.core.mapping.id.IdPrefix;
import javax.validation.constraints.*;

import java.io.Serializable;
import java.util.Objects;

import com.onyx.app.domain.enumeration.HardwarePoleType;

import com.onyx.app.domain.enumeration.HardwarePolePort;

import com.onyx.app.domain.enumeration.HardwareMsrPort;

import com.onyx.app.domain.enumeration.HardwarePrinterType;

import com.onyx.app.domain.enumeration.HardwarePrinterPort;

import com.onyx.app.domain.enumeration.HardwareScannerPort;

import com.onyx.app.domain.enumeration.HardwareMediaType;

import com.onyx.app.domain.enumeration.KitchenType;

import com.onyx.app.domain.enumeration.KitchenPort;

import com.onyx.app.domain.enumeration.HardwarePinpadType;

import static com.onyx.app.config.Constants.ID_DELIMITER;
import static org.springframework.data.couchbase.core.mapping.id.GenerationStrategy.UNIQUE;

/**
 * A SettingsHardware.
 */
@Document
public class SettingsHardware implements Serializable {

    private static final long serialVersionUID = 1L;
    public static final String PREFIX = "settingshardware";

    @SuppressWarnings("unused")
    @IdPrefix
    private String prefix = PREFIX;

    @Id
    @GeneratedValue(strategy = UNIQUE, delimiter = ID_DELIMITER)
    private String id;

    @NotNull
    @Field("store_id")
    private Integer storeId;

    @Field("pole_display")
    private Boolean poleDisplay;

    @Field("pole_display_type")
    private HardwarePoleType poleDisplayType;

    @Field("pole_display_port")
    private HardwarePolePort poleDisplayPort;

    @Field("msr")
    private Boolean msr;

    @Field("msr_port")
    private HardwareMsrPort msrPort;

    @Field("printer")
    private Boolean printer;

    @Field("printer_type")
    private HardwarePrinterType printerType;

    @Field("printer_port")
    private HardwarePrinterPort printerPort;

    @Field("scanner")
    private Boolean scanner;

    @Field("scanner_port")
    private HardwareScannerPort scannerPort;

    @Field("media_display")
    private Boolean mediaDisplay;

    @Field("media_display_type")
    private HardwareMediaType mediaDisplayType;

    @Field("kitchen_printer")
    private Boolean kitchenPrinter;

    @Field("kitchen_printer_type")
    private KitchenType kitchenPrinterType;

    @Field("kitchen_printer_port")
    private KitchenPort kitchenPrinterPort;

    @Field("pinpad")
    private Boolean pinpad;

    @Field("pinpad_type")
    private HardwarePinpadType pinpadType;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getStoreId() {
        return storeId;
    }

    public SettingsHardware storeId(Integer storeId) {
        this.storeId = storeId;
        return this;
    }

    public void setStoreId(Integer storeId) {
        this.storeId = storeId;
    }

    public Boolean isPoleDisplay() {
        return poleDisplay;
    }

    public SettingsHardware poleDisplay(Boolean poleDisplay) {
        this.poleDisplay = poleDisplay;
        return this;
    }

    public void setPoleDisplay(Boolean poleDisplay) {
        this.poleDisplay = poleDisplay;
    }

    public HardwarePoleType getPoleDisplayType() {
        return poleDisplayType;
    }

    public SettingsHardware poleDisplayType(HardwarePoleType poleDisplayType) {
        this.poleDisplayType = poleDisplayType;
        return this;
    }

    public void setPoleDisplayType(HardwarePoleType poleDisplayType) {
        this.poleDisplayType = poleDisplayType;
    }

    public HardwarePolePort getPoleDisplayPort() {
        return poleDisplayPort;
    }

    public SettingsHardware poleDisplayPort(HardwarePolePort poleDisplayPort) {
        this.poleDisplayPort = poleDisplayPort;
        return this;
    }

    public void setPoleDisplayPort(HardwarePolePort poleDisplayPort) {
        this.poleDisplayPort = poleDisplayPort;
    }

    public Boolean isMsr() {
        return msr;
    }

    public SettingsHardware msr(Boolean msr) {
        this.msr = msr;
        return this;
    }

    public void setMsr(Boolean msr) {
        this.msr = msr;
    }

    public HardwareMsrPort getMsrPort() {
        return msrPort;
    }

    public SettingsHardware msrPort(HardwareMsrPort msrPort) {
        this.msrPort = msrPort;
        return this;
    }

    public void setMsrPort(HardwareMsrPort msrPort) {
        this.msrPort = msrPort;
    }

    public Boolean isPrinter() {
        return printer;
    }

    public SettingsHardware printer(Boolean printer) {
        this.printer = printer;
        return this;
    }

    public void setPrinter(Boolean printer) {
        this.printer = printer;
    }

    public HardwarePrinterType getPrinterType() {
        return printerType;
    }

    public SettingsHardware printerType(HardwarePrinterType printerType) {
        this.printerType = printerType;
        return this;
    }

    public void setPrinterType(HardwarePrinterType printerType) {
        this.printerType = printerType;
    }

    public HardwarePrinterPort getPrinterPort() {
        return printerPort;
    }

    public SettingsHardware printerPort(HardwarePrinterPort printerPort) {
        this.printerPort = printerPort;
        return this;
    }

    public void setPrinterPort(HardwarePrinterPort printerPort) {
        this.printerPort = printerPort;
    }

    public Boolean isScanner() {
        return scanner;
    }

    public SettingsHardware scanner(Boolean scanner) {
        this.scanner = scanner;
        return this;
    }

    public void setScanner(Boolean scanner) {
        this.scanner = scanner;
    }

    public HardwareScannerPort getScannerPort() {
        return scannerPort;
    }

    public SettingsHardware scannerPort(HardwareScannerPort scannerPort) {
        this.scannerPort = scannerPort;
        return this;
    }

    public void setScannerPort(HardwareScannerPort scannerPort) {
        this.scannerPort = scannerPort;
    }

    public Boolean isMediaDisplay() {
        return mediaDisplay;
    }

    public SettingsHardware mediaDisplay(Boolean mediaDisplay) {
        this.mediaDisplay = mediaDisplay;
        return this;
    }

    public void setMediaDisplay(Boolean mediaDisplay) {
        this.mediaDisplay = mediaDisplay;
    }

    public HardwareMediaType getMediaDisplayType() {
        return mediaDisplayType;
    }

    public SettingsHardware mediaDisplayType(HardwareMediaType mediaDisplayType) {
        this.mediaDisplayType = mediaDisplayType;
        return this;
    }

    public void setMediaDisplayType(HardwareMediaType mediaDisplayType) {
        this.mediaDisplayType = mediaDisplayType;
    }

    public Boolean isKitchenPrinter() {
        return kitchenPrinter;
    }

    public SettingsHardware kitchenPrinter(Boolean kitchenPrinter) {
        this.kitchenPrinter = kitchenPrinter;
        return this;
    }

    public void setKitchenPrinter(Boolean kitchenPrinter) {
        this.kitchenPrinter = kitchenPrinter;
    }

    public KitchenType getKitchenPrinterType() {
        return kitchenPrinterType;
    }

    public SettingsHardware kitchenPrinterType(KitchenType kitchenPrinterType) {
        this.kitchenPrinterType = kitchenPrinterType;
        return this;
    }

    public void setKitchenPrinterType(KitchenType kitchenPrinterType) {
        this.kitchenPrinterType = kitchenPrinterType;
    }

    public KitchenPort getKitchenPrinterPort() {
        return kitchenPrinterPort;
    }

    public SettingsHardware kitchenPrinterPort(KitchenPort kitchenPrinterPort) {
        this.kitchenPrinterPort = kitchenPrinterPort;
        return this;
    }

    public void setKitchenPrinterPort(KitchenPort kitchenPrinterPort) {
        this.kitchenPrinterPort = kitchenPrinterPort;
    }

    public Boolean isPinpad() {
        return pinpad;
    }

    public SettingsHardware pinpad(Boolean pinpad) {
        this.pinpad = pinpad;
        return this;
    }

    public void setPinpad(Boolean pinpad) {
        this.pinpad = pinpad;
    }

    public HardwarePinpadType getPinpadType() {
        return pinpadType;
    }

    public SettingsHardware pinpadType(HardwarePinpadType pinpadType) {
        this.pinpadType = pinpadType;
        return this;
    }

    public void setPinpadType(HardwarePinpadType pinpadType) {
        this.pinpadType = pinpadType;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        SettingsHardware settingsHardware = (SettingsHardware) o;
        if (settingsHardware.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), settingsHardware.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "SettingsHardware{" +
            "id=" + getId() +
            ", storeId=" + getStoreId() +
            ", poleDisplay='" + isPoleDisplay() + "'" +
            ", poleDisplayType='" + getPoleDisplayType() + "'" +
            ", poleDisplayPort='" + getPoleDisplayPort() + "'" +
            ", msr='" + isMsr() + "'" +
            ", msrPort='" + getMsrPort() + "'" +
            ", printer='" + isPrinter() + "'" +
            ", printerType='" + getPrinterType() + "'" +
            ", printerPort='" + getPrinterPort() + "'" +
            ", scanner='" + isScanner() + "'" +
            ", scannerPort='" + getScannerPort() + "'" +
            ", mediaDisplay='" + isMediaDisplay() + "'" +
            ", mediaDisplayType='" + getMediaDisplayType() + "'" +
            ", kitchenPrinter='" + isKitchenPrinter() + "'" +
            ", kitchenPrinterType='" + getKitchenPrinterType() + "'" +
            ", kitchenPrinterPort='" + getKitchenPrinterPort() + "'" +
            ", pinpad='" + isPinpad() + "'" +
            ", pinpadType='" + getPinpadType() + "'" +
            "}";
    }
}
