package com.onyx.app.domain;

import org.springframework.data.annotation.Id;
import com.couchbase.client.java.repository.annotation.Field;
import org.springframework.data.couchbase.core.mapping.Document;

import java.io.Serializable;
import java.util.Objects;

/**
 * A SizeList.
 */
@Document
public class SizeList implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    private String id;

//    @Field("size_id")
//    private Integer sizeId;

    @Field("unit")
    private String unit;

    @Field("measurement")
    private String measurement;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

//    public Integer getSizeId() {
//        return sizeId;
//    }
//
//    public SizeList sizeId(Integer sizeId) {
//        this.sizeId = sizeId;
//        return this;
//    }

//    public void setSizeId(Integer sizeId) {
//        this.sizeId = sizeId;
//    }

    public String getUnit() {
        return unit;
    }

    public SizeList unit(String unit) {
        this.unit = unit;
        return this;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public String getMeasurement() {
        return measurement;
    }

    public SizeList measurement(String measurement) {
        this.measurement = measurement;
        return this;
    }

    public void setMeasurement(String measurement) {
        this.measurement = measurement;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        SizeList sizeList = (SizeList) o;
        if (sizeList.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), sizeList.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "SizeList{" +
            "id=" + getId() +
//            ", sizeId=" + getSizeId() +
            ", unit='" + getUnit() + "'" +
            ", measurement='" + getMeasurement() + "'" +
            "}";
    }
}
