package com.onyx.app.web.rest;

import com.codahale.metrics.annotation.Timed;
import com.onyx.app.service.CustomerTrxService;
import com.onyx.app.web.rest.errors.BadRequestAlertException;
import com.onyx.app.web.rest.util.HeaderUtil;
import com.onyx.app.service.dto.CustomerTrxDTO;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.net.URISyntaxException;

import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing CustomerTrx.
 */
@RestController
@RequestMapping("/api")
public class CustomerTrxResource {

    private final Logger log = LoggerFactory.getLogger(CustomerTrxResource.class);

    private static final String ENTITY_NAME = "customerTrx";

    private final CustomerTrxService customerTrxService;

    public CustomerTrxResource(CustomerTrxService customerTrxService) {
        this.customerTrxService = customerTrxService;
    }

    /**
     * POST  /customer-trxes : Create a new customerTrx.
     *
     * @param customerTrxDTO the customerTrxDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new customerTrxDTO, or with status 400 (Bad Request) if the customerTrx has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/customer-trxes")
    @Timed
    public ResponseEntity<CustomerTrxDTO> createCustomerTrx(@RequestBody CustomerTrxDTO customerTrxDTO) throws URISyntaxException {
        log.debug("REST request to save CustomerTrx : {}", customerTrxDTO);
        if (customerTrxDTO.getId() != null) {
            throw new BadRequestAlertException("A new customerTrx cannot already have an ID", ENTITY_NAME, "idexists");
        }
        CustomerTrxDTO result = customerTrxService.save(customerTrxDTO);
        return ResponseEntity.created(new URI("/api/customer-trxes/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /customer-trxes : Updates an existing customerTrx.
     *
     * @param customerTrxDTO the customerTrxDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated customerTrxDTO,
     * or with status 400 (Bad Request) if the customerTrxDTO is not valid,
     * or with status 500 (Internal Server Error) if the customerTrxDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/customer-trxes")
    @Timed
    public ResponseEntity<CustomerTrxDTO> updateCustomerTrx(@RequestBody CustomerTrxDTO customerTrxDTO) throws URISyntaxException {
        log.debug("REST request to update CustomerTrx : {}", customerTrxDTO);
        if (customerTrxDTO.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        CustomerTrxDTO result = customerTrxService.save(customerTrxDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, customerTrxDTO.getId().toString()))
            .body(result);
    }

    /**
     * GET  /customer-trxes : get all the customerTrxes.
     *
     * @return the ResponseEntity with status 200 (OK) and the list of customerTrxes in body
     */
    @GetMapping("/customer-trxes")
    @Timed
    public List<CustomerTrxDTO> getAllCustomerTrxes() {
        log.debug("REST request to get all CustomerTrxes");
        return customerTrxService.findAll();
    }

    /**
     * GET  /customer-trxes/:id : get the "id" customerTrx.
     *
     * @param id the id of the customerTrxDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the customerTrxDTO, or with status 404 (Not Found)
     */
    @GetMapping("/customer-trxes/{id}")
    @Timed
    public ResponseEntity<CustomerTrxDTO> getCustomerTrx(@PathVariable String id) {
        log.debug("REST request to get CustomerTrx : {}", id);
        Optional<CustomerTrxDTO> customerTrxDTO = customerTrxService.findOne(id);
        return ResponseUtil.wrapOrNotFound(customerTrxDTO);
    }

    /**
     * DELETE  /customer-trxes/:id : delete the "id" customerTrx.
     *
     * @param id the id of the customerTrxDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/customer-trxes/{id}")
    @Timed
    public ResponseEntity<Void> deleteCustomerTrx(@PathVariable String id) {
        log.debug("REST request to delete CustomerTrx : {}", id);
        customerTrxService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id)).build();
    }
}
