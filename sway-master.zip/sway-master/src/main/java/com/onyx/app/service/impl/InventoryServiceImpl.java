package com.onyx.app.service.impl;

import com.onyx.app.service.InventoryService;
import com.onyx.app.domain.Inventory;
import com.onyx.app.exception.ErrorMessage;
import com.onyx.app.repository.BrandRepository;
import com.onyx.app.repository.CategoryRepository;
import com.onyx.app.repository.DeptRepository;
import com.onyx.app.repository.FamilyRepository;
import com.onyx.app.repository.InventoryRepository;
import com.onyx.app.repository.ModifierRepository;
import com.onyx.app.repository.ModifiersGroupRepository;
import com.onyx.app.repository.SectionRepository;
import com.onyx.app.repository.StoreLocalRepository;
import com.onyx.app.repository.SubFamilyRepository;
import com.onyx.app.service.dto.InventoryDTO;
import com.onyx.app.service.mapper.InventoryMapper;
import com.onyx.app.web.rest.errors.BrandException;
import com.onyx.app.web.rest.errors.ErrorMessages;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
/**
 * Service Implementation for managing Inventory.
 */
@Service
public class InventoryServiceImpl implements InventoryService {

    private final Logger log = LoggerFactory.getLogger(InventoryServiceImpl.class);

    private final InventoryRepository inventoryRepository;
    
    private final BrandRepository brandRepository;
    
    private final FamilyRepository familyRepository;
    
    private final SubFamilyRepository subFamilyRepository;
    
    private final SectionRepository sectionRepository;
    
    private final StoreLocalRepository storeLocalRepository;
    
    private final DeptRepository deptRepository;
    
    private final CategoryRepository categoryRepository;
    
    private final ModifierRepository modifierRepository;
    
    private final ModifiersGroupRepository modifiersGroupRepository;

    private final InventoryMapper inventoryMapper;

    @Autowired
    public InventoryServiceImpl(InventoryRepository inventoryRepository, InventoryMapper inventoryMapper
    		,BrandRepository brandRepository,FamilyRepository familyRepository,
    		SubFamilyRepository subFamilyRepository,SectionRepository sectionRepository,
    		StoreLocalRepository storeLocalRepository,DeptRepository deptRepository,
    		CategoryRepository categoryRepository, ModifierRepository modifierRepository,
    		ModifiersGroupRepository modifiersGroupRepository) {
        this.inventoryRepository = inventoryRepository;
        this.inventoryMapper = inventoryMapper;
        this.brandRepository = brandRepository;
        this.familyRepository = familyRepository;
        this.subFamilyRepository = subFamilyRepository;
        this.sectionRepository = sectionRepository;
        this.storeLocalRepository = storeLocalRepository;
        this.deptRepository = deptRepository;
        this.categoryRepository = categoryRepository;
        this.modifierRepository = modifierRepository;
        this.modifiersGroupRepository = modifiersGroupRepository;
    }

    /**
     * Save a inventory.
     *
     * @param inventoryDTO the entity to save
     * @return the persisted entity
     * @throws Exception 
     */
    @Override
    public InventoryDTO save(InventoryDTO inventoryDTO) throws Exception {
        log.debug("Request to save Inventory : {}", inventoryDTO);
        if(inventoryDTO.getBrandId() != null) {
        	brandRepository.findById(inventoryDTO.getBrandId()).orElseThrow(() -> 
        	new BrandException(ErrorMessages.BRAND_NOT_FOUND.getErrorMessage()));	
        }
        if(inventoryDTO.getFamilyId() != null) {
        	familyRepository.findById(inventoryDTO.getFamilyId()).orElseThrow(() -> 
        	new BrandException(ErrorMessages.FAMILY_NOT_FOUND.getErrorMessage()));	
        }
        if(inventoryDTO.getSubfamilyId() != null) {
        	subFamilyRepository.findById(inventoryDTO.getSubfamilyId()).orElseThrow(() -> 
        	new BrandException(ErrorMessages.SUBFAMILY_NOT_FOUND.getErrorMessage()));	
        }
        if(inventoryDTO.getSectionId() != null) {
        	sectionRepository.findById(inventoryDTO.getSectionId()).orElseThrow(() -> 
        	new BrandException(ErrorMessages.SECTION_NOT_FOUND.getErrorMessage()));	
        }
        if(inventoryDTO.getStoreId() != null) {
        	storeLocalRepository.findById(inventoryDTO.getStoreId()).orElseThrow(() -> 
        	new BrandException(ErrorMessages.STORE_NOT_FOUND.getErrorMessage()));	
        }
        if(inventoryDTO.getDepartmentId() != null) {
        	deptRepository.findById(inventoryDTO.getDepartmentId()).orElseThrow(() -> 
        	new BrandException(ErrorMessages.DEPT_NOT_FOUND.getErrorMessage()));	
        }
        if(inventoryDTO.getCategoryId() != null) {
        	categoryRepository.findById(inventoryDTO.getCategoryId()).orElseThrow(() -> 
        	new BrandException(ErrorMessages.CATEGORY_NOT_FOUND.getErrorMessage()));	
        }
        if(inventoryDTO.getModifiersIds() != null) {
        	inventoryDTO.getModifiersIds().stream().forEach(id -> 
        		modifierRepository.findById(id).orElseThrow(() -> 
            		new BrandException(ErrorMessages.MODIFIER_NOT_FOUND.getErrorMessage()))
        	);	
        }
        if(inventoryDTO.getModifiersGroupsIds() != null) {
        	inventoryDTO.getModifiersGroupsIds().stream().forEach(id -> 
        		modifiersGroupRepository.findById(id).orElseThrow(() -> 
            		new BrandException(ErrorMessages.MODIFIER_GROUP_NOT_FOUND.getErrorMessage()))
        	);	
        }  
        ModelMapper mapper = new ModelMapper();
//        Inventory inventory = inventoryMapper.toEntity(inventoryDTO);
        Inventory inventory = mapper.map(inventoryDTO, Inventory.class);
        inventory = inventoryRepository.save(inventory);
        InventoryDTO returnValue = mapper.map(inventory, InventoryDTO.class);
//        return inventoryMapper.toDto(inventory);
        return returnValue;
    }

    /**
     * Get all the inventories.
     *
     * @return the list of entities
     */
    @Override
    public List<InventoryDTO> findAll() {
        log.debug("Request to get all Inventories");
        ModelMapper mapper = new ModelMapper();
//        return inventoryRepository.findAll().stream()
//                .map(inventoryMapper::toDto)
//                .collect(Collectors.toCollection(LinkedList::new));
        return inventoryRepository.findAll().stream()
            .map(inventory -> mapper.map(inventory, InventoryDTO.class))
            .collect(Collectors.toCollection(LinkedList::new));
    }


    /**
     * Get one inventory by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    public Optional<InventoryDTO> findOne(String id) {
        log.debug("Request to get Inventory : {}", id);
        return inventoryRepository.findById(id)
            .map(inventoryMapper::toDto);
    }

    /**
     * Delete the inventory by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(String id) {
        log.debug("Request to delete Inventory : {}", id);
        inventoryRepository.deleteById(id);
    }
}
