package com.onyx.app.domain;

import org.springframework.data.annotation.Id;
import com.couchbase.client.java.repository.annotation.Field;
import org.springframework.data.couchbase.core.mapping.Document;
import org.springframework.data.couchbase.core.mapping.id.GeneratedValue;
import org.springframework.data.couchbase.core.mapping.id.IdPrefix;

import java.io.Serializable;
import java.util.Objects;

import static com.onyx.app.config.Constants.ID_DELIMITER;
import static org.springframework.data.couchbase.core.mapping.id.GenerationStrategy.UNIQUE;

/**
 * A TouchDisplay.
 */
@Document
public class TouchDisplay implements Serializable {

    private static final long serialVersionUID = 1L;
    public static final String PREFIX = "touchdisplay";

    @SuppressWarnings("unused")
    @IdPrefix
    private String prefix = PREFIX;

    @Id
    @GeneratedValue(strategy = UNIQUE, delimiter = ID_DELIMITER)
    private String id;

    @Field("station_id")
    private Integer stationId;

    @Field("store_id")
    private Integer storeId;

    @Field("index")
    private Integer index;

    @Field("caption")
    private String caption;

    @Field("picture")
    private String picture;

    @Field("func")
    private String func;

    @Field("option_1")
    private String option1;

    @Field("back_color")
    private String backColor;

    @Field("fore_color")
    private String foreColor;

    @Field("visible")
    private Boolean visible;

    @Field("btn_type")
    private String btnType;

    @Field("ident")
    private String ident;

    @Field("schedule_index")
    private String scheduleIndex;

    @Field("row_id")
    private String rowId;

    @Field("column")
    private String column;

    @Field("group")
    private String group;

    @Field("sub_group")
    private String subGroup;

    @Field("dep_group")
    private String depGroup;

    @Field("family")
    private String family;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getStationId() {
        return stationId;
    }

    public TouchDisplay stationId(Integer stationId) {
        this.stationId = stationId;
        return this;
    }

    public void setStationId(Integer stationId) {
        this.stationId = stationId;
    }

    public Integer getStoreId() {
        return storeId;
    }

    public TouchDisplay storeId(Integer storeId) {
        this.storeId = storeId;
        return this;
    }

    public void setStoreId(Integer storeId) {
        this.storeId = storeId;
    }

    public Integer getIndex() {
        return index;
    }

    public TouchDisplay index(Integer index) {
        this.index = index;
        return this;
    }

    public void setIndex(Integer index) {
        this.index = index;
    }

    public String getCaption() {
        return caption;
    }

    public TouchDisplay caption(String caption) {
        this.caption = caption;
        return this;
    }

    public void setCaption(String caption) {
        this.caption = caption;
    }

    public String getPicture() {
        return picture;
    }

    public TouchDisplay picture(String picture) {
        this.picture = picture;
        return this;
    }

    public void setPicture(String picture) {
        this.picture = picture;
    }

    public String getFunc() {
        return func;
    }

    public TouchDisplay func(String func) {
        this.func = func;
        return this;
    }

    public void setFunc(String func) {
        this.func = func;
    }

    public String getOption1() {
        return option1;
    }

    public TouchDisplay option1(String option1) {
        this.option1 = option1;
        return this;
    }

    public void setOption1(String option1) {
        this.option1 = option1;
    }

    public String getBackColor() {
        return backColor;
    }

    public TouchDisplay backColor(String backColor) {
        this.backColor = backColor;
        return this;
    }

    public void setBackColor(String backColor) {
        this.backColor = backColor;
    }

    public String getForeColor() {
        return foreColor;
    }

    public TouchDisplay foreColor(String foreColor) {
        this.foreColor = foreColor;
        return this;
    }

    public void setForeColor(String foreColor) {
        this.foreColor = foreColor;
    }

    public Boolean isVisible() {
        return visible;
    }

    public TouchDisplay visible(Boolean visible) {
        this.visible = visible;
        return this;
    }

    public void setVisible(Boolean visible) {
        this.visible = visible;
    }

    public String getBtnType() {
        return btnType;
    }

    public TouchDisplay btnType(String btnType) {
        this.btnType = btnType;
        return this;
    }

    public void setBtnType(String btnType) {
        this.btnType = btnType;
    }

    public String getIdent() {
        return ident;
    }

    public TouchDisplay ident(String ident) {
        this.ident = ident;
        return this;
    }

    public void setIdent(String ident) {
        this.ident = ident;
    }

    public String getScheduleIndex() {
        return scheduleIndex;
    }

    public TouchDisplay scheduleIndex(String scheduleIndex) {
        this.scheduleIndex = scheduleIndex;
        return this;
    }

    public void setScheduleIndex(String scheduleIndex) {
        this.scheduleIndex = scheduleIndex;
    }

    public String getRowId() {
        return rowId;
    }

    public TouchDisplay rowId(String rowId) {
        this.rowId = rowId;
        return this;
    }

    public void setRowId(String rowId) {
        this.rowId = rowId;
    }

    public String getColumn() {
        return column;
    }

    public TouchDisplay column(String column) {
        this.column = column;
        return this;
    }

    public void setColumn(String column) {
        this.column = column;
    }

    public String getGroup() {
        return group;
    }

    public TouchDisplay group(String group) {
        this.group = group;
        return this;
    }

    public void setGroup(String group) {
        this.group = group;
    }

    public String getSubGroup() {
        return subGroup;
    }

    public TouchDisplay subGroup(String subGroup) {
        this.subGroup = subGroup;
        return this;
    }

    public void setSubGroup(String subGroup) {
        this.subGroup = subGroup;
    }

    public String getDepGroup() {
        return depGroup;
    }

    public TouchDisplay depGroup(String depGroup) {
        this.depGroup = depGroup;
        return this;
    }

    public void setDepGroup(String depGroup) {
        this.depGroup = depGroup;
    }

    public String getFamily() {
        return family;
    }

    public TouchDisplay family(String family) {
        this.family = family;
        return this;
    }

    public void setFamily(String family) {
        this.family = family;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        TouchDisplay touchDisplay = (TouchDisplay) o;
        if (touchDisplay.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), touchDisplay.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "TouchDisplay{" +
            "id=" + getId() +
            ", stationId=" + getStationId() +
            ", storeId=" + getStoreId() +
            ", index=" + getIndex() +
            ", caption='" + getCaption() + "'" +
            ", picture='" + getPicture() + "'" +
            ", func='" + getFunc() + "'" +
            ", option1='" + getOption1() + "'" +
            ", backColor='" + getBackColor() + "'" +
            ", foreColor='" + getForeColor() + "'" +
            ", visible='" + isVisible() + "'" +
            ", btnType='" + getBtnType() + "'" +
            ", ident='" + getIdent() + "'" +
            ", scheduleIndex='" + getScheduleIndex() + "'" +
            ", rowId='" + getRowId() + "'" +
            ", column='" + getColumn() + "'" +
            ", group='" + getGroup() + "'" +
            ", subGroup='" + getSubGroup() + "'" +
            ", depGroup='" + getDepGroup() + "'" +
            ", family='" + getFamily() + "'" +
            "}";
    }
}
