package com.onyx.app.service.mapper;

import com.onyx.app.domain.*;
import com.onyx.app.service.dto.InvoiceMobileDTO;

import org.mapstruct.*;

/**
 * Mapper for the entity InvoiceMobile and its DTO InvoiceMobileDTO.
 */
@Mapper(componentModel = "spring", uses = {})
public interface InvoiceMobileMapper extends EntityMapper<InvoiceMobileDTO, InvoiceMobile> {


}
