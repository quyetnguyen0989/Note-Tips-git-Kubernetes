package com.onyx.app.service.impl;

import com.onyx.app.service.TransfersService;
import com.onyx.app.domain.Transfers;
import com.onyx.app.repository.TransfersRepository;
import com.onyx.app.service.dto.TransfersDTO;
import com.onyx.app.service.mapper.TransfersMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.stereotype.Service;

import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
/**
 * Service Implementation for managing Transfers.
 */
@Service
public class TransfersServiceImpl implements TransfersService {

    private final Logger log = LoggerFactory.getLogger(TransfersServiceImpl.class);

    private final TransfersRepository transfersRepository;

    private final TransfersMapper transfersMapper;

    public TransfersServiceImpl(TransfersRepository transfersRepository, TransfersMapper transfersMapper) {
        this.transfersRepository = transfersRepository;
        this.transfersMapper = transfersMapper;
    }

    /**
     * Save a transfers.
     *
     * @param transfersDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public TransfersDTO save(TransfersDTO transfersDTO) {
        log.debug("Request to save Transfers : {}", transfersDTO);
        Transfers transfers = transfersMapper.toEntity(transfersDTO);
        transfers = transfersRepository.save(transfers);
        return transfersMapper.toDto(transfers);
    }

    /**
     * Get all the transfers.
     *
     * @return the list of entities
     */
    @Override
    public List<TransfersDTO> findAll() {
        log.debug("Request to get all Transfers");
        return transfersRepository.findAll().stream()
            .map(transfersMapper::toDto)
            .collect(Collectors.toCollection(LinkedList::new));
    }


    /**
     * Get one transfers by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    public Optional<TransfersDTO> findOne(String id) {
        log.debug("Request to get Transfers : {}", id);
        return transfersRepository.findById(id)
            .map(transfersMapper::toDto);
    }

    /**
     * Delete the transfers by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(String id) {
        log.debug("Request to delete Transfers : {}", id);
        transfersRepository.deleteById(id);
    }
}
