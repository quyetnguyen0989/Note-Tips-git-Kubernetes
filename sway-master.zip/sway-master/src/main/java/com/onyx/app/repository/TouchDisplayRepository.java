package com.onyx.app.repository;

import com.onyx.app.domain.TouchDisplay;
import org.springframework.stereotype.Repository;

/**
 * Spring Data Couchbase repository for the TouchDisplay entity.
 */
@SuppressWarnings("unused")
@Repository
public interface TouchDisplayRepository extends N1qlCouchbaseRepository<TouchDisplay, String> {

}
