package com.onyx.app.service.impl;

import com.onyx.app.service.SizeListService;
import com.onyx.app.domain.SizeList;
import com.onyx.app.repository.SizeListRepository;
import com.onyx.app.service.dto.SizeListDTO;
import com.onyx.app.service.mapper.SizeListMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.stereotype.Service;

import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
/**
 * Service Implementation for managing SizeList.
 */
@Service
public class SizeListServiceImpl implements SizeListService {

    private final Logger log = LoggerFactory.getLogger(SizeListServiceImpl.class);

    private final SizeListRepository sizeListRepository;

    private final SizeListMapper sizeListMapper;

    public SizeListServiceImpl(SizeListRepository sizeListRepository, SizeListMapper sizeListMapper) {
        this.sizeListRepository = sizeListRepository;
        this.sizeListMapper = sizeListMapper;
    }

    /**
     * Save a sizeList.
     *
     * @param sizeListDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public SizeListDTO save(SizeListDTO sizeListDTO) {
        log.debug("Request to save SizeList : {}", sizeListDTO);
        SizeList sizeList = sizeListMapper.toEntity(sizeListDTO);
        sizeList = sizeListRepository.save(sizeList);
        return sizeListMapper.toDto(sizeList);
    }

    /**
     * Get all the sizeLists.
     *
     * @return the list of entities
     */
    @Override
    public List<SizeListDTO> findAll() {
        log.debug("Request to get all SizeLists");
        return sizeListRepository.findAll().stream()
            .map(sizeListMapper::toDto)
            .collect(Collectors.toCollection(LinkedList::new));
    }


    /**
     * Get one sizeList by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    public Optional<SizeListDTO> findOne(String id) {
        log.debug("Request to get SizeList : {}", id);
        return sizeListRepository.findById(id)
            .map(sizeListMapper::toDto);
    }

    /**
     * Delete the sizeList by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(String id) {
        log.debug("Request to delete SizeList : {}", id);
        sizeListRepository.deleteById(id);
    }
}
