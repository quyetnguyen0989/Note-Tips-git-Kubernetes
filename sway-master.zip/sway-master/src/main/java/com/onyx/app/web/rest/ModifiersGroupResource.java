package com.onyx.app.web.rest;

import com.codahale.metrics.annotation.Timed;
import com.onyx.app.domain.ModifiersGroup;
import com.onyx.app.repository.ModifiersGroupRepository;
import com.onyx.app.response.ModifierGroupResponse;
import com.onyx.app.service.ModifiersGroupService;
import com.onyx.app.web.rest.errors.BadRequestAlertException;
import com.onyx.app.web.rest.util.HeaderUtil;
import com.onyx.app.service.dto.ModifiersGroupDTO;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing ModifiersGroup.
 */
@RestController
@RequestMapping("/api")
public class ModifiersGroupResource {

    private final Logger log = LoggerFactory.getLogger(ModifiersGroupResource.class);

    private static final String ENTITY_NAME = "modifiersGroup";

    private final ModifiersGroupService modifiersGroupService;
    
    @Autowired
    private ModifiersGroupRepository modifiersGroupRepository;

    public ModifiersGroupResource(ModifiersGroupService modifiersGroupService) {
        this.modifiersGroupService = modifiersGroupService;
    }

    /**
     * POST  /modifiers-groups : Create a new modifiersGroup.
     *
     * @param modifiersGroupDTO the modifiersGroupDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new modifiersGroupDTO, or with status 400 (Bad Request) if the modifiersGroup has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/modifiers-groups")
    @Timed
    public ResponseEntity<ModifiersGroup> createModifiersGroup(@RequestBody ModifiersGroup modifiersGroupDTO) throws URISyntaxException {
        log.debug("REST request to save ModifiersGroup : {}", modifiersGroupDTO.toString());
        if (modifiersGroupDTO.getId() != null) {
            throw new BadRequestAlertException("A new modifiersGroup cannot already have an ID", ENTITY_NAME, "idexists");
        }
        ModifiersGroup result = modifiersGroupRepository.save(modifiersGroupDTO);
        return ResponseEntity.created(new URI("/api/modifiers-groups/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /modifiers-groups : Updates an existing modifiersGroup.
     *
     * @param modifiersGroupDTO the modifiersGroupDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated modifiersGroupDTO,
     * or with status 400 (Bad Request) if the modifiersGroupDTO is not valid,
     * or with status 500 (Internal Server Error) if the modifiersGroupDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/modifiers-groups")
    @Timed
    public ResponseEntity<ModifiersGroupDTO> updateModifiersGroup(@RequestBody ModifiersGroupDTO modifiersGroupDTO) throws URISyntaxException {
        log.debug("REST request to update ModifiersGroup : {}", modifiersGroupDTO);
        if (modifiersGroupDTO.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        ModifiersGroupDTO result = modifiersGroupService.save(modifiersGroupDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, modifiersGroupDTO.getId().toString()))
            .body(result);
    }

    /**
     * GET  /modifiers-groups : get all the modifiersGroups.
     *
     * @return the ResponseEntity with status 200 (OK) and the list of modifiersGroups in body
     */
    @GetMapping("/modifiers-groups")
    @Timed
    public List<ModifierGroupResponse> getAllModifiersGroups() {
        log.debug("REST request to get all ModifiersGroups");
        List<ModifiersGroup> modifiersGroupDTOs = modifiersGroupRepository.findAll();
        List<ModifierGroupResponse> responses = new ArrayList<>();
  
        BeanUtils.copyProperties(modifiersGroupDTOs, responses);
        
        return responses;
    }

    /**
     * GET  /modifiers-groups/:id : get the "id" modifiersGroup.
     *
     * @param id the id of the modifiersGroupDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the modifiersGroupDTO, or with status 404 (Not Found)
     */
    @GetMapping("/modifiers-groups/{id}")
    @Timed
    public ResponseEntity<ModifiersGroup> getModifiersGroup(@PathVariable String id) {
        log.debug("REST request to get ModifiersGroup : {}", id);
        Optional<ModifiersGroup> modifiersGroupDTO = modifiersGroupRepository.findById(id);
        return ResponseUtil.wrapOrNotFound(modifiersGroupDTO);
    }

    /**
     * DELETE  /modifiers-groups/:id : delete the "id" modifiersGroup.
     *
     * @param id the id of the modifiersGroupDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/modifiers-groups/{id}")
    @Timed
    public ResponseEntity<Void> deleteModifiersGroup(@PathVariable String id) {
        log.debug("REST request to delete ModifiersGroup : {}", id);
        modifiersGroupService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id)).build();
    }
}
