package com.onyx.app.service.mapper;

import com.onyx.app.domain.*;
import com.onyx.app.service.dto.DeptDTO;

import org.mapstruct.*;

/**
 * Mapper for the entity Dept and its DTO DeptDTO.
 */
@Mapper(componentModel = "spring", uses = {})
public interface DeptMapper extends EntityMapper<DeptDTO, Dept> {


}
