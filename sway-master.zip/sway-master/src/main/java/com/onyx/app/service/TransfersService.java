package com.onyx.app.service;

import com.onyx.app.service.dto.TransfersDTO;

import java.util.List;
import java.util.Optional;

/**
 * Service Interface for managing Transfers.
 */
public interface TransfersService {

    /**
     * Save a transfers.
     *
     * @param transfersDTO the entity to save
     * @return the persisted entity
     */
    TransfersDTO save(TransfersDTO transfersDTO);

    /**
     * Get all the transfers.
     *
     * @return the list of entities
     */
    List<TransfersDTO> findAll();


    /**
     * Get the "id" transfers.
     *
     * @param id the id of the entity
     * @return the entity
     */
    Optional<TransfersDTO> findOne(String id);

    /**
     * Delete the "id" transfers.
     *
     * @param id the id of the entity
     */
    void delete(String id);
}
