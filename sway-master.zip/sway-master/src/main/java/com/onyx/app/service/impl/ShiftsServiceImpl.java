package com.onyx.app.service.impl;

import com.onyx.app.service.ShiftsService;
import com.onyx.app.domain.Shifts;
import com.onyx.app.repository.ShiftsRepository;
import com.onyx.app.service.dto.ShiftsDTO;
import com.onyx.app.service.mapper.ShiftsMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.stereotype.Service;

import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
/**
 * Service Implementation for managing Shifts.
 */
@Service
public class ShiftsServiceImpl implements ShiftsService {

    private final Logger log = LoggerFactory.getLogger(ShiftsServiceImpl.class);

    private final ShiftsRepository shiftsRepository;

    private final ShiftsMapper shiftsMapper;

    public ShiftsServiceImpl(ShiftsRepository shiftsRepository, ShiftsMapper shiftsMapper) {
        this.shiftsRepository = shiftsRepository;
        this.shiftsMapper = shiftsMapper;
    }

    /**
     * Save a shifts.
     *
     * @param shiftsDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public ShiftsDTO save(ShiftsDTO shiftsDTO) {
        log.debug("Request to save Shifts : {}", shiftsDTO);
        Shifts shifts = shiftsMapper.toEntity(shiftsDTO);
        shifts = shiftsRepository.save(shifts);
        return shiftsMapper.toDto(shifts);
    }

    /**
     * Get all the shifts.
     *
     * @return the list of entities
     */
    @Override
    public List<ShiftsDTO> findAll() {
        log.debug("Request to get all Shifts");
        return shiftsRepository.findAll().stream()
            .map(shiftsMapper::toDto)
            .collect(Collectors.toCollection(LinkedList::new));
    }


    /**
     * Get one shifts by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    public Optional<ShiftsDTO> findOne(String id) {
        log.debug("Request to get Shifts : {}", id);
        return shiftsRepository.findById(id)
            .map(shiftsMapper::toDto);
    }

    /**
     * Delete the shifts by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(String id) {
        log.debug("Request to delete Shifts : {}", id);
        shiftsRepository.deleteById(id);
    }
}
