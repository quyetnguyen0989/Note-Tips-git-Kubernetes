package com.onyx.app.service.impl;

import com.onyx.app.service.CustomerTrxService;
import com.onyx.app.domain.CustomerTrx;
import com.onyx.app.repository.CustomerTrxRepository;
import com.onyx.app.service.dto.CustomerTrxDTO;
import com.onyx.app.service.mapper.CustomerTrxMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.stereotype.Service;

import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
/**
 * Service Implementation for managing CustomerTrx.
 */
@Service
public class CustomerTrxServiceImpl implements CustomerTrxService {

    private final Logger log = LoggerFactory.getLogger(CustomerTrxServiceImpl.class);

    private final CustomerTrxRepository customerTrxRepository;

    private final CustomerTrxMapper customerTrxMapper;

    public CustomerTrxServiceImpl(CustomerTrxRepository customerTrxRepository, CustomerTrxMapper customerTrxMapper) {
        this.customerTrxRepository = customerTrxRepository;
        this.customerTrxMapper = customerTrxMapper;
    }

    /**
     * Save a customerTrx.
     *
     * @param customerTrxDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public CustomerTrxDTO save(CustomerTrxDTO customerTrxDTO) {
        log.debug("Request to save CustomerTrx : {}", customerTrxDTO);
        CustomerTrx customerTrx = customerTrxMapper.toEntity(customerTrxDTO);
        customerTrx = customerTrxRepository.save(customerTrx);
        return customerTrxMapper.toDto(customerTrx);
    }

    /**
     * Get all the customerTrxes.
     *
     * @return the list of entities
     */
    @Override
    public List<CustomerTrxDTO> findAll() {
        log.debug("Request to get all CustomerTrxes");
        return customerTrxRepository.findAll().stream()
            .map(customerTrxMapper::toDto)
            .collect(Collectors.toCollection(LinkedList::new));
    }


    /**
     * Get one customerTrx by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    public Optional<CustomerTrxDTO> findOne(String id) {
        log.debug("Request to get CustomerTrx : {}", id);
        return customerTrxRepository.findById(id)
            .map(customerTrxMapper::toDto);
    }

    /**
     * Delete the customerTrx by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(String id) {
        log.debug("Request to delete CustomerTrx : {}", id);
        customerTrxRepository.deleteById(id);
    }
}
