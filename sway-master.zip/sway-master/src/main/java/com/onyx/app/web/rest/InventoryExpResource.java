package com.onyx.app.web.rest;

import com.codahale.metrics.annotation.Timed;
import com.onyx.app.service.InventoryExpService;
import com.onyx.app.web.rest.errors.BadRequestAlertException;
import com.onyx.app.web.rest.util.HeaderUtil;
import com.onyx.app.service.dto.InventoryExpDTO;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;

import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing InventoryExp.
 */
@RestController
@RequestMapping("/api")
public class InventoryExpResource {

    private final Logger log = LoggerFactory.getLogger(InventoryExpResource.class);

    private static final String ENTITY_NAME = "inventoryExp";

    private final InventoryExpService inventoryExpService;

    public InventoryExpResource(InventoryExpService inventoryExpService) {
        this.inventoryExpService = inventoryExpService;
    }

    /**
     * POST  /inventory-exps : Create a new inventoryExp.
     *
     * @param inventoryExpDTO the inventoryExpDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new inventoryExpDTO, or with status 400 (Bad Request) if the inventoryExp has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/inventory-exps")
    @Timed
    public ResponseEntity<InventoryExpDTO> createInventoryExp(@Valid @RequestBody InventoryExpDTO inventoryExpDTO) throws URISyntaxException {
        log.debug("REST request to save InventoryExp : {}", inventoryExpDTO);
        if (inventoryExpDTO.getId() != null) {
            throw new BadRequestAlertException("A new inventoryExp cannot already have an ID", ENTITY_NAME, "idexists");
        }
        InventoryExpDTO result = inventoryExpService.save(inventoryExpDTO);
        return ResponseEntity.created(new URI("/api/inventory-exps/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /inventory-exps : Updates an existing inventoryExp.
     *
     * @param inventoryExpDTO the inventoryExpDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated inventoryExpDTO,
     * or with status 400 (Bad Request) if the inventoryExpDTO is not valid,
     * or with status 500 (Internal Server Error) if the inventoryExpDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/inventory-exps")
    @Timed
    public ResponseEntity<InventoryExpDTO> updateInventoryExp(@Valid @RequestBody InventoryExpDTO inventoryExpDTO) throws URISyntaxException {
        log.debug("REST request to update InventoryExp : {}", inventoryExpDTO);
        if (inventoryExpDTO.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        InventoryExpDTO result = inventoryExpService.save(inventoryExpDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, inventoryExpDTO.getId().toString()))
            .body(result);
    }

    /**
     * GET  /inventory-exps : get all the inventoryExps.
     *
     * @return the ResponseEntity with status 200 (OK) and the list of inventoryExps in body
     */
    @GetMapping("/inventory-exps")
    @Timed
    public List<InventoryExpDTO> getAllInventoryExps() {
        log.debug("REST request to get all InventoryExps");
        return inventoryExpService.findAll();
    }

    /**
     * GET  /inventory-exps/:id : get the "id" inventoryExp.
     *
     * @param id the id of the inventoryExpDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the inventoryExpDTO, or with status 404 (Not Found)
     */
    @GetMapping("/inventory-exps/{id}")
    @Timed
    public ResponseEntity<InventoryExpDTO> getInventoryExp(@PathVariable String id) {
        log.debug("REST request to get InventoryExp : {}", id);
        Optional<InventoryExpDTO> inventoryExpDTO = inventoryExpService.findOne(id);
        return ResponseUtil.wrapOrNotFound(inventoryExpDTO);
    }

    /**
     * DELETE  /inventory-exps/:id : delete the "id" inventoryExp.
     *
     * @param id the id of the inventoryExpDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/inventory-exps/{id}")
    @Timed
    public ResponseEntity<Void> deleteInventoryExp(@PathVariable String id) {
        log.debug("REST request to delete InventoryExp : {}", id);
        inventoryExpService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id)).build();
    }
}
