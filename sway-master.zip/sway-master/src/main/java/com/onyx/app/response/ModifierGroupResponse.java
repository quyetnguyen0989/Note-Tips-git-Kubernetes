package com.onyx.app.response;

import java.util.List;


public class ModifierGroupResponse {

	private String id;
	
	private Integer storeid;

	private Integer modifierGroupID;

	private String modifierGroupName;

	private List<ModifierResponse> modifiers;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Integer getStoreid() {
		return storeid;
	}

	public void setStoreid(Integer storeid) {
		this.storeid = storeid;
	}

	public Integer getModifierGroupID() {
		return modifierGroupID;
	}

	public void setModifierGroupID(Integer modifierGroupID) {
		this.modifierGroupID = modifierGroupID;
	}

	public String getModifierGroupName() {
		return modifierGroupName;
	}

	public void setModifierGroupName(String modifierGroupName) {
		this.modifierGroupName = modifierGroupName;
	}

	public List<ModifierResponse> getModifiers() {
		return modifiers;
	}

	public void setModifiers(List<ModifierResponse> modifiers) {
		this.modifiers = modifiers;
	}
	
	
}
