package com.onyx.app.domain;

import org.springframework.data.annotation.Id;
import com.couchbase.client.java.repository.annotation.Field;
import org.springframework.data.couchbase.core.mapping.Document;
import org.springframework.data.couchbase.core.mapping.id.GeneratedValue;
import org.springframework.data.couchbase.core.mapping.id.IdPrefix;

import java.io.Serializable;
import java.util.Objects;

import static com.onyx.app.config.Constants.ID_DELIMITER;
import static org.springframework.data.couchbase.core.mapping.id.GenerationStrategy.UNIQUE;

/**
 * A PaymentMethod.
 */
@Document
public class PaymentMethod implements Serializable {

    private static final long serialVersionUID = 1L;
    public static final String PREFIX = "paymentmethod";

    @SuppressWarnings("unused")
    @IdPrefix
    private String prefix = PREFIX;

    @Id
    @GeneratedValue(strategy = UNIQUE, delimiter = ID_DELIMITER)
    private String id;

    @Field("payment_type_id")
    private Integer paymentTypeID;

    @Field("storeid")
    private Integer storeid;

    @Field("description")
    private String description;

    @Field("tagid")
    private String tagid;

    @Field("num_receipts")
    private Integer numReceipts;

    @Field("signature")
    private Boolean signature;

    @Field("currencytag")
    private String currencytag;

    @Field("check_id")
    private Boolean checkID;

    @Field("active")
    private Boolean active;

    @Field("processes")
    private Boolean processes;

    @Field("tax_exempt")
    private Boolean taxExempt;

    @Field("customer_required")
    private Boolean customerRequired;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getPaymentTypeID() {
        return paymentTypeID;
    }

    public PaymentMethod paymentTypeID(Integer paymentTypeID) {
        this.paymentTypeID = paymentTypeID;
        return this;
    }

    public void setPaymentTypeID(Integer paymentTypeID) {
        this.paymentTypeID = paymentTypeID;
    }

    public Integer getStoreid() {
        return storeid;
    }

    public PaymentMethod storeid(Integer storeid) {
        this.storeid = storeid;
        return this;
    }

    public void setStoreid(Integer storeid) {
        this.storeid = storeid;
    }

    public String getDescription() {
        return description;
    }

    public PaymentMethod description(String description) {
        this.description = description;
        return this;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getTagid() {
        return tagid;
    }

    public PaymentMethod tagid(String tagid) {
        this.tagid = tagid;
        return this;
    }

    public void setTagid(String tagid) {
        this.tagid = tagid;
    }

    public Integer getNumReceipts() {
        return numReceipts;
    }

    public PaymentMethod numReceipts(Integer numReceipts) {
        this.numReceipts = numReceipts;
        return this;
    }

    public void setNumReceipts(Integer numReceipts) {
        this.numReceipts = numReceipts;
    }

    public Boolean isSignature() {
        return signature;
    }

    public PaymentMethod signature(Boolean signature) {
        this.signature = signature;
        return this;
    }

    public void setSignature(Boolean signature) {
        this.signature = signature;
    }

    public String getCurrencytag() {
        return currencytag;
    }

    public PaymentMethod currencytag(String currencytag) {
        this.currencytag = currencytag;
        return this;
    }

    public void setCurrencytag(String currencytag) {
        this.currencytag = currencytag;
    }

    public Boolean isCheckID() {
        return checkID;
    }

    public PaymentMethod checkID(Boolean checkID) {
        this.checkID = checkID;
        return this;
    }

    public void setCheckID(Boolean checkID) {
        this.checkID = checkID;
    }

    public Boolean isActive() {
        return active;
    }

    public PaymentMethod active(Boolean active) {
        this.active = active;
        return this;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    public Boolean isProcesses() {
        return processes;
    }

    public PaymentMethod processes(Boolean processes) {
        this.processes = processes;
        return this;
    }

    public void setProcesses(Boolean processes) {
        this.processes = processes;
    }

    public Boolean isTaxExempt() {
        return taxExempt;
    }

    public PaymentMethod taxExempt(Boolean taxExempt) {
        this.taxExempt = taxExempt;
        return this;
    }

    public void setTaxExempt(Boolean taxExempt) {
        this.taxExempt = taxExempt;
    }

    public Boolean isCustomerRequired() {
        return customerRequired;
    }

    public PaymentMethod customerRequired(Boolean customerRequired) {
        this.customerRequired = customerRequired;
        return this;
    }

    public void setCustomerRequired(Boolean customerRequired) {
        this.customerRequired = customerRequired;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        PaymentMethod paymentMethod = (PaymentMethod) o;
        if (paymentMethod.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), paymentMethod.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "PaymentMethod{" +
            "id=" + getId() +
            ", paymentTypeID=" + getPaymentTypeID() +
            ", storeid=" + getStoreid() +
            ", description='" + getDescription() + "'" +
            ", tagid='" + getTagid() + "'" +
            ", numReceipts=" + getNumReceipts() +
            ", signature='" + isSignature() + "'" +
            ", currencytag='" + getCurrencytag() + "'" +
            ", checkID='" + isCheckID() + "'" +
            ", active='" + isActive() + "'" +
            ", processes='" + isProcesses() + "'" +
            ", taxExempt='" + isTaxExempt() + "'" +
            ", customerRequired='" + isCustomerRequired() + "'" +
            "}";
    }
}
