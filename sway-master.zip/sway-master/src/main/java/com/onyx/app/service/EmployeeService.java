package com.onyx.app.service;

import java.util.List;

import com.onyx.app.domain.Employee;

public interface EmployeeService {

   public Employee save(Employee employee);

   public Employee getOne(String id);

public List<Employee> getEmployees(int page, int limit);

public void delete(String id);
}
