package com.onyx.app.service.dto;

import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.Objects;

/**
 * A DTO for the InventoryAttribute entity.
 */
public class InventoryAttributeDTO implements Serializable {

    private String id;

    @Size(max = 50)
    private String itemName;

    @Size(max = 25)
    private String itemNum;

    private Integer itemSize;

    @NotNull
    private Integer storeId;

    private Double itemAttPrice;

    private Integer itemAttNum;

    private Boolean active;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public String getItemNum() {
        return itemNum;
    }

    public void setItemNum(String itemNum) {
        this.itemNum = itemNum;
    }

    public Integer getItemSize() {
        return itemSize;
    }

    public void setItemSize(Integer itemSize) {
        this.itemSize = itemSize;
    }

    public Integer getStoreId() {
        return storeId;
    }

    public void setStoreId(Integer storeId) {
        this.storeId = storeId;
    }

    public Double getItemAttPrice() {
        return itemAttPrice;
    }

    public void setItemAttPrice(Double itemAttPrice) {
        this.itemAttPrice = itemAttPrice;
    }

    public Integer getItemAttNum() {
        return itemAttNum;
    }

    public void setItemAttNum(Integer itemAttNum) {
        this.itemAttNum = itemAttNum;
    }

    public Boolean isActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        InventoryAttributeDTO inventoryAttributeDTO = (InventoryAttributeDTO) o;
        if (inventoryAttributeDTO.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), inventoryAttributeDTO.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "InventoryAttributeDTO{" +
            "id=" + getId() +
            ", itemName='" + getItemName() + "'" +
            ", itemNum='" + getItemNum() + "'" +
            ", itemSize=" + getItemSize() +
            ", storeId=" + getStoreId() +
            ", itemAttPrice=" + getItemAttPrice() +
            ", itemAttNum=" + getItemAttNum() +
            ", active='" + isActive() + "'" +
            "}";
    }
}
