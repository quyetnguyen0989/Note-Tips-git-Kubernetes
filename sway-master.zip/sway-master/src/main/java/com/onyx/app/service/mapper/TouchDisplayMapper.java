package com.onyx.app.service.mapper;

import com.onyx.app.domain.*;
import com.onyx.app.service.dto.TouchDisplayDTO;

import org.mapstruct.*;

/**
 * Mapper for the entity TouchDisplay and its DTO TouchDisplayDTO.
 */
@Mapper(componentModel = "spring", uses = {})
public interface TouchDisplayMapper extends EntityMapper<TouchDisplayDTO, TouchDisplay> {


}
