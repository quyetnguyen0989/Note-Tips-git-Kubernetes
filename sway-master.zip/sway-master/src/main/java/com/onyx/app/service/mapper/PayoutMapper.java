package com.onyx.app.service.mapper;

import com.onyx.app.domain.*;
import com.onyx.app.service.dto.PayoutDTO;

import org.mapstruct.*;

/**
 * Mapper for the entity Payout and its DTO PayoutDTO.
 */
@Mapper(componentModel = "spring", uses = {})
public interface PayoutMapper extends EntityMapper<PayoutDTO, Payout> {


}
