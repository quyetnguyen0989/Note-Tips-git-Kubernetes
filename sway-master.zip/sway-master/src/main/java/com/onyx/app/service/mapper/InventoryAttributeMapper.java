package com.onyx.app.service.mapper;

import com.onyx.app.domain.*;
import com.onyx.app.service.dto.InventoryAttributeDTO;

import org.mapstruct.*;

/**
 * Mapper for the entity InventoryAttribute and its DTO InventoryAttributeDTO.
 */
@Mapper(componentModel = "spring", uses = {})
public interface InventoryAttributeMapper extends EntityMapper<InventoryAttributeDTO, InventoryAttribute> {


}
