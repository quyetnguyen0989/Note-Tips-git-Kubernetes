package com.onyx.app.service.dto;

import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.Objects;

/**
 * A DTO for the Family entity.
 */
public class FamilyDTO implements Serializable {

    private String id;

    private Integer familyId;

    private String familyName;

    @NotNull
    private Integer storeId;

    private Integer deptId;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getFamilyId() {
        return familyId;
    }

    public void setFamilyId(Integer familyId) {
        this.familyId = familyId;
    }

    public String getFamilyName() {
        return familyName;
    }

    public void setFamilyName(String familyName) {
        this.familyName = familyName;
    }

    public Integer getStoreId() {
        return storeId;
    }

    public void setStoreId(Integer storeId) {
        this.storeId = storeId;
    }

    public Integer getDeptId() {
        return deptId;
    }

    public void setDeptId(Integer deptId) {
        this.deptId = deptId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        FamilyDTO familyDTO = (FamilyDTO) o;
        if (familyDTO.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), familyDTO.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "FamilyDTO{" +
            "id=" + getId() +
            ", familyId=" + getFamilyId() +
            ", familyName='" + getFamilyName() + "'" +
            ", storeId=" + getStoreId() +
            ", deptId=" + getDeptId() +
            "}";
    }
}
