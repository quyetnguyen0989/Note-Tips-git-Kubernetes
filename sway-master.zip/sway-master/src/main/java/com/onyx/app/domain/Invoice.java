package com.onyx.app.domain;


import org.springframework.data.annotation.Id;
import com.couchbase.client.java.repository.annotation.Field;
import org.springframework.data.couchbase.core.mapping.Document;
import org.springframework.data.couchbase.core.mapping.id.GeneratedValue;
import org.springframework.data.couchbase.core.mapping.id.IdPrefix;
import javax.validation.constraints.*;

import java.io.Serializable;
import java.time.Instant;
import java.time.LocalDate;
import java.util.Objects;

import static com.onyx.app.config.Constants.ID_DELIMITER;
import static org.springframework.data.couchbase.core.mapping.id.GenerationStrategy.UNIQUE;

/**
 * A Invoice.
 */
@Document
public class Invoice implements Serializable {

    private static final long serialVersionUID = 1L;
    public static final String PREFIX = "invoice";

    @SuppressWarnings("unused")
    @IdPrefix
    private String prefix = PREFIX;
    
    @Id
    @GeneratedValue(strategy = UNIQUE, delimiter = ID_DELIMITER)
    private String id;

    @Field("itemnum")
    private Integer itemnum;

    @Size(max = 50)
    @Field("itemname")
    private String itemname;

    @Field("storeid")
    private Integer storeid;

    @Field("cust_num")
    private Long custNum;

    @Field("invnum")
    private Integer invnum;

    @Field("invtime")
    private Instant invtime;

    @NotNull
    @Field("itemprice")
    private Double itemprice;

    @Field("invdate")
    private LocalDate invdate;

    @Field("total_cost")
    private Double totalCost;

    @Field("discount")
    private Double discount;

    @Field("total_price")
    private Double totalPrice;

    @Field("total_tax_1")
    private Double totalTax1;

    @Field("total_tax_2")
    private Double totalTax2;

    @Field("total_tax_3")
    private Double totalTax3;

    @Field("grand_total")
    private Double grandTotal;

    @Field("amt_tendered")
    private Double amtTendered;

    @Field("amt_change")
    private Double amtChange;

    @Size(max = 200)
    @Field("notes")
    private String notes;

    @Field("status")
    private String status;

    @Field("cashierid")
    private Integer cashierid;

    @Field("cashiername")
    private String cashiername;

    @Field("stationid")
    private Integer stationid;

    @Field("payment_method")
    private String paymentMethod;

    @Field("taxed_1")
    private Double taxed1;

    @Field("taxed_sales")
    private Double taxedSales;

    @Field("non_taxedsales")
    private Double nonTaxedsales;

    @Field("taxexemptsales")
    private Double taxexemptsales;

    @Field("caamount")
    private Double caamount;

    @Field("ccamount")
    private Double ccamount;

    @Field("oaamount")
    private Double oaamount;

    @Field("dcamount")
    private Double dcamount;

    @Field("tipamount")
    private Double tipamount;

    @Field("fsamount")
    private Double fsamount;

    @Field("taxrateid")
    private String taxrateid;

    @Field("taxrate_1_percent")
    private Double taxrate1percent;

    @Field("layaway")
    private String layaway;

    @Field("amtdeposit")
    private Double amtdeposit;

    @Field("layawayamount")
    private Double layawayamount;

    @Field("onlineorderid")
    private Integer onlineorderid;

    @Field("order_source")
    private String orderSource;

    @Field("modifieddate")
    private String modifieddate;

    @Field("createdate")
    private String createdate;

    @Field("kioskid")
    private String kioskid;

    @Field("modifier_id")
    private Integer modifierID;

    @Field("modifier_name")
    private String modifierName;

    @Field("modifier_num")
    private Long modifierNum;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getItemnum() {
        return itemnum;
    }

    public Invoice itemnum(Integer itemnum) {
        this.itemnum = itemnum;
        return this;
    }

    public void setItemnum(Integer itemnum) {
        this.itemnum = itemnum;
    }

    public String getItemname() {
        return itemname;
    }

    public Invoice itemname(String itemname) {
        this.itemname = itemname;
        return this;
    }

    public void setItemname(String itemname) {
        this.itemname = itemname;
    }

    public Integer getStoreid() {
        return storeid;
    }

    public Invoice storeid(Integer storeid) {
        this.storeid = storeid;
        return this;
    }

    public void setStoreid(Integer storeid) {
        this.storeid = storeid;
    }

    public Long getCustNum() {
        return custNum;
    }

    public Invoice custNum(Long custNum) {
        this.custNum = custNum;
        return this;
    }

    public void setCustNum(Long custNum) {
        this.custNum = custNum;
    }

    public Integer getInvnum() {
        return invnum;
    }

    public Invoice invnum(Integer invnum) {
        this.invnum = invnum;
        return this;
    }

    public void setInvnum(Integer invnum) {
        this.invnum = invnum;
    }

    public Instant getInvtime() {
        return invtime;
    }

    public Invoice invtime(Instant invtime) {
        this.invtime = invtime;
        return this;
    }

    public void setInvtime(Instant invtime) {
        this.invtime = invtime;
    }

    public Double getItemprice() {
        return itemprice;
    }

    public Invoice itemprice(Double itemprice) {
        this.itemprice = itemprice;
        return this;
    }

    public void setItemprice(Double itemprice) {
        this.itemprice = itemprice;
    }

    public LocalDate getInvdate() {
        return invdate;
    }

    public Invoice invdate(LocalDate invdate) {
        this.invdate = invdate;
        return this;
    }

    public void setInvdate(LocalDate invdate) {
        this.invdate = invdate;
    }

    public Double getTotalCost() {
        return totalCost;
    }

    public Invoice totalCost(Double totalCost) {
        this.totalCost = totalCost;
        return this;
    }

    public void setTotalCost(Double totalCost) {
        this.totalCost = totalCost;
    }

    public Double getDiscount() {
        return discount;
    }

    public Invoice discount(Double discount) {
        this.discount = discount;
        return this;
    }

    public void setDiscount(Double discount) {
        this.discount = discount;
    }

    public Double getTotalPrice() {
        return totalPrice;
    }

    public Invoice totalPrice(Double totalPrice) {
        this.totalPrice = totalPrice;
        return this;
    }

    public void setTotalPrice(Double totalPrice) {
        this.totalPrice = totalPrice;
    }

    public Double getTotalTax1() {
        return totalTax1;
    }

    public Invoice totalTax1(Double totalTax1) {
        this.totalTax1 = totalTax1;
        return this;
    }

    public void setTotalTax1(Double totalTax1) {
        this.totalTax1 = totalTax1;
    }

    public Double getTotalTax2() {
        return totalTax2;
    }

    public Invoice totalTax2(Double totalTax2) {
        this.totalTax2 = totalTax2;
        return this;
    }

    public void setTotalTax2(Double totalTax2) {
        this.totalTax2 = totalTax2;
    }

    public Double getTotalTax3() {
        return totalTax3;
    }

    public Invoice totalTax3(Double totalTax3) {
        this.totalTax3 = totalTax3;
        return this;
    }

    public void setTotalTax3(Double totalTax3) {
        this.totalTax3 = totalTax3;
    }

    public Double getGrandTotal() {
        return grandTotal;
    }

    public Invoice grandTotal(Double grandTotal) {
        this.grandTotal = grandTotal;
        return this;
    }

    public void setGrandTotal(Double grandTotal) {
        this.grandTotal = grandTotal;
    }

    public Double getAmtTendered() {
        return amtTendered;
    }

    public Invoice amtTendered(Double amtTendered) {
        this.amtTendered = amtTendered;
        return this;
    }

    public void setAmtTendered(Double amtTendered) {
        this.amtTendered = amtTendered;
    }

    public Double getAmtChange() {
        return amtChange;
    }

    public Invoice amtChange(Double amtChange) {
        this.amtChange = amtChange;
        return this;
    }

    public void setAmtChange(Double amtChange) {
        this.amtChange = amtChange;
    }

    public String getNotes() {
        return notes;
    }

    public Invoice notes(String notes) {
        this.notes = notes;
        return this;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public String getStatus() {
        return status;
    }

    public Invoice status(String status) {
        this.status = status;
        return this;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Integer getCashierid() {
        return cashierid;
    }

    public Invoice cashierid(Integer cashierid) {
        this.cashierid = cashierid;
        return this;
    }

    public void setCashierid(Integer cashierid) {
        this.cashierid = cashierid;
    }

    public String getCashiername() {
        return cashiername;
    }

    public Invoice cashiername(String cashiername) {
        this.cashiername = cashiername;
        return this;
    }

    public void setCashiername(String cashiername) {
        this.cashiername = cashiername;
    }

    public Integer getStationid() {
        return stationid;
    }

    public Invoice stationid(Integer stationid) {
        this.stationid = stationid;
        return this;
    }

    public void setStationid(Integer stationid) {
        this.stationid = stationid;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public Invoice paymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
        return this;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public Double getTaxed1() {
        return taxed1;
    }

    public Invoice taxed1(Double taxed1) {
        this.taxed1 = taxed1;
        return this;
    }

    public void setTaxed1(Double taxed1) {
        this.taxed1 = taxed1;
    }

    public Double getTaxedSales() {
        return taxedSales;
    }

    public Invoice taxedSales(Double taxedSales) {
        this.taxedSales = taxedSales;
        return this;
    }

    public void setTaxedSales(Double taxedSales) {
        this.taxedSales = taxedSales;
    }

    public Double getNonTaxedsales() {
        return nonTaxedsales;
    }

    public Invoice nonTaxedsales(Double nonTaxedsales) {
        this.nonTaxedsales = nonTaxedsales;
        return this;
    }

    public void setNonTaxedsales(Double nonTaxedsales) {
        this.nonTaxedsales = nonTaxedsales;
    }

    public Double getTaxexemptsales() {
        return taxexemptsales;
    }

    public Invoice taxexemptsales(Double taxexemptsales) {
        this.taxexemptsales = taxexemptsales;
        return this;
    }

    public void setTaxexemptsales(Double taxexemptsales) {
        this.taxexemptsales = taxexemptsales;
    }

    public Double getCaamount() {
        return caamount;
    }

    public Invoice caamount(Double caamount) {
        this.caamount = caamount;
        return this;
    }

    public void setCaamount(Double caamount) {
        this.caamount = caamount;
    }

    public Double getCcamount() {
        return ccamount;
    }

    public Invoice ccamount(Double ccamount) {
        this.ccamount = ccamount;
        return this;
    }

    public void setCcamount(Double ccamount) {
        this.ccamount = ccamount;
    }

    public Double getOaamount() {
        return oaamount;
    }

    public Invoice oaamount(Double oaamount) {
        this.oaamount = oaamount;
        return this;
    }

    public void setOaamount(Double oaamount) {
        this.oaamount = oaamount;
    }

    public Double getDcamount() {
        return dcamount;
    }

    public Invoice dcamount(Double dcamount) {
        this.dcamount = dcamount;
        return this;
    }

    public void setDcamount(Double dcamount) {
        this.dcamount = dcamount;
    }

    public Double getTipamount() {
        return tipamount;
    }

    public Invoice tipamount(Double tipamount) {
        this.tipamount = tipamount;
        return this;
    }

    public void setTipamount(Double tipamount) {
        this.tipamount = tipamount;
    }

    public Double getFsamount() {
        return fsamount;
    }

    public Invoice fsamount(Double fsamount) {
        this.fsamount = fsamount;
        return this;
    }

    public void setFsamount(Double fsamount) {
        this.fsamount = fsamount;
    }

    public String getTaxrateid() {
        return taxrateid;
    }

    public Invoice taxrateid(String taxrateid) {
        this.taxrateid = taxrateid;
        return this;
    }

    public void setTaxrateid(String taxrateid) {
        this.taxrateid = taxrateid;
    }

    public Double getTaxrate1percent() {
        return taxrate1percent;
    }

    public Invoice taxrate1percent(Double taxrate1percent) {
        this.taxrate1percent = taxrate1percent;
        return this;
    }

    public void setTaxrate1percent(Double taxrate1percent) {
        this.taxrate1percent = taxrate1percent;
    }

    public String getLayaway() {
        return layaway;
    }

    public Invoice layaway(String layaway) {
        this.layaway = layaway;
        return this;
    }

    public void setLayaway(String layaway) {
        this.layaway = layaway;
    }

    public Double getAmtdeposit() {
        return amtdeposit;
    }

    public Invoice amtdeposit(Double amtdeposit) {
        this.amtdeposit = amtdeposit;
        return this;
    }

    public void setAmtdeposit(Double amtdeposit) {
        this.amtdeposit = amtdeposit;
    }

    public Double getLayawayamount() {
        return layawayamount;
    }

    public Invoice layawayamount(Double layawayamount) {
        this.layawayamount = layawayamount;
        return this;
    }

    public void setLayawayamount(Double layawayamount) {
        this.layawayamount = layawayamount;
    }

    public Integer getOnlineorderid() {
        return onlineorderid;
    }

    public Invoice onlineorderid(Integer onlineorderid) {
        this.onlineorderid = onlineorderid;
        return this;
    }

    public void setOnlineorderid(Integer onlineorderid) {
        this.onlineorderid = onlineorderid;
    }

    public String getOrderSource() {
        return orderSource;
    }

    public Invoice orderSource(String orderSource) {
        this.orderSource = orderSource;
        return this;
    }

    public void setOrderSource(String orderSource) {
        this.orderSource = orderSource;
    }

    public String getModifieddate() {
        return modifieddate;
    }

    public Invoice modifieddate(String modifieddate) {
        this.modifieddate = modifieddate;
        return this;
    }

    public void setModifieddate(String modifieddate) {
        this.modifieddate = modifieddate;
    }

    public String getCreatedate() {
        return createdate;
    }

    public Invoice createdate(String createdate) {
        this.createdate = createdate;
        return this;
    }

    public void setCreatedate(String createdate) {
        this.createdate = createdate;
    }

    public String getKioskid() {
        return kioskid;
    }

    public Invoice kioskid(String kioskid) {
        this.kioskid = kioskid;
        return this;
    }

    public void setKioskid(String kioskid) {
        this.kioskid = kioskid;
    }

    public Integer getModifierID() {
        return modifierID;
    }

    public Invoice modifierID(Integer modifierID) {
        this.modifierID = modifierID;
        return this;
    }

    public void setModifierID(Integer modifierID) {
        this.modifierID = modifierID;
    }

    public String getModifierName() {
        return modifierName;
    }

    public Invoice modifierName(String modifierName) {
        this.modifierName = modifierName;
        return this;
    }

    public void setModifierName(String modifierName) {
        this.modifierName = modifierName;
    }

    public Long getModifierNum() {
        return modifierNum;
    }

    public Invoice modifierNum(Long modifierNum) {
        this.modifierNum = modifierNum;
        return this;
    }

    public void setModifierNum(Long modifierNum) {
        this.modifierNum = modifierNum;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Invoice invoice = (Invoice) o;
        if (invoice.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), invoice.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "Invoice{" +
            "id=" + getId() +
            ", itemnum=" + getItemnum() +
            ", itemname='" + getItemname() + "'" +
            ", storeid=" + getStoreid() +
            ", custNum=" + getCustNum() +
            ", invnum=" + getInvnum() +
            ", invtime='" + getInvtime() + "'" +
            ", itemprice=" + getItemprice() +
            ", invdate='" + getInvdate() + "'" +
            ", totalCost=" + getTotalCost() +
            ", discount=" + getDiscount() +
            ", totalPrice=" + getTotalPrice() +
            ", totalTax1=" + getTotalTax1() +
            ", totalTax2=" + getTotalTax2() +
            ", totalTax3=" + getTotalTax3() +
            ", grandTotal=" + getGrandTotal() +
            ", amtTendered=" + getAmtTendered() +
            ", amtChange=" + getAmtChange() +
            ", notes='" + getNotes() + "'" +
            ", status='" + getStatus() + "'" +
            ", cashierid=" + getCashierid() +
            ", cashiername='" + getCashiername() + "'" +
            ", stationid=" + getStationid() +
            ", paymentMethod='" + getPaymentMethod() + "'" +
            ", taxed1=" + getTaxed1() +
            ", taxedSales=" + getTaxedSales() +
            ", nonTaxedsales=" + getNonTaxedsales() +
            ", taxexemptsales=" + getTaxexemptsales() +
            ", caamount=" + getCaamount() +
            ", ccamount=" + getCcamount() +
            ", oaamount=" + getOaamount() +
            ", dcamount=" + getDcamount() +
            ", tipamount=" + getTipamount() +
            ", fsamount=" + getFsamount() +
            ", taxrateid='" + getTaxrateid() + "'" +
            ", taxrate1percent=" + getTaxrate1percent() +
            ", layaway='" + getLayaway() + "'" +
            ", amtdeposit=" + getAmtdeposit() +
            ", layawayamount=" + getLayawayamount() +
            ", onlineorderid=" + getOnlineorderid() +
            ", orderSource='" + getOrderSource() + "'" +
            ", modifieddate='" + getModifieddate() + "'" +
            ", createdate='" + getCreatedate() + "'" +
            ", kioskid='" + getKioskid() + "'" +
            ", modifierID=" + getModifierID() +
            ", modifierName='" + getModifierName() + "'" +
            ", modifierNum=" + getModifierNum() +
            "}";
    }
}
