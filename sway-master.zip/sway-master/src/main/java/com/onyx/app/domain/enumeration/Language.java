package com.onyx.app.domain.enumeration;

/**
 * The Language enumeration.
 */
public enum Language {
    CHINESE, ENGLISH, SPANISH, ARABIC, THAI, PORTUGUESE
}
