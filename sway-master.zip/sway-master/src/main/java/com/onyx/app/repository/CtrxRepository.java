package com.onyx.app.repository;

import com.onyx.app.domain.Ctrx;
import org.springframework.stereotype.Repository;

/**
 * Spring Data Couchbase repository for the Ctrx entity.
 */
@SuppressWarnings("unused")
@Repository
public interface CtrxRepository extends N1qlCouchbaseRepository<Ctrx, String> {

}
