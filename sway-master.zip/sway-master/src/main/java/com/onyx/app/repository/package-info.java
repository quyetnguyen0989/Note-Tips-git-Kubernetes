/**
 * Spring Data JPA repositories.
 */
package com.onyx.app.repository;
