package com.onyx.app.service.mapper;

import com.onyx.app.domain.*;
import com.onyx.app.service.dto.ModifierDTO;

import org.mapstruct.*;

/**
 * Mapper for the entity Modifier and its DTO ModifierDTO.
 */
@Mapper(componentModel = "spring", uses = {})
public interface ModifierMapper extends EntityMapper<ModifierDTO, Modifier> {


}
