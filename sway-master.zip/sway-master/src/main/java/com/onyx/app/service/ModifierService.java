package com.onyx.app.service;

import com.onyx.app.service.dto.ModifierDTO;

import java.util.List;
import java.util.Optional;

/**
 * Service Interface for managing Modifier.
 */
public interface ModifierService {

    /**
     * Save a modifier.
     *
     * @param modifierDTO the entity to save
     * @return the persisted entity
     */
    ModifierDTO save(ModifierDTO modifierDTO);

    /**
     * Get all the modifiers.
     *
     * @return the list of entities
     */
    List<ModifierDTO> findAll();


    /**
     * Get the "id" modifier.
     *
     * @param id the id of the entity
     * @return the entity
     */
    Optional<ModifierDTO> findOne(String id);

    /**
     * Delete the "id" modifier.
     *
     * @param id the id of the entity
     */
    void delete(String id);
}
