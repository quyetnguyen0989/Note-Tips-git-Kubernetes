package com.onyx.app.service.impl;

import com.onyx.app.service.CTrxService;
import com.onyx.app.domain.CTrx;
import com.onyx.app.repository.CTrxRepository;
import com.onyx.app.service.dto.CTrxDTO;
import com.onyx.app.service.mapper.CTrxMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.stereotype.Service;

import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
/**
 * Service Implementation for managing CTrx.
 */
@Service
public class CTrxServiceImpl implements CTrxService {

    private final Logger log = LoggerFactory.getLogger(CTrxServiceImpl.class);

    private final CTrxRepository cTrxRepository;

    private final CTrxMapper cTrxMapper;

    public CTrxServiceImpl(CTrxRepository cTrxRepository, CTrxMapper cTrxMapper) {
        this.cTrxRepository = cTrxRepository;
        this.cTrxMapper = cTrxMapper;
    }

    /**
     * Save a cTrx.
     *
     * @param cTrxDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public CTrxDTO save(CTrxDTO cTrxDTO) {
        log.debug("Request to save CTrx : {}", cTrxDTO);
        CTrx cTrx = cTrxMapper.toEntity(cTrxDTO);
        cTrx = cTrxRepository.save(cTrx);
        return cTrxMapper.toDto(cTrx);
    }

    /**
     * Get all the cTrxes.
     *
     * @return the list of entities
     */
    @Override
    public List<CTrxDTO> findAll() {
        log.debug("Request to get all CTrxes");
        return cTrxRepository.findAll().stream()
            .map(cTrxMapper::toDto)
            .collect(Collectors.toCollection(LinkedList::new));
    }


    /**
     * Get one cTrx by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    public Optional<CTrxDTO> findOne(String id) {
        log.debug("Request to get CTrx : {}", id);
        return cTrxRepository.findById(id)
            .map(cTrxMapper::toDto);
    }

    /**
     * Delete the cTrx by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(String id) {
        log.debug("Request to delete CTrx : {}", id);
        cTrxRepository.deleteById(id);
    }
}
