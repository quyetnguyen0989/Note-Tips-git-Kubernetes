package com.onyx.app.service.impl;

import com.onyx.app.service.TouchDisplayService;
import com.onyx.app.domain.TouchDisplay;
import com.onyx.app.repository.TouchDisplayRepository;
import com.onyx.app.service.dto.TouchDisplayDTO;
import com.onyx.app.service.mapper.TouchDisplayMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.stereotype.Service;

import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
/**
 * Service Implementation for managing TouchDisplay.
 */
@Service
public class TouchDisplayServiceImpl implements TouchDisplayService {

    private final Logger log = LoggerFactory.getLogger(TouchDisplayServiceImpl.class);

    private final TouchDisplayRepository touchDisplayRepository;

    private final TouchDisplayMapper touchDisplayMapper;

    public TouchDisplayServiceImpl(TouchDisplayRepository touchDisplayRepository, TouchDisplayMapper touchDisplayMapper) {
        this.touchDisplayRepository = touchDisplayRepository;
        this.touchDisplayMapper = touchDisplayMapper;
    }

    /**
     * Save a touchDisplay.
     *
     * @param touchDisplayDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public TouchDisplayDTO save(TouchDisplayDTO touchDisplayDTO) {
        log.debug("Request to save TouchDisplay : {}", touchDisplayDTO);
        TouchDisplay touchDisplay = touchDisplayMapper.toEntity(touchDisplayDTO);
        touchDisplay = touchDisplayRepository.save(touchDisplay);
        return touchDisplayMapper.toDto(touchDisplay);
    }

    /**
     * Get all the touchDisplays.
     *
     * @return the list of entities
     */
    @Override
    public List<TouchDisplayDTO> findAll() {
        log.debug("Request to get all TouchDisplays");
        return touchDisplayRepository.findAll().stream()
            .map(touchDisplayMapper::toDto)
            .collect(Collectors.toCollection(LinkedList::new));
    }


    /**
     * Get one touchDisplay by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    public Optional<TouchDisplayDTO> findOne(String id) {
        log.debug("Request to get TouchDisplay : {}", id);
        return touchDisplayRepository.findById(id)
            .map(touchDisplayMapper::toDto);
    }

    /**
     * Delete the touchDisplay by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(String id) {
        log.debug("Request to delete TouchDisplay : {}", id);
        touchDisplayRepository.deleteById(id);
    }
}
