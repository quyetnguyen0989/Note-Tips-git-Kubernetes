package com.onyx.app.repository;

import com.onyx.app.domain.InventoryExp;
import org.springframework.stereotype.Repository;

/**
 * Spring Data Couchbase repository for the InventoryExp entity.
 */
@SuppressWarnings("unused")
@Repository
public interface InventoryExpRepository extends N1qlCouchbaseRepository<InventoryExp, String> {

}
