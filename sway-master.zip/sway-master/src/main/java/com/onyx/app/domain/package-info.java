/**
 * JPA domain objects.
 */
package com.onyx.app.domain;
