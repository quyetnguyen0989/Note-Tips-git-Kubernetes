/**
 * Spring Security configuration.
 */
package com.onyx.app.security;
