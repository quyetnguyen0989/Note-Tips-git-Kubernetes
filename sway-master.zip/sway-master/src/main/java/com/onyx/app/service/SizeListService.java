package com.onyx.app.service;

import com.onyx.app.service.dto.SizeListDTO;

import java.util.List;
import java.util.Optional;

/**
 * Service Interface for managing SizeList.
 */
public interface SizeListService {

    /**
     * Save a sizeList.
     *
     * @param sizeListDTO the entity to save
     * @return the persisted entity
     */
    SizeListDTO save(SizeListDTO sizeListDTO);

    /**
     * Get all the sizeLists.
     *
     * @return the list of entities
     */
    List<SizeListDTO> findAll();


    /**
     * Get the "id" sizeList.
     *
     * @param id the id of the entity
     * @return the entity
     */
    Optional<SizeListDTO> findOne(String id);

    /**
     * Delete the "id" sizeList.
     *
     * @param id the id of the entity
     */
    void delete(String id);
}
