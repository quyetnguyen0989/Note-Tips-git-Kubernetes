package com.onyx.app.service.dto;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;

public class Quick implements Serializable{


    private String id;

    @NotNull
    private Integer storeId;

    @Size(max = 50)
    private String itemName;

    private Integer itemNum;

    @NotNull
    private Integer itemId;

    @NotNull
    private Double itemPrice;


}
