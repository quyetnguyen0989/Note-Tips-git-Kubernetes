package com.onyx.app.domain;

import org.springframework.data.annotation.Id;
import com.couchbase.client.java.repository.annotation.Field;
import org.springframework.data.couchbase.core.mapping.Document;
import org.springframework.data.couchbase.core.mapping.id.GeneratedValue;
import org.springframework.data.couchbase.core.mapping.id.IdPrefix;
import javax.validation.constraints.*;

import java.io.Serializable;
import java.util.Objects;

import static com.onyx.app.config.Constants.ID_DELIMITER;
import static org.springframework.data.couchbase.core.mapping.id.GenerationStrategy.UNIQUE;

/**
 * A Family.
 */
@Document
public class Family implements Serializable {

    private static final long serialVersionUID = 1L;
    public static final String PREFIX = "family";

    @SuppressWarnings("unused")
    @IdPrefix
    private String prefix = PREFIX;

    @Id
    @GeneratedValue(strategy = UNIQUE, delimiter = ID_DELIMITER)
    private String id;

    @Field("family_id")
    private Integer familyId;

    @Field("family_name")
    private String familyName;

    @NotNull
    @Field("store_id")
    private Integer storeId;

    @Field("dept_id")
    private Integer deptId;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getFamilyId() {
        return familyId;
    }

    public Family familyId(Integer familyId) {
        this.familyId = familyId;
        return this;
    }

    public void setFamilyId(Integer familyId) {
        this.familyId = familyId;
    }

    public String getFamilyName() {
        return familyName;
    }

    public Family familyName(String familyName) {
        this.familyName = familyName;
        return this;
    }

    public void setFamilyName(String familyName) {
        this.familyName = familyName;
    }

    public Integer getStoreId() {
        return storeId;
    }

    public Family storeId(Integer storeId) {
        this.storeId = storeId;
        return this;
    }

    public void setStoreId(Integer storeId) {
        this.storeId = storeId;
    }

    public Integer getDeptId() {
        return deptId;
    }

    public Family deptId(Integer deptId) {
        this.deptId = deptId;
        return this;
    }

    public void setDeptId(Integer deptId) {
        this.deptId = deptId;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Family family = (Family) o;
        if (family.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), family.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "Family{" +
            "id=" + getId() +
            ", familyId=" + getFamilyId() +
            ", familyName='" + getFamilyName() + "'" +
            ", storeId=" + getStoreId() +
            ", deptId=" + getDeptId() +
            "}";
    }
}
