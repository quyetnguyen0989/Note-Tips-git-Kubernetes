package com.onyx.app.service.dto;

import java.io.Serializable;
import java.util.Objects;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.opencsv.bean.CsvBindByName;

/**
 * A DTO for the Inventory entity.
 */
public class InventoryDTO2 implements Serializable {

    private String id;
    @CsvBindByName(column = "Item_Num")
    private String itemNum;

    @CsvBindByName(column = "MU")
    private String sizeList;

    @CsvBindByName (column = "brand")
    @Size(max = 25)
    private String brand;

    @CsvBindByName (column = "Family")
    @Size(max = 25)
    private String family;

    @CsvBindByName  (column = "Sub Family")
    @Size(max = 25)
    private String subFamily;

    @Size(max = 25)
    private String section;

    @NotNull
    private Integer itemId;

    @CsvBindByName(column = "Item_Name")
    @Size(max = 50)
    private String itemName;

    @CsvBindByName(column = "store_id")
    @NotNull
    private Integer storeId;

    @CsvBindByName   (column = "Cost")
    private Double cost;

    @CsvBindByName(column = "Price")
    @NotNull
    private Double itemPrice;

    private Double minPrice;

    @CsvBindByName(column = "Stock")
    private Double stock;

    private Double reorder;

    @CsvBindByName(column = "Tax_1")
    private Boolean tax_1;

    @CsvBindByName(column = "Vendor_Part_Num")
    private Integer vendorPartNumber;

    private String vendorName;


    @CsvBindByName(column = "Dept_name")
    private String deptName;

    private Integer points;

    private Double bulkPricing;

    private Integer location;

    private Boolean autoWeigh;

    @CsvBindByName(column = "num_per_case")
    private Integer numPerCase;

    private Boolean foodStampable;

    private Boolean checkId;

    @Size(max = 10)
    private String itemType;

    private Boolean askPrice;

    private Boolean askQuantity;

    private Boolean disabled;

    @CsvBindByName(column = "size")
    private Double unitSize;

    private Boolean askDescription;

    private Boolean checkId2;

    private Boolean countItem;

    private Boolean active_online;

    private Boolean useBulk;

    private Boolean useTimeSale;

    private Boolean useDateSale;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getItemNum() {
        return itemNum;
    }

    public void setItemNum(String itemNum) {
        this.itemNum = itemNum;
    }

    public String getSizeList() {
        return sizeList;
    }

    public void setSizeList(String sizeList) {
        this.sizeList = sizeList;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getFamily() {
        return family;
    }

    public void setFamily(String family) {
        this.family = family;
    }

    public String getSubFamily() {
        return subFamily;
    }

    public void setSubFamily(String subFamily) {
        this.subFamily = subFamily;
    }

    public String getSection() {
        return section;
    }

    public void setSection(String section) {
        this.section = section;
    }

    public Integer getItemId() {
        return itemId;
    }

    public void setItemId(Integer itemId) {
        this.itemId = itemId;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public Integer getStoreId() {
        return storeId;
    }

    public void setStoreId(Integer storeId) {
        this.storeId = storeId;
    }

    public Double getCost() {
        return cost;
    }

    public void setCost(Double cost) {
        this.cost = cost;
    }

    public Double getItemPrice() {
        return itemPrice;
    }

    public void setItemPrice(Double itemPrice) {
        this.itemPrice = itemPrice;
    }

    public Double getMinPrice() {
        return minPrice;
    }

    public void setMinPrice(Double minPrice) {
        this.minPrice = minPrice;
    }

    public Double getStock() {
        return stock;
    }

    public void setStock(Double stock) {
        this.stock = stock;
    }

    public Double getReorder() {
        return reorder;
    }

    public void setReorder(Double reorder) {
        this.reorder = reorder;
    }

    public Boolean isTax_1() {
        return tax_1;
    }

    public void setTax_1(Boolean tax_1) {
        this.tax_1 = tax_1;
    }

    public Integer getVendorPartNumber() {
        return vendorPartNumber;
    }

    public void setVendorPartNumber(Integer vendorPartNumber) {
        this.vendorPartNumber = vendorPartNumber;
    }

    public String getVendorName() {
        return vendorName;
    }

    public void setVendorName(String vendorName) {
        this.vendorName = vendorName;
    }

    public String getDeptName() {
        return deptName;
    }

    public void setDeptName(String deptName) {
        this.deptName = deptName;
    }

    public Integer getPoints() {
        return points;
    }

    public void setPoints(Integer points) {
        this.points = points;
    }

    public Double getBulkPricing() {
        return bulkPricing;
    }

    public void setBulkPricing(Double bulkPricing) {
        this.bulkPricing = bulkPricing;
    }

    public Integer getLocation() {
        return location;
    }

    public void setLocation(Integer location) {
        this.location = location;
    }

    public Boolean isAutoWeigh() {
        return autoWeigh;
    }

    public void setAutoWeigh(Boolean autoWeigh) {
        this.autoWeigh = autoWeigh;
    }

    public Integer getNumPerCase() {
        return numPerCase;
    }

    public void setNumPerCase(Integer numPerCase) {
        this.numPerCase = numPerCase;
    }

    public Boolean isFoodStampable() {
        return foodStampable;
    }

    public void setFoodStampable(Boolean foodStampable) {
        this.foodStampable = foodStampable;
    }

    public Boolean isCheckId() {
        return checkId;
    }

    public void setCheckId(Boolean checkId) {
        this.checkId = checkId;
    }

    public String getItemType() {
        return itemType;
    }

    public void setItemType(String itemType) {
        this.itemType = itemType;
    }

    public Boolean isAskPrice() {
        return askPrice;
    }

    public void setAskPrice(Boolean askPrice) {
        this.askPrice = askPrice;
    }

    public Boolean isAskQuantity() {
        return askQuantity;
    }

    public void setAskQuantity(Boolean askQuantity) {
        this.askQuantity = askQuantity;
    }

    public Boolean isDisabled() {
        return disabled;
    }

    public void setDisabled(Boolean disabled) {
        this.disabled = disabled;
    }

    public Double getUnitSize() {
        return unitSize;
    }

    public void setUnitSize(Double unitSize) {
        this.unitSize = unitSize;
    }

    public Boolean isAskDescription() {
        return askDescription;
    }

    public void setAskDescription(Boolean askDescription) {
        this.askDescription = askDescription;
    }

    public Boolean isCheckId2() {
        return checkId2;
    }

    public void setCheckId2(Boolean checkId2) {
        this.checkId2 = checkId2;
    }

    public Boolean isCountItem() {
        return countItem;
    }

    public void setCountItem(Boolean countItem) {
        this.countItem = countItem;
    }

    public Boolean isActive_online() {
        return active_online;
    }

    public void setActive_online(Boolean active_online) {
        this.active_online = active_online;
    }

    public Boolean isUseBulk() {
        return useBulk;
    }

    public void setUseBulk(Boolean useBulk) {
        this.useBulk = useBulk;
    }

    public Boolean isUseTimeSale() {
        return useTimeSale;
    }

    public void setUseTimeSale(Boolean useTimeSale) {
        this.useTimeSale = useTimeSale;
    }

    public Boolean isUseDateSale() {
        return useDateSale;
    }

    public void setUseDateSale(Boolean useDateSale) {
        this.useDateSale = useDateSale;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        InventoryDTO2 inventoryDTO = (InventoryDTO2) o;
        if (inventoryDTO.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), inventoryDTO.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "InventoryQuick{" +
            "id=" + getId() +
            ", itemNum=" + getItemNum() +
            ", sizeList='" + getSizeList() + "'" +
            ", brand='" + getBrand() + "'" +
            ", family='" + getFamily() + "'" +
            ", subFamily='" + getSubFamily() + "'" +
            ", section='" + getSection() + "'" +
            ", itemId=" + getItemId() +
            ", itemName='" + getItemName() + "'" +
            ", storeId=" + getStoreId() +
            ", cost=" + getCost() +
            ", itemPrice=" + getItemPrice() +
            ", minPrice=" + getMinPrice() +
            ", stock=" + getStock() +
            ", reorder=" + getReorder() +
            ", tax_1='" + isTax_1() + "'" +
            ", vendorPartNumber=" + getVendorPartNumber() +
            ", vendorName='" + getVendorName() + "'" +
            ", deptName='" + getDeptName() + "'" +
            ", points=" + getPoints() +
            ", bulkPricing=" + getBulkPricing() +
            ", location=" + getLocation() +
            ", autoWeigh='" + isAutoWeigh() + "'" +
            ", numPerCase=" + getNumPerCase() +
            ", foodStampable='" + isFoodStampable() + "'" +
            ", checkId='" + isCheckId() + "'" +
            ", itemType='" + getItemType() + "'" +
            ", askPrice='" + isAskPrice() + "'" +
            ", askQuantity='" + isAskQuantity() + "'" +
            ", disabled='" + isDisabled() + "'" +
            ", unitSize=" + getUnitSize() +
            ", askDescription='" + isAskDescription() + "'" +
            ", checkId2='" + isCheckId2() + "'" +
            ", countItem='" + isCountItem() + "'" +
            ", active_online='" + isActive_online() + "'" +
            ", useBulk='" + isUseBulk() + "'" +
            ", useTimeSale='" + isUseTimeSale() + "'" +
            ", useDateSale='" + isUseDateSale() + "'" +
            "}";
    }
}
