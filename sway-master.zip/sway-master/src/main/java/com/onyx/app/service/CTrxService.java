package com.onyx.app.service;

import com.onyx.app.service.dto.CTrxDTO;

import java.util.List;
import java.util.Optional;

/**
 * Service Interface for managing CTrx.
 */
public interface CTrxService {

    /**
     * Save a cTrx.
     *
     * @param cTrxDTO the entity to save
     * @return the persisted entity
     */
    CTrxDTO save(CTrxDTO cTrxDTO);

    /**
     * Get all the cTrxes.
     *
     * @return the list of entities
     */
    List<CTrxDTO> findAll();


    /**
     * Get the "id" cTrx.
     *
     * @param id the id of the entity
     * @return the entity
     */
    Optional<CTrxDTO> findOne(String id);

    /**
     * Delete the "id" cTrx.
     *
     * @param id the id of the entity
     */
    void delete(String id);
}
