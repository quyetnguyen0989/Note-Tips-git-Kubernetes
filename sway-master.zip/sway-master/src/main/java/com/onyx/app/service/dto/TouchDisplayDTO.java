package com.onyx.app.service.dto;

import java.io.Serializable;
import java.util.Objects;

/**
 * A DTO for the TouchDisplay entity.
 */
public class TouchDisplayDTO implements Serializable {

    private String id;

    private Integer stationId;

    private Integer storeId;

    private Integer index;

    private String caption;

    private String picture;

    private String func;

    private String option1;

    private String backColor;

    private String foreColor;

    private Boolean visible;

    private String btnType;

    private String ident;

    private String scheduleIndex;

    private String rowId;

    private String column;

    private String group;

    private String subGroup;

    private String depGroup;

    private String family;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getStationId() {
        return stationId;
    }

    public void setStationId(Integer stationId) {
        this.stationId = stationId;
    }

    public Integer getStoreId() {
        return storeId;
    }

    public void setStoreId(Integer storeId) {
        this.storeId = storeId;
    }

    public Integer getIndex() {
        return index;
    }

    public void setIndex(Integer index) {
        this.index = index;
    }

    public String getCaption() {
        return caption;
    }

    public void setCaption(String caption) {
        this.caption = caption;
    }

    public String getPicture() {
        return picture;
    }

    public void setPicture(String picture) {
        this.picture = picture;
    }

    public String getFunc() {
        return func;
    }

    public void setFunc(String func) {
        this.func = func;
    }

    public String getOption1() {
        return option1;
    }

    public void setOption1(String option1) {
        this.option1 = option1;
    }

    public String getBackColor() {
        return backColor;
    }

    public void setBackColor(String backColor) {
        this.backColor = backColor;
    }

    public String getForeColor() {
        return foreColor;
    }

    public void setForeColor(String foreColor) {
        this.foreColor = foreColor;
    }

    public Boolean isVisible() {
        return visible;
    }

    public void setVisible(Boolean visible) {
        this.visible = visible;
    }

    public String getBtnType() {
        return btnType;
    }

    public void setBtnType(String btnType) {
        this.btnType = btnType;
    }

    public String getIdent() {
        return ident;
    }

    public void setIdent(String ident) {
        this.ident = ident;
    }

    public String getScheduleIndex() {
        return scheduleIndex;
    }

    public void setScheduleIndex(String scheduleIndex) {
        this.scheduleIndex = scheduleIndex;
    }

    public String getRowId() {
        return rowId;
    }

    public void setRowId(String rowId) {
        this.rowId = rowId;
    }

    public String getColumn() {
        return column;
    }

    public void setColumn(String column) {
        this.column = column;
    }

    public String getGroup() {
        return group;
    }

    public void setGroup(String group) {
        this.group = group;
    }

    public String getSubGroup() {
        return subGroup;
    }

    public void setSubGroup(String subGroup) {
        this.subGroup = subGroup;
    }

    public String getDepGroup() {
        return depGroup;
    }

    public void setDepGroup(String depGroup) {
        this.depGroup = depGroup;
    }

    public String getFamily() {
        return family;
    }

    public void setFamily(String family) {
        this.family = family;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        TouchDisplayDTO touchDisplayDTO = (TouchDisplayDTO) o;
        if (touchDisplayDTO.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), touchDisplayDTO.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "TouchDisplayDTO{" +
            "id=" + getId() +
            ", stationId=" + getStationId() +
            ", storeId=" + getStoreId() +
            ", index=" + getIndex() +
            ", caption='" + getCaption() + "'" +
            ", picture='" + getPicture() + "'" +
            ", func='" + getFunc() + "'" +
            ", option1='" + getOption1() + "'" +
            ", backColor='" + getBackColor() + "'" +
            ", foreColor='" + getForeColor() + "'" +
            ", visible='" + isVisible() + "'" +
            ", btnType='" + getBtnType() + "'" +
            ", ident='" + getIdent() + "'" +
            ", scheduleIndex='" + getScheduleIndex() + "'" +
            ", rowId='" + getRowId() + "'" +
            ", column='" + getColumn() + "'" +
            ", group='" + getGroup() + "'" +
            ", subGroup='" + getSubGroup() + "'" +
            ", depGroup='" + getDepGroup() + "'" +
            ", family='" + getFamily() + "'" +
            "}";
    }
}
