package com.onyx.app.service.dto;

import java.time.ZonedDateTime;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.Objects;

/**
 * A DTO for the InvoiceKiosk entity.
 */
public class InvoiceKioskDTO implements Serializable {

    private String id;

    private Integer itemNum;

    @Size(max = 50)
    private String itemName;

    private Integer storeId;

    private Integer kioskId;

    private Integer custNum;

    private Integer invNum;

    @NotNull
    private Double itemPrice;

    private ZonedDateTime invDateTime;

    private Double discount;

    private Double totalPrice;

    private Double totalTax1;

    private Double grandTotal;

    private Double amtChange;

    private String type;

    private Integer stationId;

    private String paymentMethod;

    private Double taxedSales;

    private Double nonTaxedSales;

    private Double ccAmount;

    private String status;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getItemNum() {
        return itemNum;
    }

    public void setItemNum(Integer itemNum) {
        this.itemNum = itemNum;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public Integer getStoreId() {
        return storeId;
    }

    public void setStoreId(Integer storeId) {
        this.storeId = storeId;
    }

    public Integer getKioskId() {
        return kioskId;
    }

    public void setKioskId(Integer kioskId) {
        this.kioskId = kioskId;
    }

    public Integer getCustNum() {
        return custNum;
    }

    public void setCustNum(Integer custNum) {
        this.custNum = custNum;
    }

    public Integer getInvNum() {
        return invNum;
    }

    public void setInvNum(Integer invNum) {
        this.invNum = invNum;
    }

    public Double getItemPrice() {
        return itemPrice;
    }

    public void setItemPrice(Double itemPrice) {
        this.itemPrice = itemPrice;
    }

    public ZonedDateTime getInvDateTime() {
        return invDateTime;
    }

    public void setInvDateTime(ZonedDateTime invDateTime) {
        this.invDateTime = invDateTime;
    }

    public Double getDiscount() {
        return discount;
    }

    public void setDiscount(Double discount) {
        this.discount = discount;
    }

    public Double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(Double totalPrice) {
        this.totalPrice = totalPrice;
    }

    public Double getTotalTax1() {
        return totalTax1;
    }

    public void setTotalTax1(Double totalTax1) {
        this.totalTax1 = totalTax1;
    }

    public Double getGrandTotal() {
        return grandTotal;
    }

    public void setGrandTotal(Double grandTotal) {
        this.grandTotal = grandTotal;
    }

    public Double getAmtChange() {
        return amtChange;
    }

    public void setAmtChange(Double amtChange) {
        this.amtChange = amtChange;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Integer getStationId() {
        return stationId;
    }

    public void setStationId(Integer stationId) {
        this.stationId = stationId;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public Double getTaxedSales() {
        return taxedSales;
    }

    public void setTaxedSales(Double taxedSales) {
        this.taxedSales = taxedSales;
    }

    public Double getNonTaxedSales() {
        return nonTaxedSales;
    }

    public void setNonTaxedSales(Double nonTaxedSales) {
        this.nonTaxedSales = nonTaxedSales;
    }

    public Double getCcAmount() {
        return ccAmount;
    }

    public void setCcAmount(Double ccAmount) {
        this.ccAmount = ccAmount;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        InvoiceKioskDTO invoiceKioskDTO = (InvoiceKioskDTO) o;
        if (invoiceKioskDTO.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), invoiceKioskDTO.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "InvoiceKioskDTO{" +
            "id=" + getId() +
            ", itemNum=" + getItemNum() +
            ", itemName='" + getItemName() + "'" +
            ", storeId=" + getStoreId() +
            ", kioskId=" + getKioskId() +
            ", custNum=" + getCustNum() +
            ", invNum=" + getInvNum() +
            ", itemPrice=" + getItemPrice() +
            ", invDateTime='" + getInvDateTime() + "'" +
            ", discount=" + getDiscount() +
            ", totalPrice=" + getTotalPrice() +
            ", totalTax1=" + getTotalTax1() +
            ", grandTotal=" + getGrandTotal() +
            ", amtChange=" + getAmtChange() +
            ", type='" + getType() + "'" +
            ", stationId=" + getStationId() +
            ", paymentMethod='" + getPaymentMethod() + "'" +
            ", taxedSales=" + getTaxedSales() +
            ", nonTaxedSales=" + getNonTaxedSales() +
            ", ccAmount=" + getCcAmount() +
            ", status='" + getStatus() + "'" +
            "}";
    }
}
