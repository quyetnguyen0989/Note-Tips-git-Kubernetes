package com.onyx.app.domain.enumeration;

public enum TypeSaleType {
    PERCENT, AMOUNT
}
