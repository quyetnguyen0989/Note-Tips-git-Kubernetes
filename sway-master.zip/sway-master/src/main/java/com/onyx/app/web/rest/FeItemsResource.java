package com.onyx.app.web.rest;
import com.onyx.app.domain.FeItems;
import com.onyx.app.repository.FeItemsRepository;
import com.onyx.app.service.FeItemsService;
import com.onyx.app.web.rest.errors.BadRequestAlertException;
import com.onyx.app.web.rest.util.HeaderUtil;
import com.onyx.app.service.dto.FeItemsDTO;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.net.URISyntaxException;

import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing FeItems.
 */
@RestController
@RequestMapping("/api")
public class FeItemsResource {

    private final Logger log = LoggerFactory.getLogger(FeItemsResource.class);

    private static final String ENTITY_NAME = "feItems";

    private final FeItemsService feItemsService;

    @Autowired
    private FeItemsRepository feItemsRepository;

    public FeItemsResource(FeItemsService feItemsService) {
        this.feItemsService = feItemsService;
    }

    /**
     * POST  /fe-items : Create a new feItems.
     *
     * @param feItemsDTO the feItemsDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new feItemsDTO, or with status 400 (Bad Request) if the feItems has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/fe-items")
    public ResponseEntity<FeItemsDTO> createFeItems(@RequestBody FeItemsDTO feItemsDTO) throws URISyntaxException {
        log.debug("REST request to save FeItems : {}", feItemsDTO);
        if (feItemsDTO.getId() != null) {
            throw new BadRequestAlertException("A new feItems cannot already have an ID", ENTITY_NAME, "idexists");
        }
        FeItemsDTO result = feItemsService.save(feItemsDTO);
        return ResponseEntity.created(new URI("/api/fe-items/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /fe-items : Updates an existing feItems.
     *
     * @param feItemsDTO the feItemsDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated feItemsDTO,
     * or with status 400 (Bad Request) if the feItemsDTO is not valid,
     * or with status 500 (Internal Server Error) if the feItemsDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/fe-items")
    public ResponseEntity<FeItemsDTO> updateFeItems(@RequestBody FeItemsDTO feItemsDTO) throws URISyntaxException {
        log.debug("REST request to update FeItems : {}", feItemsDTO);
        if (feItemsDTO.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        FeItemsDTO result = feItemsService.save(feItemsDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, feItemsDTO.getId().toString()))
            .body(result);
    }

    /**
     * GET  /fe-items : get all the feItems.
     *
     * @return the ResponseEntity with status 200 (OK) and the list of feItems in body
     */
    @GetMapping("/fe-items")
    public List<FeItemsDTO> getAllFeItems() {
        log.debug("REST request to get all FeItems");
        return feItemsService.findAll();
    }

    /**
     * GET /fe-items/:storeId get all the feItems of an store
     *
     * @return the ResponseEntity with status 200 (OK) and the list of feItems in body
     */
    @GetMapping("/fe-items-store/{storeId}")
    public ResponseEntity<List<FeItems>> getAllFeItemsOfStore(@PathVariable Integer storeId){
        log.debug("REST request to get all FeItems");
        List<FeItems> feItems = feItemsRepository.findAllByStoreId(storeId);
        return new ResponseEntity<>(feItems, HttpStatus.OK);
    }

    /**
     * GET  /fe-items/:id : get the "id" feItems.
     *
     * @param id the id of the feItemsDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the feItemsDTO, or with status 404 (Not Found)
     */
    @GetMapping("/fe-items/{id}")
    public ResponseEntity<FeItemsDTO> getFeItems(@PathVariable String id) {
        log.debug("REST request to get FeItems : {}", id);
        Optional<FeItemsDTO> feItemsDTO = feItemsService.findOne(id);
        return ResponseUtil.wrapOrNotFound(feItemsDTO);
    }

    /**
     * DELETE  /fe-items/:id : delete the "id" feItems.
     *
     * @param id the id of the feItemsDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/fe-items/{id}")
    public ResponseEntity<Void> deleteFeItems(@PathVariable String id) {
        log.debug("REST request to delete FeItems : {}", id);
        feItemsService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id)).build();
    }
}
