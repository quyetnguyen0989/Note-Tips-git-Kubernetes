package com.onyx.app.repository;

import org.springframework.stereotype.Repository;

import com.onyx.app.domain.Shifts;

/**
 * Spring Data MongoDB repository for the Shifts entity.
 */
@SuppressWarnings("unused")
@Repository
public interface ShiftsRepository extends N1qlCouchbaseRepository<Shifts, String> {

}
