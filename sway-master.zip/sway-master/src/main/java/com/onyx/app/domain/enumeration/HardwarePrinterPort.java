package com.onyx.app.domain.enumeration;

/**
 * The HardwarePrinterPort enumeration.
 */
public enum HardwarePrinterPort {
    USB, COM
}
