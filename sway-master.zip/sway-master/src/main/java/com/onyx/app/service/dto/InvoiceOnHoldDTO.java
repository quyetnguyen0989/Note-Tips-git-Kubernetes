package com.onyx.app.service.dto;

import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.Objects;

/**
 * A DTO for the InvoiceOnHold entity.
 */
public class InvoiceOnHoldDTO implements Serializable {

    private String id;

    @Size(max = 25)
    private String itemNum;

    private Integer invNum;

    @NotNull
    @Size(max = 10)
    private String itemPrice;

    private Double invoiceOnHoldId;

    private String invTime;

    private String onHoldName;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getItemNum() {
        return itemNum;
    }

    public void setItemNum(String itemNum) {
        this.itemNum = itemNum;
    }

    public Integer getInvNum() {
        return invNum;
    }

    public void setInvNum(Integer invNum) {
        this.invNum = invNum;
    }

    public String getItemPrice() {
        return itemPrice;
    }

    public void setItemPrice(String itemPrice) {
        this.itemPrice = itemPrice;
    }

    public Double getInvoiceOnHoldId() {
        return invoiceOnHoldId;
    }

    public void setInvoiceOnHoldId(Double invoiceOnHoldId) {
        this.invoiceOnHoldId = invoiceOnHoldId;
    }

    public String getInvTime() {
        return invTime;
    }

    public void setInvTime(String invTime) {
        this.invTime = invTime;
    }

    public String getOnHoldName() {
        return onHoldName;
    }

    public void setOnHoldName(String onHoldName) {
        this.onHoldName = onHoldName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        InvoiceOnHoldDTO invoiceOnHoldDTO = (InvoiceOnHoldDTO) o;
        if (invoiceOnHoldDTO.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), invoiceOnHoldDTO.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "InvoiceOnHoldDTO{" +
            "id=" + getId() +
            ", itemNum='" + getItemNum() + "'" +
            ", invNum=" + getInvNum() +
            ", itemPrice='" + getItemPrice() + "'" +
            ", invoiceOnHoldId=" + getInvoiceOnHoldId() +
            ", invTime='" + getInvTime() + "'" +
            ", onHoldName='" + getOnHoldName() + "'" +
            "}";
    }
}
