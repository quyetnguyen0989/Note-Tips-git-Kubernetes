package com.onyx.app.service.mapper;

import com.onyx.app.domain.*;
import com.onyx.app.service.dto.ModifiersGroupDTO;

import org.mapstruct.*;

/**
 * Mapper for the entity ModifiersGroup and its DTO ModifiersGroupDTO.
 */
@Mapper(componentModel = "spring", uses = {})
public interface ModifiersGroupMapper extends EntityMapper<ModifiersGroupDTO, ModifiersGroup> {


}
