package com.onyx.app.domain.enumeration;

/**
 * The HardwareMsrPort enumeration.
 */
public enum HardwareMsrPort {
    USB, COM
}
