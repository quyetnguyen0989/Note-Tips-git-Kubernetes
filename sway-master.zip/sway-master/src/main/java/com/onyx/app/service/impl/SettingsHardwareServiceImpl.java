package com.onyx.app.service.impl;

import com.onyx.app.service.SettingsHardwareService;
import com.onyx.app.domain.SettingsHardware;
import com.onyx.app.repository.SettingsHardwareRepository;
import com.onyx.app.service.dto.SettingsHardwareDTO;
import com.onyx.app.service.mapper.SettingsHardwareMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.stereotype.Service;

import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
/**
 * Service Implementation for managing SettingsHardware.
 */
@Service
public class SettingsHardwareServiceImpl implements SettingsHardwareService {

    private final Logger log = LoggerFactory.getLogger(SettingsHardwareServiceImpl.class);

    private final SettingsHardwareRepository settingsHardwareRepository;

    private final SettingsHardwareMapper settingsHardwareMapper;

    public SettingsHardwareServiceImpl(SettingsHardwareRepository settingsHardwareRepository, SettingsHardwareMapper settingsHardwareMapper) {
        this.settingsHardwareRepository = settingsHardwareRepository;
        this.settingsHardwareMapper = settingsHardwareMapper;
    }

    /**
     * Save a settingsHardware.
     *
     * @param settingsHardwareDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public SettingsHardwareDTO save(SettingsHardwareDTO settingsHardwareDTO) {
        log.debug("Request to save SettingsHardware : {}", settingsHardwareDTO);
        SettingsHardware settingsHardware = settingsHardwareMapper.toEntity(settingsHardwareDTO);
        settingsHardware = settingsHardwareRepository.save(settingsHardware);
        return settingsHardwareMapper.toDto(settingsHardware);
    }

    /**
     * Get all the settingsHardwares.
     *
     * @return the list of entities
     */
    @Override
    public List<SettingsHardwareDTO> findAll() {
        log.debug("Request to get all SettingsHardwares");
        return settingsHardwareRepository.findAll().stream()
            .map(settingsHardwareMapper::toDto)
            .collect(Collectors.toCollection(LinkedList::new));
    }


    /**
     * Get one settingsHardware by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    public Optional<SettingsHardwareDTO> findOne(String id) {
        log.debug("Request to get SettingsHardware : {}", id);
        return settingsHardwareRepository.findById(id)
            .map(settingsHardwareMapper::toDto);
    }

    /**
     * Delete the settingsHardware by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(String id) {
        log.debug("Request to delete SettingsHardware : {}", id);
        settingsHardwareRepository.deleteById(id);
    }
}
