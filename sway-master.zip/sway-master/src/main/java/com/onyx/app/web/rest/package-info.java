/**
 * Spring MVC REST controllers.
 */
package com.onyx.app.web.rest;
