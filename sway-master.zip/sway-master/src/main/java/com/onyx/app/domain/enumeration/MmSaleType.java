package com.onyx.app.domain.enumeration;

/**
 * The MmSaleType enumeration.
 */
public enum MmSaleType {
    PERCENT, AMOUNT
}
