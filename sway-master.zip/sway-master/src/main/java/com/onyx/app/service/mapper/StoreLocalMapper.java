package com.onyx.app.service.mapper;

import com.onyx.app.domain.*;
import com.onyx.app.service.dto.StoreLocalDTO;

import org.mapstruct.*;

/**
 * Mapper for the entity StoreLocal and its DTO StoreLocalDTO.
 */
@Mapper(componentModel = "spring", uses = {})
public interface StoreLocalMapper extends EntityMapper<StoreLocalDTO, StoreLocal> {


}
