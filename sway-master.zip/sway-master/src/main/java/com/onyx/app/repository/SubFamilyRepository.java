package com.onyx.app.repository;

import com.onyx.app.domain.SubFamily;
import org.springframework.stereotype.Repository;

/**
 * Spring Data Couchbase repository for the SubFamily entity.
 */
@SuppressWarnings("unused")
@Repository
public interface SubFamilyRepository extends N1qlCouchbaseRepository<SubFamily, String> {

}
