package com.onyx.app.repository;

import com.onyx.app.domain.Vendor;
import org.springframework.stereotype.Repository;

/**
 * Spring Data Couchbase repository for the Vendor entity.
 */
@SuppressWarnings("unused")
@Repository
public interface VendorRepository extends N1qlCouchbaseRepository<Vendor, String> {

}
