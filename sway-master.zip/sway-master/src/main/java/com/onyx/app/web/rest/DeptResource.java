package com.onyx.app.web.rest;

import com.codahale.metrics.annotation.Timed;
import com.onyx.app.domain.Dept;
import com.onyx.app.repository.DeptRepository;
import com.onyx.app.service.DeptService;
import com.onyx.app.web.rest.errors.BadRequestAlertException;
import com.onyx.app.web.rest.util.HeaderUtil;
import com.onyx.app.service.dto.DeptDTO;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.net.URI;
import java.net.URISyntaxException;

import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing Dept.
 */
@RestController
@RequestMapping("/api")
public class DeptResource {

    private final Logger log = LoggerFactory.getLogger(DeptResource.class);

    private static final String ENTITY_NAME = "dept";

    private final DeptService deptService;

    @Autowired
    private DeptRepository deptRepository;

    public DeptResource(DeptService deptService) {
        this.deptService = deptService;
    }

    /**
     * POST  /depts : Create a new dept.
     *
     * @param deptDTO the deptDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new deptDTO, or with status 400 (Bad Request) if the dept has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/depts")
    @Timed
    public ResponseEntity<DeptDTO> createDept(@Valid @RequestBody DeptDTO deptDTO) throws URISyntaxException {
        log.debug("REST request to save Dept : {}", deptDTO);
        if (deptDTO.getId() != null) {
            throw new BadRequestAlertException("A new dept cannot already have an ID", ENTITY_NAME, "idexists");
        }
        DeptDTO result = deptService.save(deptDTO);
        return ResponseEntity.created(new URI("/api/depts/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /depts : Updates an existing dept.
     *
     * @param deptDTO the deptDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated deptDTO,
     * or with status 400 (Bad Request) if the deptDTO is not valid,
     * or with status 500 (Internal Server Error) if the deptDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/depts")
    @Timed
    public ResponseEntity<DeptDTO> updateDept(@Valid @RequestBody DeptDTO deptDTO) throws URISyntaxException {
        log.debug("REST request to update Dept : {}", deptDTO);
        if (deptDTO.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        DeptDTO result = deptService.save(deptDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, deptDTO.getId().toString()))
            .body(result);
    }

    /**
     * GET  /depts : get all the depts.
     *
     * @return the ResponseEntity with status 200 (OK) and the list of depts in body
     */
    @GetMapping("/depts")
    @Timed
    public List<DeptDTO> getAllDepts() {
        log.debug("REST request to get all Depts");
        return deptService.findAll();
    }

    /**
     * GET /depts/:store_id: get all the depts based on his store
     *  @return the ResponseEntity with status 200 (OK) and the list of depts in body
     */
    @GetMapping("depts-store/{storeId}")
    @Timed
    public List<Dept> getAllDeptsOfStore(@PathVariable Integer storeId){
        log.debug("REST request to get all Depts of the Store");
        return deptRepository.findAllByStoreId(storeId);
    }

    /**
     * GET  /depts/:id : get the "id" dept.
     *
     * @param id the id of the deptDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the deptDTO, or with status 404 (Not Found)
     */
    @GetMapping("/depts/{id}")
    @Timed
    public ResponseEntity<DeptDTO> getDept(@PathVariable String id) {
        log.debug("REST request to get Dept : {}", id);
        Optional<DeptDTO> deptDTO = deptService.findOne(id);
        return ResponseUtil.wrapOrNotFound(deptDTO);
    }

    /**
     * DELETE  /depts/:id : delete the "id" dept.
     *
     * @param id the id of the deptDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/depts/{id}")
    @Timed
    public ResponseEntity<Void> deleteDept(@PathVariable String id) {
        log.debug("REST request to delete Dept : {}", id);
        deptService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id)).build();
    }
}
