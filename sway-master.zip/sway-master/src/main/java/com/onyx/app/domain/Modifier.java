package com.onyx.app.domain;

import org.springframework.data.annotation.Id;
import com.couchbase.client.java.repository.annotation.Field;
import org.springframework.data.couchbase.core.mapping.Document;
import org.springframework.data.couchbase.core.mapping.id.GeneratedValue;
import org.springframework.data.couchbase.core.mapping.id.IdPrefix;

import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.Objects;

import static com.onyx.app.config.Constants.ID_DELIMITER;
import static org.springframework.data.couchbase.core.mapping.id.GenerationStrategy.UNIQUE;

/**
 * A Modifier.
 */
@Document
public class Modifier implements Serializable {

	private static final long serialVersionUID = 1L;
	public static final String PREFIX = "modifier";

	@SuppressWarnings("unused")
	@IdPrefix
	private String prefix = PREFIX;

	@Id
	@GeneratedValue(strategy = UNIQUE, delimiter = ID_DELIMITER)
	private String id;

	@Field("store_id")
	private String storeId;

	@Field("modifier_name")
	private String modifierName;

	@Field("modifier_num")
	private Long modifierNum;

	@Field("modifier_price_1")
	private Double modifierPrice1;

	@Field("modifier_price_2")
	private Double modifierPrice2;

	@Field("modifier_price_3")
	private Double modifierPrice3;

	@Field("modifier_price_4")
	private Double modifierPrice4;

	@Field("modifier_adddsc_1")
	private String modifierADDDSC1;

	@Field("modifier_adddsc_2")
	private String modifierADDDSC2;

	@Field("modifier_adddsc_3")
	private String modifierADDDSC3;

	@Field("modifier_adddsc_4")
	private String modifierADDDSC4;

	@Field("dept_id")
	private String deptId;

	@Field("item_id")
	private String itemId;

	@Field("comment")
	@Size(max = 300)
	private String comment;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getStoreId() {
		return storeId;
	}

	public void setStoreId(String storeId) {
		this.storeId = storeId;
	}

	public String getModifierName() {
		return modifierName;
	}

	public Modifier modifierName(String modifierName) {
		this.modifierName = modifierName;
		return this;
	}

	public void setModifierName(String modifierName) {
		this.modifierName = modifierName;
	}

	public Long getModifierNum() {
		return modifierNum;
	}

	public Modifier modifierNum(Long modifierNum) {
		this.modifierNum = modifierNum;
		return this;
	}

	public void setModifierNum(Long modifierNum) {
		this.modifierNum = modifierNum;
	}

	public Double getModifierPrice1() {
		return modifierPrice1;
	}

	public Modifier modifierPrice1(Double modifierPrice1) {
		this.modifierPrice1 = modifierPrice1;
		return this;
	}

	public void setModifierPrice1(Double modifierPrice1) {
		this.modifierPrice1 = modifierPrice1;
	}

	public Double getModifierPrice2() {
		return modifierPrice2;
	}

	public Modifier modifierPrice2(Double modifierPrice2) {
		this.modifierPrice2 = modifierPrice2;
		return this;
	}

	public void setModifierPrice2(Double modifierPrice2) {
		this.modifierPrice2 = modifierPrice2;
	}

	public Double getModifierPrice3() {
		return modifierPrice3;
	}

	public Modifier modifierPrice3(Double modifierPrice3) {
		this.modifierPrice3 = modifierPrice3;
		return this;
	}

	public void setModifierPrice3(Double modifierPrice3) {
		this.modifierPrice3 = modifierPrice3;
	}

	public Double getModifierPrice4() {
		return modifierPrice4;
	}

	public Modifier modifierPrice4(Double modifierPrice4) {
		this.modifierPrice4 = modifierPrice4;
		return this;
	}

	public void setModifierPrice4(Double modifierPrice4) {
		this.modifierPrice4 = modifierPrice4;
	}

	public String getModifierADDDSC1() {
		return modifierADDDSC1;
	}

	public Modifier modifierADDDSC1(String modifierADDDSC1) {
		this.modifierADDDSC1 = modifierADDDSC1;
		return this;
	}

	public void setModifierADDDSC1(String modifierADDDSC1) {
		this.modifierADDDSC1 = modifierADDDSC1;
	}

	public String getModifierADDDSC2() {
		return modifierADDDSC2;
	}

	public Modifier modifierADDDSC2(String modifierADDDSC2) {
		this.modifierADDDSC2 = modifierADDDSC2;
		return this;
	}

	public void setModifierADDDSC2(String modifierADDDSC2) {
		this.modifierADDDSC2 = modifierADDDSC2;
	}

	public String getModifierADDDSC3() {
		return modifierADDDSC3;
	}

	public Modifier modifierADDDSC3(String modifierADDDSC3) {
		this.modifierADDDSC3 = modifierADDDSC3;
		return this;
	}

	public void setModifierADDDSC3(String modifierADDDSC3) {
		this.modifierADDDSC3 = modifierADDDSC3;
	}

	public String getModifierADDDSC4() {
		return modifierADDDSC4;
	}

	public Modifier modifierADDDSC4(String modifierADDDSC4) {
		this.modifierADDDSC4 = modifierADDDSC4;
		return this;
	}

	public void setModifierADDDSC4(String modifierADDDSC4) {
		this.modifierADDDSC4 = modifierADDDSC4;
	}
	// jhipster-needle-entity-add-getters-setters - JHipster will add getters and
	// setters here, do not remove

	public String getComment() {
		return comment;
	}

	public String getDeptId() {
		return deptId;
	}

	public void setDeptId(String deptId) {
		this.deptId = deptId;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getItemId() {
		return itemId;
	}

	public void setItemId(String itemId) {
		this.itemId = itemId;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		Modifier modifier = (Modifier) o;
		if (modifier.getId() == null || getId() == null) {
			return false;
		}
		return Objects.equals(getId(), modifier.getId());
	}

	@Override
	public int hashCode() {
		return Objects.hashCode(getId());
	}

}
