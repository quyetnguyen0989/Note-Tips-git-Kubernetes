package com.onyx.app.web.rest;

import com.codahale.metrics.annotation.Timed;
import com.onyx.app.service.PayoutService;
import com.onyx.app.web.rest.errors.BadRequestAlertException;
import com.onyx.app.web.rest.util.HeaderUtil;
import com.onyx.app.service.dto.PayoutDTO;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.net.URISyntaxException;

import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing Payout.
 */
@RestController
@RequestMapping("/api")
public class PayoutResource {

    private final Logger log = LoggerFactory.getLogger(PayoutResource.class);

    private static final String ENTITY_NAME = "payout";

    private final PayoutService payoutService;

    public PayoutResource(PayoutService payoutService) {
        this.payoutService = payoutService;
    }

    /**
     * POST  /payouts : Create a new payout.
     *
     * @param payoutDTO the payoutDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new payoutDTO, or with status 400 (Bad Request) if the payout has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/payouts")
    @Timed
    public ResponseEntity<PayoutDTO> createPayout(@RequestBody PayoutDTO payoutDTO) throws URISyntaxException {
        log.debug("REST request to save Payout : {}", payoutDTO);
        if (payoutDTO.getId() != null) {
            throw new BadRequestAlertException("A new payout cannot already have an ID", ENTITY_NAME, "idexists");
        }
        PayoutDTO result = payoutService.save(payoutDTO);
        return ResponseEntity.created(new URI("/api/payouts/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /payouts : Updates an existing payout.
     *
     * @param payoutDTO the payoutDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated payoutDTO,
     * or with status 400 (Bad Request) if the payoutDTO is not valid,
     * or with status 500 (Internal Server Error) if the payoutDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/payouts")
    @Timed
    public ResponseEntity<PayoutDTO> updatePayout(@RequestBody PayoutDTO payoutDTO) throws URISyntaxException {
        log.debug("REST request to update Payout : {}", payoutDTO);
        if (payoutDTO.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        PayoutDTO result = payoutService.save(payoutDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, payoutDTO.getId().toString()))
            .body(result);
    }

    /**
     * GET  /payouts : get all the payouts.
     *
     * @return the ResponseEntity with status 200 (OK) and the list of payouts in body
     */
    @GetMapping("/payouts")
    @Timed
    public List<PayoutDTO> getAllPayouts() {
        log.debug("REST request to get all Payouts");
        return payoutService.findAll();
    }

    /**
     * GET  /payouts/:id : get the "id" payout.
     *
     * @param id the id of the payoutDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the payoutDTO, or with status 404 (Not Found)
     */
    @GetMapping("/payouts/{id}")
    @Timed
    public ResponseEntity<PayoutDTO> getPayout(@PathVariable String id) {
        log.debug("REST request to get Payout : {}", id);
        Optional<PayoutDTO> payoutDTO = payoutService.findOne(id);
        return ResponseUtil.wrapOrNotFound(payoutDTO);
    }

    /**
     * DELETE  /payouts/:id : delete the "id" payout.
     *
     * @param id the id of the payoutDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/payouts/{id}")
    @Timed
    public ResponseEntity<Void> deletePayout(@PathVariable String id) {
        log.debug("REST request to delete Payout : {}", id);
        payoutService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id)).build();
    }
}
