package com.onyx.app.service.mapper;

import com.onyx.app.domain.*;
import com.onyx.app.service.dto.CustomerInfoDTO;

import org.mapstruct.*;

/**
 * Mapper for the entity CustomerInfo and its DTO CustomerInfoDTO.
 */
@Mapper(componentModel = "spring", uses = {})
public interface CustomerInfoMapper extends EntityMapper<CustomerInfoDTO, CustomerInfo> {


}
