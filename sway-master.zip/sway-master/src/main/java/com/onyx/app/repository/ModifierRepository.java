package com.onyx.app.repository;

import com.onyx.app.domain.Modifier;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Spring Data Couchbase repository for the Modifier entity.
 */
@SuppressWarnings("unused")
@Repository
public interface ModifierRepository extends N1qlCouchbaseRepository<Modifier, String> {


    List<Modifier> findAllByStoreIdAndDeptIdAndItemId(Integer store_id, Integer dept_id, Integer item_id);
}
