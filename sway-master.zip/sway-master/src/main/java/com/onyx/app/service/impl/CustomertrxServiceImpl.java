package com.onyx.app.service.impl;

import com.onyx.app.service.CustomertrxService;
import com.onyx.app.domain.Customertrx;
import com.onyx.app.repository.CustomertrxRepository;
import com.onyx.app.service.dto.CustomertrxDTO;
import com.onyx.app.service.mapper.CustomertrxMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.stereotype.Service;

import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
/**
 * Service Implementation for managing Customertrx.
 */
@Service
public class CustomertrxServiceImpl implements CustomertrxService {

    private final Logger log = LoggerFactory.getLogger(CustomertrxServiceImpl.class);

    private final CustomertrxRepository customertrxRepository;

    private final CustomertrxMapper customertrxMapper;

    public CustomertrxServiceImpl(CustomertrxRepository customertrxRepository, CustomertrxMapper customertrxMapper) {
        this.customertrxRepository = customertrxRepository;
        this.customertrxMapper = customertrxMapper;
    }

    /**
     * Save a customertrx.
     *
     * @param customertrxDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public CustomertrxDTO save(CustomertrxDTO customertrxDTO) {
        log.debug("Request to save Customertrx : {}", customertrxDTO);
        Customertrx customertrx = customertrxMapper.toEntity(customertrxDTO);
        customertrx = customertrxRepository.save(customertrx);
        return customertrxMapper.toDto(customertrx);
    }

    /**
     * Get all the customertrxes.
     *
     * @return the list of entities
     */
    @Override
    public List<CustomertrxDTO> findAll() {
        log.debug("Request to get all Customertrxes");
        return customertrxRepository.findAll().stream()
            .map(customertrxMapper::toDto)
            .collect(Collectors.toCollection(LinkedList::new));
    }


    /**
     * Get one customertrx by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    public Optional<CustomertrxDTO> findOne(String id) {
        log.debug("Request to get Customertrx : {}", id);
        return customertrxRepository.findById(id)
            .map(customertrxMapper::toDto);
    }

    /**
     * Delete the customertrx by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(String id) {
        log.debug("Request to delete Customertrx : {}", id);
        customertrxRepository.deleteById(id);
    }
}
