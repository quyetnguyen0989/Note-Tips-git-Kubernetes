package com.onyx.app.service;

import com.onyx.app.service.dto.InventoryTimeSaleDTO;

import java.util.List;
import java.util.Optional;

/**
 * Service Interface for managing InventoryTimeSale.
 */
public interface InventoryTimeSaleService {

    /**
     * Save a inventoryTimeSale.
     *
     * @param inventoryTimeSaleDTO the entity to save
     * @return the persisted entity
     */
    InventoryTimeSaleDTO save(InventoryTimeSaleDTO inventoryTimeSaleDTO);

    /**
     * Get all the inventoryTimeSales.
     *
     * @return the list of entities
     */
    List<InventoryTimeSaleDTO> findAll();


    /**
     * Get the "id" inventoryTimeSale.
     *
     * @param id the id of the entity
     * @return the entity
     */
    Optional<InventoryTimeSaleDTO> findOne(String id);

    /**
     * Delete the "id" inventoryTimeSale.
     *
     * @param id the id of the entity
     */
    void delete(String id);
}
