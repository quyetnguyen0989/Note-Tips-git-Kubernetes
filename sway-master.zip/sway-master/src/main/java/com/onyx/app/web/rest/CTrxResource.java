package com.onyx.app.web.rest;

import com.codahale.metrics.annotation.Timed;
import com.onyx.app.service.CTrxService;
import com.onyx.app.web.rest.errors.BadRequestAlertException;
import com.onyx.app.web.rest.util.HeaderUtil;
import com.onyx.app.service.dto.CTrxDTO;
import io.github.jhipster.web.util.ResponseUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.net.URISyntaxException;

import java.util.List;
import java.util.Optional;

/**
 * REST controller for managing CTrx.
 */
@RestController
@RequestMapping("/api")
public class CTrxResource {

    private final Logger log = LoggerFactory.getLogger(CTrxResource.class);

    private static final String ENTITY_NAME = "cTrx";

    private final CTrxService cTrxService;

    public CTrxResource(CTrxService cTrxService) {
        this.cTrxService = cTrxService;
    }

    /**
     * POST  /c-trxes : Create a new cTrx.
     *
     * @param cTrxDTO the cTrxDTO to create
     * @return the ResponseEntity with status 201 (Created) and with body the new cTrxDTO, or with status 400 (Bad Request) if the cTrx has already an ID
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PostMapping("/c-trxes")
    @Timed
    public ResponseEntity<CTrxDTO> createCTrx(@RequestBody CTrxDTO cTrxDTO) throws URISyntaxException {
        log.debug("REST request to save CTrx : {}", cTrxDTO);
        if (cTrxDTO.getId() != null) {
            throw new BadRequestAlertException("A new cTrx cannot already have an ID", ENTITY_NAME, "idexists");
        }
        CTrxDTO result = cTrxService.save(cTrxDTO);
        return ResponseEntity.created(new URI("/api/c-trxes/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * PUT  /c-trxes : Updates an existing cTrx.
     *
     * @param cTrxDTO the cTrxDTO to update
     * @return the ResponseEntity with status 200 (OK) and with body the updated cTrxDTO,
     * or with status 400 (Bad Request) if the cTrxDTO is not valid,
     * or with status 500 (Internal Server Error) if the cTrxDTO couldn't be updated
     * @throws URISyntaxException if the Location URI syntax is incorrect
     */
    @PutMapping("/c-trxes")
    @Timed
    public ResponseEntity<CTrxDTO> updateCTrx(@RequestBody CTrxDTO cTrxDTO) throws URISyntaxException {
        log.debug("REST request to update CTrx : {}", cTrxDTO);
        if (cTrxDTO.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        CTrxDTO result = cTrxService.save(cTrxDTO);
        return ResponseEntity.ok()
            .headers(HeaderUtil.createEntityUpdateAlert(ENTITY_NAME, cTrxDTO.getId().toString()))
            .body(result);
    }

    /**
     * GET  /c-trxes : get all the cTrxes.
     *
     * @return the ResponseEntity with status 200 (OK) and the list of cTrxes in body
     */
    @GetMapping("/c-trxes")
    @Timed
    public List<CTrxDTO> getAllCTrxes() {
        log.debug("REST request to get all CTrxes");
        return cTrxService.findAll();
    }

    /**
     * GET  /c-trxes/:id : get the "id" cTrx.
     *
     * @param id the id of the cTrxDTO to retrieve
     * @return the ResponseEntity with status 200 (OK) and with body the cTrxDTO, or with status 404 (Not Found)
     */
    @GetMapping("/c-trxes/{id}")
    @Timed
    public ResponseEntity<CTrxDTO> getCTrx(@PathVariable String id) {
        log.debug("REST request to get CTrx : {}", id);
        Optional<CTrxDTO> cTrxDTO = cTrxService.findOne(id);
        return ResponseUtil.wrapOrNotFound(cTrxDTO);
    }

    /**
     * DELETE  /c-trxes/:id : delete the "id" cTrx.
     *
     * @param id the id of the cTrxDTO to delete
     * @return the ResponseEntity with status 200 (OK)
     */
    @DeleteMapping("/c-trxes/{id}")
    @Timed
    public ResponseEntity<Void> deleteCTrx(@PathVariable String id) {
        log.debug("REST request to delete CTrx : {}", id);
        cTrxService.delete(id);
        return ResponseEntity.ok().headers(HeaderUtil.createEntityDeletionAlert(ENTITY_NAME, id)).build();
    }
}
