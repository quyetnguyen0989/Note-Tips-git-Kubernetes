package com.onyx.app.service.dto;

import java.io.Serializable;
import java.util.Objects;

/**
 * A DTO for the Modifier entity.
 */
public class ModifierDTO implements Serializable {

    private String id;

    private String storeId;

    private String modifierName;

    private Long modifierNum;

    private Double modifierPrice1;

    private Double modifierPrice2;

    private Double modifierPrice3;

    private Double modifierPrice4;

    private String modifierADDDSC1;

    private String modifierADDDSC2;

    private String modifierADDDSC3;

    private String modifierADDDSC4;

    private String deptId;

    private String itemId;

    private String comment;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getStoreId() {
		return storeId;
	}

	public void setStoreId(String storeId) {
		this.storeId = storeId;
	}

	public String getModifierName() {
        return modifierName;
    }

    public void setModifierName(String modifierName) {
        this.modifierName = modifierName;
    }


    public Long getModifierNum() {
        return modifierNum;
    }

    public void setModifierNum(Long modifierNum) {
        this.modifierNum = modifierNum;
    }

    public Double getModifierPrice1() {
        return modifierPrice1;
    }

    public void setModifierPrice1(Double modifierPrice1) {
        this.modifierPrice1 = modifierPrice1;
    }

    public Double getModifierPrice2() {
        return modifierPrice2;
    }

    public void setModifierPrice2(Double modifierPrice2) {
        this.modifierPrice2 = modifierPrice2;
    }

    public Double getModifierPrice3() {
        return modifierPrice3;
    }

    public void setModifierPrice3(Double modifierPrice3) {
        this.modifierPrice3 = modifierPrice3;
    }

    public Double getModifierPrice4() {
        return modifierPrice4;
    }

    public void setModifierPrice4(Double modifierPrice4) {
        this.modifierPrice4 = modifierPrice4;
    }

    public String getModifierADDDSC1() {
        return modifierADDDSC1;
    }

    public void setModifierADDDSC1(String modifierADDDSC1) {
        this.modifierADDDSC1 = modifierADDDSC1;
    }

    public String getModifierADDDSC2() {
        return modifierADDDSC2;
    }

    public void setModifierADDDSC2(String modifierADDDSC2) {
        this.modifierADDDSC2 = modifierADDDSC2;
    }

    public String getModifierADDDSC3() {
        return modifierADDDSC3;
    }

    public void setModifierADDDSC3(String modifierADDDSC3) {
        this.modifierADDDSC3 = modifierADDDSC3;
    }

    public String getModifierADDDSC4() {
        return modifierADDDSC4;
    }

    public void setModifierADDDSC4(String modifierADDDSC4) {
        this.modifierADDDSC4 = modifierADDDSC4;
    }

    public String getDeptId() {
        return deptId;
    }

    public void setDeptId(String deptId) {
        this.deptId = deptId;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }
    
    public String getItemId() {
		return itemId;
	}

	public void setItemId(String itemId) {
		this.itemId = itemId;
	}

	@Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        ModifierDTO modifierDTO = (ModifierDTO) o;
        if (modifierDTO.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), modifierDTO.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

}
