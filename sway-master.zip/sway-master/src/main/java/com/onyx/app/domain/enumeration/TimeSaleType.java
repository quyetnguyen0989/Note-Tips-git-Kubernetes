package com.onyx.app.domain.enumeration;

/**
 * The TimeSaleType enumeration.
 */
public enum TimeSaleType {
    PERCENT, AMOUNT
}
