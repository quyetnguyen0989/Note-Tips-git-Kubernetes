package com.onyx.app.domain;

import org.springframework.data.annotation.Id;
import com.couchbase.client.java.repository.annotation.Field;
import org.springframework.data.couchbase.core.mapping.Document;

import java.io.Serializable;
import java.time.ZonedDateTime;
import java.util.Objects;

/**
 * A CTrx.
 */
@Document
public class CTrx implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    private String id;

    @Field("store_id")
    private Integer storeId;

    @Field("date_time")
    private ZonedDateTime dateTime;

    @Field("trx_type")
    private String trxType;

    @Field("amount")
    private Double amount;

    @Field("approval")
    private String approval;

    @Field("reference")
    private String reference;

    @Field("inv_num")
    private Integer invNum;

    @Field("tip_amount")
    private Double tipAmount;

    @Field("card_type")
    private String cardType;

    @Field("tip_applied")
    private Double tipApplied;

    @Field("trout_d")
    private String troutD;

    @Field("post_auth_reference_number")
    private String postAuthReferenceNumber;

    @Field("order_id")
    private Integer orderId;

    @Field("language")
    private String language;

    @Field("card_number")
    private Integer cardNumber;

    @Field("payment_method")
    private String paymentMethod;

    @Field("cash_back")
    private Double cashBack;

    @Field("terminal_number")
    private Integer terminalNumber;

    @Field("a_ci")
    private String aCI;

    @Field("card_entry_source")
    private String cardEntrySource;

    @Field("trace_number")
    private String traceNumber;

    @Field("sequence_number")
    private Integer sequenceNumber;

    @Field("is_pre_paid_card")
    private String isPrePaidCard;

    @Field("pre_auth_amount")
    private Double preAuthAmount;

    @Field("app_label")
    private String appLabel;

    @Field("app_preferred_name")
    private String appPreferredName;

    @Field("card_plan")
    private String cardPlan;

    @Field("emv_aid")
    private String emvAid;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getStoreId() {
        return storeId;
    }

    public CTrx storeId(Integer storeId) {
        this.storeId = storeId;
        return this;
    }

    public void setStoreId(Integer storeId) {
        this.storeId = storeId;
    }

    public ZonedDateTime getDateTime() {
        return dateTime;
    }

    public CTrx dateTime(ZonedDateTime dateTime) {
        this.dateTime = dateTime;
        return this;
    }

    public void setDateTime(ZonedDateTime dateTime) {
        this.dateTime = dateTime;
    }

    public String getTrxType() {
        return trxType;
    }

    public CTrx trxType(String trxType) {
        this.trxType = trxType;
        return this;
    }

    public void setTrxType(String trxType) {
        this.trxType = trxType;
    }

    public Double getAmount() {
        return amount;
    }

    public CTrx amount(Double amount) {
        this.amount = amount;
        return this;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public String getApproval() {
        return approval;
    }

    public CTrx approval(String approval) {
        this.approval = approval;
        return this;
    }

    public void setApproval(String approval) {
        this.approval = approval;
    }

    public String getReference() {
        return reference;
    }

    public CTrx reference(String reference) {
        this.reference = reference;
        return this;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    public Integer getInvNum() {
        return invNum;
    }

    public CTrx invNum(Integer invNum) {
        this.invNum = invNum;
        return this;
    }

    public void setInvNum(Integer invNum) {
        this.invNum = invNum;
    }

    public Double getTipAmount() {
        return tipAmount;
    }

    public CTrx tipAmount(Double tipAmount) {
        this.tipAmount = tipAmount;
        return this;
    }

    public void setTipAmount(Double tipAmount) {
        this.tipAmount = tipAmount;
    }

    public String getCardType() {
        return cardType;
    }

    public CTrx cardType(String cardType) {
        this.cardType = cardType;
        return this;
    }

    public void setCardType(String cardType) {
        this.cardType = cardType;
    }

    public Double getTipApplied() {
        return tipApplied;
    }

    public CTrx tipApplied(Double tipApplied) {
        this.tipApplied = tipApplied;
        return this;
    }

    public void setTipApplied(Double tipApplied) {
        this.tipApplied = tipApplied;
    }

    public String getTroutD() {
        return troutD;
    }

    public CTrx troutD(String troutD) {
        this.troutD = troutD;
        return this;
    }

    public void setTroutD(String troutD) {
        this.troutD = troutD;
    }

    public String getPostAuthReferenceNumber() {
        return postAuthReferenceNumber;
    }

    public CTrx postAuthReferenceNumber(String postAuthReferenceNumber) {
        this.postAuthReferenceNumber = postAuthReferenceNumber;
        return this;
    }

    public void setPostAuthReferenceNumber(String postAuthReferenceNumber) {
        this.postAuthReferenceNumber = postAuthReferenceNumber;
    }

    public Integer getOrderId() {
        return orderId;
    }

    public CTrx orderId(Integer orderId) {
        this.orderId = orderId;
        return this;
    }

    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }

    public String getLanguage() {
        return language;
    }

    public CTrx language(String language) {
        this.language = language;
        return this;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public Integer getCardNumber() {
        return cardNumber;
    }

    public CTrx cardNumber(Integer cardNumber) {
        this.cardNumber = cardNumber;
        return this;
    }

    public void setCardNumber(Integer cardNumber) {
        this.cardNumber = cardNumber;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public CTrx paymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
        return this;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public Double getCashBack() {
        return cashBack;
    }

    public CTrx cashBack(Double cashBack) {
        this.cashBack = cashBack;
        return this;
    }

    public void setCashBack(Double cashBack) {
        this.cashBack = cashBack;
    }

    public Integer getTerminalNumber() {
        return terminalNumber;
    }

    public CTrx terminalNumber(Integer terminalNumber) {
        this.terminalNumber = terminalNumber;
        return this;
    }

    public void setTerminalNumber(Integer terminalNumber) {
        this.terminalNumber = terminalNumber;
    }

    public String getaCI() {
        return aCI;
    }

    public CTrx aCI(String aCI) {
        this.aCI = aCI;
        return this;
    }

    public void setaCI(String aCI) {
        this.aCI = aCI;
    }

    public String getCardEntrySource() {
        return cardEntrySource;
    }

    public CTrx cardEntrySource(String cardEntrySource) {
        this.cardEntrySource = cardEntrySource;
        return this;
    }

    public void setCardEntrySource(String cardEntrySource) {
        this.cardEntrySource = cardEntrySource;
    }

    public String getTraceNumber() {
        return traceNumber;
    }

    public CTrx traceNumber(String traceNumber) {
        this.traceNumber = traceNumber;
        return this;
    }

    public void setTraceNumber(String traceNumber) {
        this.traceNumber = traceNumber;
    }

    public Integer getSequenceNumber() {
        return sequenceNumber;
    }

    public CTrx sequenceNumber(Integer sequenceNumber) {
        this.sequenceNumber = sequenceNumber;
        return this;
    }

    public void setSequenceNumber(Integer sequenceNumber) {
        this.sequenceNumber = sequenceNumber;
    }

    public String getIsPrePaidCard() {
        return isPrePaidCard;
    }

    public CTrx isPrePaidCard(String isPrePaidCard) {
        this.isPrePaidCard = isPrePaidCard;
        return this;
    }

    public void setIsPrePaidCard(String isPrePaidCard) {
        this.isPrePaidCard = isPrePaidCard;
    }

    public Double getPreAuthAmount() {
        return preAuthAmount;
    }

    public CTrx preAuthAmount(Double preAuthAmount) {
        this.preAuthAmount = preAuthAmount;
        return this;
    }

    public void setPreAuthAmount(Double preAuthAmount) {
        this.preAuthAmount = preAuthAmount;
    }

    public String getAppLabel() {
        return appLabel;
    }

    public CTrx appLabel(String appLabel) {
        this.appLabel = appLabel;
        return this;
    }

    public void setAppLabel(String appLabel) {
        this.appLabel = appLabel;
    }

    public String getAppPreferredName() {
        return appPreferredName;
    }

    public CTrx appPreferredName(String appPreferredName) {
        this.appPreferredName = appPreferredName;
        return this;
    }

    public void setAppPreferredName(String appPreferredName) {
        this.appPreferredName = appPreferredName;
    }

    public String getCardPlan() {
        return cardPlan;
    }

    public CTrx cardPlan(String cardPlan) {
        this.cardPlan = cardPlan;
        return this;
    }

    public void setCardPlan(String cardPlan) {
        this.cardPlan = cardPlan;
    }

    public String getEmvAid() {
        return emvAid;
    }

    public CTrx emvAid(String emvAid) {
        this.emvAid = emvAid;
        return this;
    }

    public void setEmvAid(String emvAid) {
        this.emvAid = emvAid;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        CTrx cTrx = (CTrx) o;
        if (cTrx.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), cTrx.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "CTrx{" +
            "id=" + getId() +
            ", storeId=" + getStoreId() +
            ", dateTime='" + getDateTime() + "'" +
            ", trxType='" + getTrxType() + "'" +
            ", amount=" + getAmount() +
            ", approval='" + getApproval() + "'" +
            ", reference='" + getReference() + "'" +
            ", invNum=" + getInvNum() +
            ", tipAmount=" + getTipAmount() +
            ", cardType='" + getCardType() + "'" +
            ", tipApplied=" + getTipApplied() +
            ", troutD='" + getTroutD() + "'" +
            ", postAuthReferenceNumber='" + getPostAuthReferenceNumber() + "'" +
            ", orderId=" + getOrderId() +
            ", language='" + getLanguage() + "'" +
            ", cardNumber=" + getCardNumber() +
            ", paymentMethod='" + getPaymentMethod() + "'" +
            ", cashBack=" + getCashBack() +
            ", terminalNumber=" + getTerminalNumber() +
            ", aCI='" + getaCI() + "'" +
            ", cardEntrySource='" + getCardEntrySource() + "'" +
            ", traceNumber='" + getTraceNumber() + "'" +
            ", sequenceNumber=" + getSequenceNumber() +
            ", isPrePaidCard='" + getIsPrePaidCard() + "'" +
            ", preAuthAmount=" + getPreAuthAmount() +
            ", appLabel='" + getAppLabel() + "'" +
            ", appPreferredName='" + getAppPreferredName() + "'" +
            ", cardPlan='" + getCardPlan() + "'" +
            ", emvAid='" + getEmvAid() + "'" +
            "}";
    }
}
