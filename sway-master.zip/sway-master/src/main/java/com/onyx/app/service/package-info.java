/**
 * Service layer beans.
 */
package com.onyx.app.service;
