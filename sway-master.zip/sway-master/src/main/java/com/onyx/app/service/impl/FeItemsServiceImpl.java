package com.onyx.app.service.impl;

import com.onyx.app.service.FeItemsService;
import com.onyx.app.domain.FeItems;
import com.onyx.app.repository.FeItemsRepository;
import com.onyx.app.service.dto.FeItemsDTO;
import com.onyx.app.service.mapper.FeItemsMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.stereotype.Service;

import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Service Implementation for managing FeItems.
 */
@Service
public class FeItemsServiceImpl implements FeItemsService {

    private final Logger log = LoggerFactory.getLogger(FeItemsServiceImpl.class);

    private final FeItemsRepository feItemsRepository;

    private final FeItemsMapper feItemsMapper;

    public FeItemsServiceImpl(FeItemsRepository feItemsRepository, FeItemsMapper feItemsMapper) {
        this.feItemsRepository = feItemsRepository;
        this.feItemsMapper = feItemsMapper;
    }

    /**
     * Save a feItems.
     *
     * @param feItemsDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public FeItemsDTO save(FeItemsDTO feItemsDTO) {
        log.debug("Request to save FeItems : {}", feItemsDTO);
        FeItems feItems = feItemsMapper.toEntity(feItemsDTO);
        feItems = feItemsRepository.save(feItems);
        return feItemsMapper.toDto(feItems);
    }

    /**
     * Get all the feItems.
     *
     * @return the list of entities
     */
    @Override
    public List<FeItemsDTO> findAll() {
        log.debug("Request to get all FeItems");
        return feItemsRepository.findAll().stream()
            .map(feItemsMapper::toDto)
            .collect(Collectors.toCollection(LinkedList::new));
    }


    /**
     * Get one feItems by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    public Optional<FeItemsDTO> findOne(String id) {
        log.debug("Request to get FeItems : {}", id);
        return feItemsRepository.findById(id)
            .map(feItemsMapper::toDto);
    }

    /**
     * Delete the feItems by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(String id) {
        log.debug("Request to delete FeItems : {}", id);
        feItemsRepository.deleteById(id);
    }
}
