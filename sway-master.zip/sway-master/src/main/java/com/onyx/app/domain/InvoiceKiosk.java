package com.onyx.app.domain;

import org.springframework.data.annotation.Id;
import com.couchbase.client.java.repository.annotation.Field;
import org.springframework.data.couchbase.core.mapping.Document;
import org.springframework.data.couchbase.core.mapping.id.GeneratedValue;
import org.springframework.data.couchbase.core.mapping.id.IdPrefix;
import javax.validation.constraints.*;

import java.io.Serializable;
import java.time.ZonedDateTime;
import java.util.Objects;

import static com.onyx.app.config.Constants.ID_DELIMITER;
import static org.springframework.data.couchbase.core.mapping.id.GenerationStrategy.UNIQUE;

/**
 * A InvoiceKiosk.
 */
@Document
public class InvoiceKiosk implements Serializable {

    private static final long serialVersionUID = 1L;
    public static final String PREFIX = "invoicekiosk";

    @SuppressWarnings("unused")
    @IdPrefix
    private String prefix = PREFIX;

    @Id
    @GeneratedValue(strategy = UNIQUE, delimiter = ID_DELIMITER)
    private String id;

    @Field("item_num")
    private Integer itemNum;

    @Size(max = 50)
    @Field("item_name")
    private String itemName;

    @Field("store_id")
    private Integer storeId;

    @Field("kiosk_id")
    private Integer kioskId;

    @Field("cust_num")
    private Integer custNum;

    @Field("inv_num")
    private Integer invNum;

    @NotNull
    @Field("item_price")
    private Double itemPrice;

    @Field("inv_date_time")
    private ZonedDateTime invDateTime;

    @Field("discount")
    private Double discount;

    @Field("total_price")
    private Double totalPrice;

    @Field("total_tax_1")
    private Double totalTax1;

    @Field("grand_total")
    private Double grandTotal;

    @Field("amt_change")
    private Double amtChange;

    @Field("type")
    private String type;

    @Field("station_id")
    private Integer stationId;

    @Field("payment_method")
    private String paymentMethod;

    @Field("taxed_sales")
    private Double taxedSales;

    @Field("non_taxed_sales")
    private Double nonTaxedSales;

    @Field("cc_amount")
    private Double ccAmount;

    @Field("status")
    private String status;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getItemNum() {
        return itemNum;
    }

    public InvoiceKiosk itemNum(Integer itemNum) {
        this.itemNum = itemNum;
        return this;
    }

    public void setItemNum(Integer itemNum) {
        this.itemNum = itemNum;
    }

    public String getItemName() {
        return itemName;
    }

    public InvoiceKiosk itemName(String itemName) {
        this.itemName = itemName;
        return this;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public Integer getStoreId() {
        return storeId;
    }

    public InvoiceKiosk storeId(Integer storeId) {
        this.storeId = storeId;
        return this;
    }

    public void setStoreId(Integer storeId) {
        this.storeId = storeId;
    }

    public Integer getKioskId() {
        return kioskId;
    }

    public InvoiceKiosk kioskId(Integer kioskId) {
        this.kioskId = kioskId;
        return this;
    }

    public void setKioskId(Integer kioskId) {
        this.kioskId = kioskId;
    }

    public Integer getCustNum() {
        return custNum;
    }

    public InvoiceKiosk custNum(Integer custNum) {
        this.custNum = custNum;
        return this;
    }

    public void setCustNum(Integer custNum) {
        this.custNum = custNum;
    }

    public Integer getInvNum() {
        return invNum;
    }

    public InvoiceKiosk invNum(Integer invNum) {
        this.invNum = invNum;
        return this;
    }

    public void setInvNum(Integer invNum) {
        this.invNum = invNum;
    }

    public Double getItemPrice() {
        return itemPrice;
    }

    public InvoiceKiosk itemPrice(Double itemPrice) {
        this.itemPrice = itemPrice;
        return this;
    }

    public void setItemPrice(Double itemPrice) {
        this.itemPrice = itemPrice;
    }

    public ZonedDateTime getInvDateTime() {
        return invDateTime;
    }

    public InvoiceKiosk invDateTime(ZonedDateTime invDateTime) {
        this.invDateTime = invDateTime;
        return this;
    }

    public void setInvDateTime(ZonedDateTime invDateTime) {
        this.invDateTime = invDateTime;
    }

    public Double getDiscount() {
        return discount;
    }

    public InvoiceKiosk discount(Double discount) {
        this.discount = discount;
        return this;
    }

    public void setDiscount(Double discount) {
        this.discount = discount;
    }

    public Double getTotalPrice() {
        return totalPrice;
    }

    public InvoiceKiosk totalPrice(Double totalPrice) {
        this.totalPrice = totalPrice;
        return this;
    }

    public void setTotalPrice(Double totalPrice) {
        this.totalPrice = totalPrice;
    }

    public Double getTotalTax1() {
        return totalTax1;
    }

    public InvoiceKiosk totalTax1(Double totalTax1) {
        this.totalTax1 = totalTax1;
        return this;
    }

    public void setTotalTax1(Double totalTax1) {
        this.totalTax1 = totalTax1;
    }

    public Double getGrandTotal() {
        return grandTotal;
    }

    public InvoiceKiosk grandTotal(Double grandTotal) {
        this.grandTotal = grandTotal;
        return this;
    }

    public void setGrandTotal(Double grandTotal) {
        this.grandTotal = grandTotal;
    }

    public Double getAmtChange() {
        return amtChange;
    }

    public InvoiceKiosk amtChange(Double amtChange) {
        this.amtChange = amtChange;
        return this;
    }

    public void setAmtChange(Double amtChange) {
        this.amtChange = amtChange;
    }

    public String getType() {
        return type;
    }

    public InvoiceKiosk type(String type) {
        this.type = type;
        return this;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Integer getStationId() {
        return stationId;
    }

    public InvoiceKiosk stationId(Integer stationId) {
        this.stationId = stationId;
        return this;
    }

    public void setStationId(Integer stationId) {
        this.stationId = stationId;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public InvoiceKiosk paymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
        return this;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public Double getTaxedSales() {
        return taxedSales;
    }

    public InvoiceKiosk taxedSales(Double taxedSales) {
        this.taxedSales = taxedSales;
        return this;
    }

    public void setTaxedSales(Double taxedSales) {
        this.taxedSales = taxedSales;
    }

    public Double getNonTaxedSales() {
        return nonTaxedSales;
    }

    public InvoiceKiosk nonTaxedSales(Double nonTaxedSales) {
        this.nonTaxedSales = nonTaxedSales;
        return this;
    }

    public void setNonTaxedSales(Double nonTaxedSales) {
        this.nonTaxedSales = nonTaxedSales;
    }

    public Double getCcAmount() {
        return ccAmount;
    }

    public InvoiceKiosk ccAmount(Double ccAmount) {
        this.ccAmount = ccAmount;
        return this;
    }

    public void setCcAmount(Double ccAmount) {
        this.ccAmount = ccAmount;
    }

    public String getStatus() {
        return status;
    }

    public InvoiceKiosk status(String status) {
        this.status = status;
        return this;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        InvoiceKiosk invoiceKiosk = (InvoiceKiosk) o;
        if (invoiceKiosk.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), invoiceKiosk.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "InvoiceKiosk{" +
            "id=" + getId() +
            ", itemNum=" + getItemNum() +
            ", itemName='" + getItemName() + "'" +
            ", storeId=" + getStoreId() +
            ", kioskId=" + getKioskId() +
            ", custNum=" + getCustNum() +
            ", invNum=" + getInvNum() +
            ", itemPrice=" + getItemPrice() +
            ", invDateTime='" + getInvDateTime() + "'" +
            ", discount=" + getDiscount() +
            ", totalPrice=" + getTotalPrice() +
            ", totalTax1=" + getTotalTax1() +
            ", grandTotal=" + getGrandTotal() +
            ", amtChange=" + getAmtChange() +
            ", type='" + getType() + "'" +
            ", stationId=" + getStationId() +
            ", paymentMethod='" + getPaymentMethod() + "'" +
            ", taxedSales=" + getTaxedSales() +
            ", nonTaxedSales=" + getNonTaxedSales() +
            ", ccAmount=" + getCcAmount() +
            ", status='" + getStatus() + "'" +
            "}";
    }
}
