package com.onyx.app.domain.enumeration;

/**
 * The HardwarePinpadType enumeration.
 */
public enum HardwarePinpadType {
    PAX, VERIFONE
}
