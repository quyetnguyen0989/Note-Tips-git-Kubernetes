package com.onyx.app.service.dto;

import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.Objects;
import com.onyx.app.domain.enumeration.MmSaleType;

/**
 * A DTO for the InventoryMixAndMatch entity.
 */
public class InventoryMixAndMatchDTO implements Serializable {

    private String id;

    @Size(max = 25)
    private String itemNum;

    @Size(max = 50)
    private String itemName;

    private String startDate;

    private String endDate;

    private Double salePrice;

    private Double salePercent;

    private MmSaleType type;

    private Integer storeId;

    @Size(max = 25)
    private String mmSaleId;

    @NotNull
    private Integer qty;

    private Boolean active;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getItemNum() {
        return itemNum;
    }

    public void setItemNum(String itemNum) {
        this.itemNum = itemNum;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public Double getSalePrice() {
        return salePrice;
    }

    public void setSalePrice(Double salePrice) {
        this.salePrice = salePrice;
    }

    public Double getSalePercent() {
        return salePercent;
    }

    public void setSalePercent(Double salePercent) {
        this.salePercent = salePercent;
    }

    public MmSaleType getType() {
        return type;
    }

    public void setType(MmSaleType type) {
        this.type = type;
    }

    public Integer getStoreId() {
        return storeId;
    }

    public void setStoreId(Integer storeId) {
        this.storeId = storeId;
    }

    public String getMmSaleId() {
        return mmSaleId;
    }

    public void setMmSaleId(String mmSaleId) {
        this.mmSaleId = mmSaleId;
    }

    public Integer getQty() {
        return qty;
    }

    public void setQty(Integer qty) {
        this.qty = qty;
    }

    public Boolean isActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        InventoryMixAndMatchDTO inventoryMixAndMatchDTO = (InventoryMixAndMatchDTO) o;
        if (inventoryMixAndMatchDTO.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), inventoryMixAndMatchDTO.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "InventoryMixAndMatchDTO{" +
            "id=" + getId() +
            ", itemNum='" + getItemNum() + "'" +
            ", itemName='" + getItemName() + "'" +
            ", startDate='" + getStartDate() + "'" +
            ", endDate='" + getEndDate() + "'" +
            ", salePrice=" + getSalePrice() +
            ", salePercent=" + getSalePercent() +
            ", type='" + getType() + "'" +
            ", storeId=" + getStoreId() +
            ", mmSaleId='" + getMmSaleId() + "'" +
            ", qty=" + getQty() +
            ", active='" + isActive() + "'" +
            "}";
    }
}
