package com.onyx.app.domain;

import org.springframework.data.annotation.Id;
import com.couchbase.client.java.repository.annotation.Field;
import org.springframework.data.couchbase.core.mapping.Document;
import org.springframework.data.couchbase.core.mapping.id.GeneratedValue;
import org.springframework.data.couchbase.core.mapping.id.IdPrefix;
import javax.validation.constraints.*;

import java.io.Serializable;
import java.util.Objects;

import com.onyx.app.domain.enumeration.TimeSaleType;

import static com.onyx.app.config.Constants.ID_DELIMITER;
import static org.springframework.data.couchbase.core.mapping.id.GenerationStrategy.UNIQUE;

/**
 * A InventoryTimeSale.
 */
@Document
public class InventoryTimeSale implements Serializable {

    private static final long serialVersionUID = 1L;
    public static final String PREFIX = "inventorytimesale";

    @SuppressWarnings("unused")
    @IdPrefix
    private String prefix = PREFIX;

    @Id
    @GeneratedValue(strategy = UNIQUE, delimiter = ID_DELIMITER)
    private String id;

    @Size(max = 25)
    @Field("item_num")
    private String itemNum;

    @Size(max = 50)
    @Field("item_name")
    private String itemName;

    @NotNull
    @Field("start_date")
    private String startDate;

    @NotNull
    @Field("end_date")
    private String endDate;

    @Field("sale_price")
    private Double salePrice;

    @Field("sale_percent")
    private Double salePercent;

    @NotNull
    @Field("type")
    private TimeSaleType type;

    @NotNull
    @Field("store_id")
    private Integer storeId;

    @Size(max = 25)
    @Field("time_sale_id")
    private String timeSaleId;

    @Field("active")
    private Boolean active;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getItemNum() {
        return itemNum;
    }

    public InventoryTimeSale itemNum(String itemNum) {
        this.itemNum = itemNum;
        return this;
    }

    public void setItemNum(String itemNum) {
        this.itemNum = itemNum;
    }

    public String getItemName() {
        return itemName;
    }

    public InventoryTimeSale itemName(String itemName) {
        this.itemName = itemName;
        return this;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public String getStartDate() {
        return startDate;
    }

    public InventoryTimeSale startDate(String startDate) {
        this.startDate = startDate;
        return this;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public InventoryTimeSale endDate(String endDate) {
        this.endDate = endDate;
        return this;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public Double getSalePrice() {
        return salePrice;
    }

    public InventoryTimeSale salePrice(Double salePrice) {
        this.salePrice = salePrice;
        return this;
    }

    public void setSalePrice(Double salePrice) {
        this.salePrice = salePrice;
    }

    public Double getSalePercent() {
        return salePercent;
    }

    public InventoryTimeSale salePercent(Double salePercent) {
        this.salePercent = salePercent;
        return this;
    }

    public void setSalePercent(Double salePercent) {
        this.salePercent = salePercent;
    }

    public TimeSaleType getType() {
        return type;
    }

    public InventoryTimeSale type(TimeSaleType type) {
        this.type = type;
        return this;
    }

    public void setType(TimeSaleType type) {
        this.type = type;
    }

    public Integer getStoreId() {
        return storeId;
    }

    public InventoryTimeSale storeId(Integer storeId) {
        this.storeId = storeId;
        return this;
    }

    public void setStoreId(Integer storeId) {
        this.storeId = storeId;
    }

    public String getTimeSaleId() {
        return timeSaleId;
    }

    public InventoryTimeSale timeSaleId(String timeSaleId) {
        this.timeSaleId = timeSaleId;
        return this;
    }

    public void setTimeSaleId(String timeSaleId) {
        this.timeSaleId = timeSaleId;
    }

    public Boolean isActive() {
        return active;
    }

    public InventoryTimeSale active(Boolean active) {
        this.active = active;
        return this;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        InventoryTimeSale inventoryTimeSale = (InventoryTimeSale) o;
        if (inventoryTimeSale.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), inventoryTimeSale.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "InventoryTimeSale{" +
            "id=" + getId() +
            ", itemNum='" + getItemNum() + "'" +
            ", itemName='" + getItemName() + "'" +
            ", startDate='" + getStartDate() + "'" +
            ", endDate='" + getEndDate() + "'" +
            ", salePrice=" + getSalePrice() +
            ", salePercent=" + getSalePercent() +
            ", type='" + getType() + "'" +
            ", storeId=" + getStoreId() +
            ", timeSaleId='" + getTimeSaleId() + "'" +
            ", active='" + isActive() + "'" +
            "}";
    }
}
