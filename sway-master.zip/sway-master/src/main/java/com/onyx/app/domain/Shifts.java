package com.onyx.app.domain;

import org.springframework.data.annotation.Id;
import com.couchbase.client.java.repository.annotation.Field;
import org.springframework.data.couchbase.core.mapping.Document;

import java.io.Serializable;
import java.time.ZonedDateTime;
import java.util.Objects;

/**
 * A Shifts.
 */
@Document
public class Shifts implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    private String id;

    @Field("shift_id")
    private Integer shiftId;

    @Field("store_id")
    private Integer storeId;

    @Field("start_datetime")
    private ZonedDateTime startDatetime;

    @Field("end_datetime")
    private ZonedDateTime endDatetime;

    @Field("id_used")
    private Integer idUsed;

    @Field("net_sales_taxed")
    private Double netSalesTaxed;

    @Field("net_sales_non_taxed")
    private Double netSalesNonTaxed;

    @Field("net_sales_tax_exempt")
    private Double netSalesTaxExempt;

    @Field("tax_1")
    private Double tax1;

    @Field("tax_2")
    private Double tax2;

    @Field("tax_3")
    private Double tax3;

    @Field("tax_custom")
    private Double taxCustom;

    @Field("total_num_trans")
    private Double totalNumTrans;

    @Field("open_cashierid")
    private Integer openCashierid;

    @Field("close_cashierid")
    private Integer closeCashierid;

    @Field("close_out_count")
    private Double closeOutCount;

    @Field("cashback_amount")
    private Double cashbackAmount;

    @Field("open_amount")
    private Double openAmount;

    @Field("close_amount")
    private Double closeAmount;

    @Field("suggested_open_amount")
    private Double suggestedOpenAmount;

    @Field("overshort")
    private Double overshort;

    @Field("cash_total")
    private Double cashTotal;

    @Field("c_total")
    private Double cTotal;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getShiftId() {
        return shiftId;
    }

    public Shifts shiftId(Integer shiftId) {
        this.shiftId = shiftId;
        return this;
    }

    public void setShiftId(Integer shiftId) {
        this.shiftId = shiftId;
    }

    public Integer getStoreId() {
        return storeId;
    }

    public Shifts storeId(Integer storeId) {
        this.storeId = storeId;
        return this;
    }

    public void setStoreId(Integer storeId) {
        this.storeId = storeId;
    }

    public ZonedDateTime getStartDatetime() {
        return startDatetime;
    }

    public Shifts startDatetime(ZonedDateTime startDatetime) {
        this.startDatetime = startDatetime;
        return this;
    }

    public void setStartDatetime(ZonedDateTime startDatetime) {
        this.startDatetime = startDatetime;
    }

    public ZonedDateTime getEndDatetime() {
        return endDatetime;
    }

    public Shifts endDatetime(ZonedDateTime endDatetime) {
        this.endDatetime = endDatetime;
        return this;
    }

    public void setEndDatetime(ZonedDateTime endDatetime) {
        this.endDatetime = endDatetime;
    }

    public Integer getIdUsed() {
        return idUsed;
    }

    public Shifts idUsed(Integer idUsed) {
        this.idUsed = idUsed;
        return this;
    }

    public void setIdUsed(Integer idUsed) {
        this.idUsed = idUsed;
    }

    public Double getNetSalesTaxed() {
        return netSalesTaxed;
    }

    public Shifts netSalesTaxed(Double netSalesTaxed) {
        this.netSalesTaxed = netSalesTaxed;
        return this;
    }

    public void setNetSalesTaxed(Double netSalesTaxed) {
        this.netSalesTaxed = netSalesTaxed;
    }

    public Double getNetSalesNonTaxed() {
        return netSalesNonTaxed;
    }

    public Shifts netSalesNonTaxed(Double netSalesNonTaxed) {
        this.netSalesNonTaxed = netSalesNonTaxed;
        return this;
    }

    public void setNetSalesNonTaxed(Double netSalesNonTaxed) {
        this.netSalesNonTaxed = netSalesNonTaxed;
    }

    public Double getNetSalesTaxExempt() {
        return netSalesTaxExempt;
    }

    public Shifts netSalesTaxExempt(Double netSalesTaxExempt) {
        this.netSalesTaxExempt = netSalesTaxExempt;
        return this;
    }

    public void setNetSalesTaxExempt(Double netSalesTaxExempt) {
        this.netSalesTaxExempt = netSalesTaxExempt;
    }

    public Double getTax1() {
        return tax1;
    }

    public Shifts tax1(Double tax1) {
        this.tax1 = tax1;
        return this;
    }

    public void setTax1(Double tax1) {
        this.tax1 = tax1;
    }

    public Double getTax2() {
        return tax2;
    }

    public Shifts tax2(Double tax2) {
        this.tax2 = tax2;
        return this;
    }

    public void setTax2(Double tax2) {
        this.tax2 = tax2;
    }

    public Double getTax3() {
        return tax3;
    }

    public Shifts tax3(Double tax3) {
        this.tax3 = tax3;
        return this;
    }

    public void setTax3(Double tax3) {
        this.tax3 = tax3;
    }

    public Double getTaxCustom() {
        return taxCustom;
    }

    public Shifts taxCustom(Double taxCustom) {
        this.taxCustom = taxCustom;
        return this;
    }

    public void setTaxCustom(Double taxCustom) {
        this.taxCustom = taxCustom;
    }

    public Double getTotalNumTrans() {
        return totalNumTrans;
    }

    public Shifts totalNumTrans(Double totalNumTrans) {
        this.totalNumTrans = totalNumTrans;
        return this;
    }

    public void setTotalNumTrans(Double totalNumTrans) {
        this.totalNumTrans = totalNumTrans;
    }

    public Integer getOpenCashierid() {
        return openCashierid;
    }

    public Shifts openCashierid(Integer openCashierid) {
        this.openCashierid = openCashierid;
        return this;
    }

    public void setOpenCashierid(Integer openCashierid) {
        this.openCashierid = openCashierid;
    }

    public Integer getCloseCashierid() {
        return closeCashierid;
    }

    public Shifts closeCashierid(Integer closeCashierid) {
        this.closeCashierid = closeCashierid;
        return this;
    }

    public void setCloseCashierid(Integer closeCashierid) {
        this.closeCashierid = closeCashierid;
    }

    public Double getCloseOutCount() {
        return closeOutCount;
    }

    public Shifts closeOutCount(Double closeOutCount) {
        this.closeOutCount = closeOutCount;
        return this;
    }

    public void setCloseOutCount(Double closeOutCount) {
        this.closeOutCount = closeOutCount;
    }

    public Double getCashbackAmount() {
        return cashbackAmount;
    }

    public Shifts cashbackAmount(Double cashbackAmount) {
        this.cashbackAmount = cashbackAmount;
        return this;
    }

    public void setCashbackAmount(Double cashbackAmount) {
        this.cashbackAmount = cashbackAmount;
    }

    public Double getOpenAmount() {
        return openAmount;
    }

    public Shifts openAmount(Double openAmount) {
        this.openAmount = openAmount;
        return this;
    }

    public void setOpenAmount(Double openAmount) {
        this.openAmount = openAmount;
    }

    public Double getCloseAmount() {
        return closeAmount;
    }

    public Shifts closeAmount(Double closeAmount) {
        this.closeAmount = closeAmount;
        return this;
    }

    public void setCloseAmount(Double closeAmount) {
        this.closeAmount = closeAmount;
    }

    public Double getSuggestedOpenAmount() {
        return suggestedOpenAmount;
    }

    public Shifts suggestedOpenAmount(Double suggestedOpenAmount) {
        this.suggestedOpenAmount = suggestedOpenAmount;
        return this;
    }

    public void setSuggestedOpenAmount(Double suggestedOpenAmount) {
        this.suggestedOpenAmount = suggestedOpenAmount;
    }

    public Double getOvershort() {
        return overshort;
    }

    public Shifts overshort(Double overshort) {
        this.overshort = overshort;
        return this;
    }

    public void setOvershort(Double overshort) {
        this.overshort = overshort;
    }

    public Double getCashTotal() {
        return cashTotal;
    }

    public Shifts cashTotal(Double cashTotal) {
        this.cashTotal = cashTotal;
        return this;
    }

    public void setCashTotal(Double cashTotal) {
        this.cashTotal = cashTotal;
    }

    public Double getcTotal() {
        return cTotal;
    }

    public Shifts cTotal(Double cTotal) {
        this.cTotal = cTotal;
        return this;
    }

    public void setcTotal(Double cTotal) {
        this.cTotal = cTotal;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Shifts shifts = (Shifts) o;
        if (shifts.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), shifts.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "Shifts{" +
            "id=" + getId() +
            ", shiftId=" + getShiftId() +
            ", storeId=" + getStoreId() +
            ", startDatetime='" + getStartDatetime() + "'" +
            ", endDatetime='" + getEndDatetime() + "'" +
            ", idUsed=" + getIdUsed() +
            ", netSalesTaxed=" + getNetSalesTaxed() +
            ", netSalesNonTaxed=" + getNetSalesNonTaxed() +
            ", netSalesTaxExempt=" + getNetSalesTaxExempt() +
            ", tax1=" + getTax1() +
            ", tax2=" + getTax2() +
            ", tax3=" + getTax3() +
            ", taxCustom=" + getTaxCustom() +
            ", totalNumTrans=" + getTotalNumTrans() +
            ", openCashierid=" + getOpenCashierid() +
            ", closeCashierid=" + getCloseCashierid() +
            ", closeOutCount=" + getCloseOutCount() +
            ", cashbackAmount=" + getCashbackAmount() +
            ", openAmount=" + getOpenAmount() +
            ", closeAmount=" + getCloseAmount() +
            ", suggestedOpenAmount=" + getSuggestedOpenAmount() +
            ", overshort=" + getOvershort() +
            ", cashTotal=" + getCashTotal() +
            ", cTotal=" + getcTotal() +
            "}";
    }
}
