package com.onyx.app.service.dto;

import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.Objects;
import com.onyx.app.domain.enumeration.BulkSaleType;

/**
 * A DTO for the InventoryBulkPrice entity.
 */
public class InventoryBulkPriceDTO implements Serializable {

    private String id;

    @Size(max = 25)
    private String itemNum;

    @Size(max = 50)
    private String itemName;

    private Double salePrice;

    private Double salePercent;

    private BulkSaleType type;

    private Integer storeId;

    @Size(max = 25)
    private String bulkSaleId;

    @NotNull
    private Integer qty;

    private Boolean active;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getItemNum() {
        return itemNum;
    }

    public void setItemNum(String itemNum) {
        this.itemNum = itemNum;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public Double getSalePrice() {
        return salePrice;
    }

    public void setSalePrice(Double salePrice) {
        this.salePrice = salePrice;
    }

    public Double getSalePercent() {
        return salePercent;
    }

    public void setSalePercent(Double salePercent) {
        this.salePercent = salePercent;
    }

    public BulkSaleType getType() {
        return type;
    }

    public void setType(BulkSaleType type) {
        this.type = type;
    }

    public Integer getStoreId() {
        return storeId;
    }

    public void setStoreId(Integer storeId) {
        this.storeId = storeId;
    }

    public String getBulkSaleId() {
        return bulkSaleId;
    }

    public void setBulkSaleId(String bulkSaleId) {
        this.bulkSaleId = bulkSaleId;
    }

    public Integer getQty() {
        return qty;
    }

    public void setQty(Integer qty) {
        this.qty = qty;
    }

    public Boolean isActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        InventoryBulkPriceDTO inventoryBulkPriceDTO = (InventoryBulkPriceDTO) o;
        if (inventoryBulkPriceDTO.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), inventoryBulkPriceDTO.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "InventoryBulkPriceDTO{" +
            "id=" + getId() +
            ", itemNum='" + getItemNum() + "'" +
            ", itemName='" + getItemName() + "'" +
            ", salePrice=" + getSalePrice() +
            ", salePercent=" + getSalePercent() +
            ", type='" + getType() + "'" +
            ", storeId=" + getStoreId() +
            ", bulkSaleId='" + getBulkSaleId() + "'" +
            ", qty=" + getQty() +
            ", active='" + isActive() + "'" +
            "}";
    }
}
