/**
 * Data Transfer Objects.
 */
package com.onyx.app.service.dto;
