package com.onyx.app.domain;

import org.springframework.data.annotation.Id;
import com.couchbase.client.java.repository.annotation.Field;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import org.springframework.data.annotation.Reference;
import org.springframework.data.couchbase.core.mapping.Document;
import org.springframework.data.couchbase.core.mapping.id.GeneratedValue;
import org.springframework.data.couchbase.core.mapping.id.IdPrefix;
import javax.validation.constraints.*;

import java.io.Serializable;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

import static com.onyx.app.config.Constants.ID_DELIMITER;
import static org.springframework.data.couchbase.core.mapping.id.GenerationStrategy.UNIQUE;

/**
 * A Inventory.
 */
//@Data
//@NoArgsConstructor
//@AllArgsConstructor
@Document
public class Inventory implements Serializable {

    private static final long serialVersionUID = 1L;
    public static final String PREFIX = "inventory";

    @SuppressWarnings("unused")
    @IdPrefix
    private String prefix = PREFIX;

    @Id
    @GeneratedValue(strategy = UNIQUE, delimiter = ID_DELIMITER)
    private String id;

    @Field("itemnum")
    private Integer itemnum;
    
    @Size(max = 50)
    @Field("itemname")
    private String itemname;
    
    @Field("itemhas_mods")
    private Boolean itemhasMods;

    @Field("item_img")
    private Boolean itemImg;

    @Field("item_spcl")
    private Boolean itemSpcl;

    @Field("item_on_hh")
    private Boolean itemOnHH;
    
    @NotNull
    @Field("itemprice")
    private Double itemprice;

    @Field("minprice")
    private Double minprice;
    
    @Size(max = 10)
    @Field("itemtype")
    private String itemtype;
    
    @NotNull
    @Field("cost")
    private Double cost;

    @Field("stock")
    private Double stock;

    @Field("reorder")
    private Double reorder;

    @Field("tax_1")
    private Boolean tax1;

    @Field("vendorpartnumber")
    private Integer vendorpartnumber;
    
    @Field("points")
    private Integer points;
    
    @Field("location")
    private Integer location;

    @Field("autoweigh")
    private Boolean autoweigh;

    @Field("numpercase")
    private Integer numpercase;

    @Field("foodstampable")
    private Boolean foodstampable;

    @Field("checkid")
    private Boolean checkid;

    @Field("askprice")
    private Boolean askprice;

    @Field("askquantity")
    private Boolean askquantity;

    @Field("disabled")
    private Boolean disabled;

    @Field("unitsize")
    private String unitsize;

    @Field("askdescription")
    private Boolean askdescription;

    @Field("checkid_2")
    private Boolean checkid2;

    @Field("countitem")
    private Boolean countitem;
    
    @Field("hh_time_start")
    private Instant hhTimeStart;

    @Field("hh_time_end")
    private Instant hhTimeEnd;

    @Field("hh_price")
    private Double hhPrice;

    @Field("img_url")
    private String imgUrl;
    
    @Field("has_bulk_price")
    private Double hasBulkprice;
    
    @Field("bulkpricing")
    private Double bulkpricing;

    @Field("qty")
    private Integer qty;
    
    @Field("item_spcl_price")
    private Double itemSpclPrice;
    
    private List<String> modifiersIds ;
    
    private List<String> modifiersGroupsIds ;

    private String brandId;
    
    private String familyId;
    
    private String subfamilyId;
    
    private String sectionId;
    
    private String storeId;
    
    private String departmentId;
    
    private String categoryId;
    
//    @Reference
//    private Family family;
//    
//    @Reference
//    private SubFamily subfamily;
//    
//    @Reference
//    private Section section;
//    
//    @Reference
//    private StoreLocal store;
//    
//    @Reference
//    private Dept department;
//    
//    @Reference
//    private Category category;

	public String getPrefix() {
		return prefix;
	}

	public void setPrefix(String prefix) {
		this.prefix = prefix;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Integer getItemnum() {
		return itemnum;
	}

	public void setItemnum(Integer itemnum) {
		this.itemnum = itemnum;
	}

	public String getItemname() {
		return itemname;
	}

	public void setItemname(String itemname) {
		this.itemname = itemname;
	}

	public Boolean getItemhasMods() {
		return itemhasMods;
	}

	public void setItemhasMods(Boolean itemhasMods) {
		this.itemhasMods = itemhasMods;
	}

	public Boolean getItemImg() {
		return itemImg;
	}

	public void setItemImg(Boolean itemImg) {
		this.itemImg = itemImg;
	}

	public Boolean getItemSpcl() {
		return itemSpcl;
	}

	public void setItemSpcl(Boolean itemSpcl) {
		this.itemSpcl = itemSpcl;
	}

	public Boolean getItemOnHH() {
		return itemOnHH;
	}

	public void setItemOnHH(Boolean itemOnHH) {
		this.itemOnHH = itemOnHH;
	}

	public Double getItemprice() {
		return itemprice;
	}

	public void setItemprice(Double itemprice) {
		this.itemprice = itemprice;
	}

	public Double getMinprice() {
		return minprice;
	}

	public void setMinprice(Double minprice) {
		this.minprice = minprice;
	}

	public String getItemtype() {
		return itemtype;
	}

	public void setItemtype(String itemtype) {
		this.itemtype = itemtype;
	}

	public Double getCost() {
		return cost;
	}

	public void setCost(Double cost) {
		this.cost = cost;
	}

	public Double getStock() {
		return stock;
	}

	public void setStock(Double stock) {
		this.stock = stock;
	}

	public Double getReorder() {
		return reorder;
	}

	public void setReorder(Double reorder) {
		this.reorder = reorder;
	}

	public Boolean getTax1() {
		return tax1;
	}

	public void setTax1(Boolean tax1) {
		this.tax1 = tax1;
	}

	public Integer getVendorpartnumber() {
		return vendorpartnumber;
	}

	public void setVendorpartnumber(Integer vendorpartnumber) {
		this.vendorpartnumber = vendorpartnumber;
	}

	public Integer getPoints() {
		return points;
	}

	public void setPoints(Integer points) {
		this.points = points;
	}

	public Integer getLocation() {
		return location;
	}

	public void setLocation(Integer location) {
		this.location = location;
	}

	public Boolean getAutoweigh() {
		return autoweigh;
	}

	public void setAutoweigh(Boolean autoweigh) {
		this.autoweigh = autoweigh;
	}

	public Integer getNumpercase() {
		return numpercase;
	}

	public void setNumpercase(Integer numpercase) {
		this.numpercase = numpercase;
	}

	public Boolean getFoodstampable() {
		return foodstampable;
	}

	public void setFoodstampable(Boolean foodstampable) {
		this.foodstampable = foodstampable;
	}

	public Boolean getCheckid() {
		return checkid;
	}

	public void setCheckid(Boolean checkid) {
		this.checkid = checkid;
	}

	public Boolean getAskprice() {
		return askprice;
	}

	public void setAskprice(Boolean askprice) {
		this.askprice = askprice;
	}

	public Boolean getAskquantity() {
		return askquantity;
	}

	public void setAskquantity(Boolean askquantity) {
		this.askquantity = askquantity;
	}

	public Boolean getDisabled() {
		return disabled;
	}

	public void setDisabled(Boolean disabled) {
		this.disabled = disabled;
	}

	public String getUnitsize() {
		return unitsize;
	}

	public void setUnitsize(String unitsize) {
		this.unitsize = unitsize;
	}

	public Boolean getAskdescription() {
		return askdescription;
	}

	public void setAskdescription(Boolean askdescription) {
		this.askdescription = askdescription;
	}

	public Boolean getCheckid2() {
		return checkid2;
	}

	public void setCheckid2(Boolean checkid2) {
		this.checkid2 = checkid2;
	}

	public Boolean getCountitem() {
		return countitem;
	}

	public void setCountitem(Boolean countitem) {
		this.countitem = countitem;
	}

	public Instant getHhTimeStart() {
		return hhTimeStart;
	}

	public void setHhTimeStart(Instant hhTimeStart) {
		this.hhTimeStart = hhTimeStart;
	}

	public Instant getHhTimeEnd() {
		return hhTimeEnd;
	}

	public void setHhTimeEnd(Instant hhTimeEnd) {
		this.hhTimeEnd = hhTimeEnd;
	}

	public Double getHhPrice() {
		return hhPrice;
	}

	public void setHhPrice(Double hhPrice) {
		this.hhPrice = hhPrice;
	}

	public String getImgUrl() {
		return imgUrl;
	}

	public void setImgUrl(String imgUrl) {
		this.imgUrl = imgUrl;
	}

	public Double getBulkpricing() {
		return bulkpricing;
	}

	public void setBulkpricing(Double bulkpricing) {
		this.bulkpricing = bulkpricing;
	}

	public Integer getQty() {
		return qty;
	}

	public void setQty(Integer qty) {
		this.qty = qty;
	}

	public Double getItemSpclPrice() {
		return itemSpclPrice;
	}

	public void setItemSpclPrice(Double itemSpclPrice) {
		this.itemSpclPrice = itemSpclPrice;
	}

	public List<String> getModifiersIds() {
		return modifiersIds;
	}

	public void setModifiersIds(List<String> modifiersIds) {
		this.modifiersIds = modifiersIds;
	}

	public List<String> getModifiersGroupsIds() {
		return modifiersGroupsIds;
	}

	public void setModifiersGroupsIds(List<String> modifiersGroupsIds) {
		this.modifiersGroupsIds = modifiersGroupsIds;
	}


	public Double getHasBulkprice() {
		return hasBulkprice;
	}

	public void setHasBulkprice(Double hasBulkprice) {
		this.hasBulkprice = hasBulkprice;
	}

	public String getBrandId() {
		return brandId;
	}

	public void setBrandId(String brandId) {
		this.brandId = brandId;
	}

	public String getFamilyId() {
		return familyId;
	}

	public void setFamilyId(String familyId) {
		this.familyId = familyId;
	}

	public String getSubfamilyId() {
		return subfamilyId;
	}

	public void setSubfamilyId(String subfamilyId) {
		this.subfamilyId = subfamilyId;
	}

	public String getSectionId() {
		return sectionId;
	}

	public void setSectionId(String sectionId) {
		this.sectionId = sectionId;
	}

	public String getStoreId() {
		return storeId;
	}

	public void setStoreId(String storeId) {
		this.storeId = storeId;
	}

	public String getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(String departmentId) {
		this.departmentId = departmentId;
	}

	public String getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(String categoryId) {
		this.categoryId = categoryId;
	}
	
//	public Brand getBrand() {
//		return brand;
//	}
//
//	public void setBrand(Brand brand) {
//		this.brand = brand;
//	}

//	public Family getFamily() {
//		return family;
//	}
//
//	public void setFamily(Family family) {
//		this.family = family;
//	}
//
//	public SubFamily getSubfamily() {
//		return subfamily;
//	}
//
//	public void setSubfamily(SubFamily subfamily) {
//		this.subfamily = subfamily;
//	}
//
//	public Section getSection() {
//		return section;
//	}
//
//	public void setSection(Section section) {
//		this.section = section;
//	}
//
//	public StoreLocal getStore() {
//		return store;
//	}
//
//	public void setStore(StoreLocal store) {
//		this.store = store;
//	}
//
//	public Dept getDepartment() {
//		return department;
//	}
//
//	public void setDepartment(Dept department) {
//		this.department = department;
//	}
//
//	public Category getCategory() {
//		return category;
//	}
//
//	public void setCategory(Category category) {
//		this.category = category;
//	}
    
    
    

//    @Size(max = 25)
//    @Field("brand")
//    private String brand;
//
//    @Field("brand_id")
//    private Integer brandId;

//    @Size(max = 25)
//    @Field("family")
//    private String family;
//
//    @Field("family_id")
//    private Integer familyId;

//    @Size(max = 25)
//    @Field("subfamily")
//    private String subfamily;
//
//    @Field("subfamily_id")
//    private Integer subfamilyId;

//    @Size(max = 25)
//    @Field("section")
//    private String section;
//
//    @Field("section_id")
//    private Integer sectionId;

//    @NotNull
//    @Field("storeid")
//    private Double storeid;

//    @Field("deptid")
//    private Integer deptid;


//    @Field("category_name")
//    private String categoryName;
//
//    @Field("category_id")
//    private Integer categoryId;
//
//    @Field("modifier_id")
//    private Integer modifierID;

    
//  @NotNull
//  @Field("itemid")
//  private Integer itemid;

   }
