package com.onyx.app.domain;

import org.springframework.data.annotation.Id;
import com.couchbase.client.java.repository.annotation.Field;
import org.springframework.data.couchbase.core.mapping.Document;
import org.springframework.data.couchbase.core.mapping.id.GeneratedValue;
import org.springframework.data.couchbase.core.mapping.id.IdPrefix;

import java.io.Serializable;
import java.util.Objects;

import static com.onyx.app.config.Constants.ID_DELIMITER;
import static org.springframework.data.couchbase.core.mapping.id.GenerationStrategy.UNIQUE;

/**
 * A PaymentCCInfo.
 */
@Document
public class PaymentCCInfo implements Serializable {

    private static final long serialVersionUID = 1L;
    public static final String PREFIX = "paymentccinfo";

    @SuppressWarnings("unused")
    @IdPrefix
    private String prefix = PREFIX;

    @Id
    @GeneratedValue(strategy = UNIQUE, delimiter = ID_DELIMITER)
    private String id;

    @Field("store_id")
    private Integer storeId;

    @Field("station_id")
    private Integer stationId;

    @Field("payment_method")
    private Boolean paymentMethod;

    @Field("primary_ip")
    private String primaryIP;

    @Field("processing_company")
    private String processingCompany;

    @Field("file_path")
    private String filePath;

    @Field("user_friendly_name")
    private String userFriendlyName;

    @Field("time_out")
    private String timeOut;

    @Field("require_cvv_2")
    private Boolean requireCvv2;

    @Field("check_number_verification")
    private Boolean checkNumberVerification;

    @Field("check_drivers_licence_verification")
    private Boolean checkDriversLicenceVerification;

    @Field("check_last_4_digits")
    private Boolean checkLast4Digits;

    @Field("pos_id")
    private Integer posId;

    @Field("capture_type")
    private String captureType;

    @Field("settlement_time")
    private String settlementTime;

    @Field("active")
    private Boolean active;

    // jhipster-needle-entity-add-field - JHipster will add fields here, do not remove
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getStoreId() {
        return storeId;
    }

    public PaymentCCInfo storeId(Integer storeId) {
        this.storeId = storeId;
        return this;
    }

    public void setStoreId(Integer storeId) {
        this.storeId = storeId;
    }

    public Integer getStationId() {
        return stationId;
    }

    public PaymentCCInfo stationId(Integer stationId) {
        this.stationId = stationId;
        return this;
    }

    public void setStationId(Integer stationId) {
        this.stationId = stationId;
    }

    public Boolean isPaymentMethod() {
        return paymentMethod;
    }

    public PaymentCCInfo paymentMethod(Boolean paymentMethod) {
        this.paymentMethod = paymentMethod;
        return this;
    }

    public void setPaymentMethod(Boolean paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public String getPrimaryIP() {
        return primaryIP;
    }

    public PaymentCCInfo primaryIP(String primaryIP) {
        this.primaryIP = primaryIP;
        return this;
    }

    public void setPrimaryIP(String primaryIP) {
        this.primaryIP = primaryIP;
    }

    public String getProcessingCompany() {
        return processingCompany;
    }

    public PaymentCCInfo processingCompany(String processingCompany) {
        this.processingCompany = processingCompany;
        return this;
    }

    public void setProcessingCompany(String processingCompany) {
        this.processingCompany = processingCompany;
    }

    public String getFilePath() {
        return filePath;
    }

    public PaymentCCInfo filePath(String filePath) {
        this.filePath = filePath;
        return this;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public String getUserFriendlyName() {
        return userFriendlyName;
    }

    public PaymentCCInfo userFriendlyName(String userFriendlyName) {
        this.userFriendlyName = userFriendlyName;
        return this;
    }

    public void setUserFriendlyName(String userFriendlyName) {
        this.userFriendlyName = userFriendlyName;
    }

    public String getTimeOut() {
        return timeOut;
    }

    public PaymentCCInfo timeOut(String timeOut) {
        this.timeOut = timeOut;
        return this;
    }

    public void setTimeOut(String timeOut) {
        this.timeOut = timeOut;
    }

    public Boolean isRequireCvv2() {
        return requireCvv2;
    }

    public PaymentCCInfo requireCvv2(Boolean requireCvv2) {
        this.requireCvv2 = requireCvv2;
        return this;
    }

    public void setRequireCvv2(Boolean requireCvv2) {
        this.requireCvv2 = requireCvv2;
    }

    public Boolean isCheckNumberVerification() {
        return checkNumberVerification;
    }

    public PaymentCCInfo checkNumberVerification(Boolean checkNumberVerification) {
        this.checkNumberVerification = checkNumberVerification;
        return this;
    }

    public void setCheckNumberVerification(Boolean checkNumberVerification) {
        this.checkNumberVerification = checkNumberVerification;
    }

    public Boolean isCheckDriversLicenceVerification() {
        return checkDriversLicenceVerification;
    }

    public PaymentCCInfo checkDriversLicenceVerification(Boolean checkDriversLicenceVerification) {
        this.checkDriversLicenceVerification = checkDriversLicenceVerification;
        return this;
    }

    public void setCheckDriversLicenceVerification(Boolean checkDriversLicenceVerification) {
        this.checkDriversLicenceVerification = checkDriversLicenceVerification;
    }

    public Boolean isCheckLast4Digits() {
        return checkLast4Digits;
    }

    public PaymentCCInfo checkLast4Digits(Boolean checkLast4Digits) {
        this.checkLast4Digits = checkLast4Digits;
        return this;
    }

    public void setCheckLast4Digits(Boolean checkLast4Digits) {
        this.checkLast4Digits = checkLast4Digits;
    }

    public Integer getPosId() {
        return posId;
    }

    public PaymentCCInfo posId(Integer posId) {
        this.posId = posId;
        return this;
    }

    public void setPosId(Integer posId) {
        this.posId = posId;
    }

    public String getCaptureType() {
        return captureType;
    }

    public PaymentCCInfo captureType(String captureType) {
        this.captureType = captureType;
        return this;
    }

    public void setCaptureType(String captureType) {
        this.captureType = captureType;
    }

    public String getSettlementTime() {
        return settlementTime;
    }

    public PaymentCCInfo settlementTime(String settlementTime) {
        this.settlementTime = settlementTime;
        return this;
    }

    public void setSettlementTime(String settlementTime) {
        this.settlementTime = settlementTime;
    }

    public Boolean isActive() {
        return active;
    }

    public PaymentCCInfo active(Boolean active) {
        this.active = active;
        return this;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }
    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here, do not remove

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        PaymentCCInfo paymentCCInfo = (PaymentCCInfo) o;
        if (paymentCCInfo.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), paymentCCInfo.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "PaymentCCInfo{" +
            "id=" + getId() +
            ", storeId=" + getStoreId() +
            ", stationId=" + getStationId() +
            ", paymentMethod='" + isPaymentMethod() + "'" +
            ", primaryIP='" + getPrimaryIP() + "'" +
            ", processingCompany='" + getProcessingCompany() + "'" +
            ", filePath='" + getFilePath() + "'" +
            ", userFriendlyName='" + getUserFriendlyName() + "'" +
            ", timeOut='" + getTimeOut() + "'" +
            ", requireCvv2='" + isRequireCvv2() + "'" +
            ", checkNumberVerification='" + isCheckNumberVerification() + "'" +
            ", checkDriversLicenceVerification='" + isCheckDriversLicenceVerification() + "'" +
            ", checkLast4Digits='" + isCheckLast4Digits() + "'" +
            ", posId=" + getPosId() +
            ", captureType='" + getCaptureType() + "'" +
            ", settlementTime='" + getSettlementTime() + "'" +
            ", active='" + isActive() + "'" +
            "}";
    }
}
