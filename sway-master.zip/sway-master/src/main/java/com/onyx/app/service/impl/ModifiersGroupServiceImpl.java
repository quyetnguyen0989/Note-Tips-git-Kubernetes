package com.onyx.app.service.impl;

import com.onyx.app.service.ModifiersGroupService;
import com.onyx.app.domain.ModifiersGroup;
import com.onyx.app.repository.ModifiersGroupRepository;
import com.onyx.app.service.dto.ModifiersGroupDTO;
import com.onyx.app.service.mapper.ModifiersGroupMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.stereotype.Service;

import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
/**
 * Service Implementation for managing ModifiersGroup.
 */
@Service
public class ModifiersGroupServiceImpl implements ModifiersGroupService {

    private final Logger log = LoggerFactory.getLogger(ModifiersGroupServiceImpl.class);

    private final ModifiersGroupRepository modifiersGroupRepository;

    private final ModifiersGroupMapper modifiersGroupMapper;

    public ModifiersGroupServiceImpl(ModifiersGroupRepository modifiersGroupRepository, ModifiersGroupMapper modifiersGroupMapper) {
        this.modifiersGroupRepository = modifiersGroupRepository;
        this.modifiersGroupMapper = modifiersGroupMapper;
    }

    /**
     * Save a modifiersGroup.
     *
     * @param modifiersGroupDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public ModifiersGroupDTO save(ModifiersGroupDTO modifiersGroupDTO) {
        log.debug("Request to save ModifiersGroup : {}", modifiersGroupDTO);
        ModifiersGroup modifiersGroup = modifiersGroupMapper.toEntity(modifiersGroupDTO);
        modifiersGroup = modifiersGroupRepository.save(modifiersGroup);
        return modifiersGroupMapper.toDto(modifiersGroup);
    }

    /**
     * Get all the modifiersGroups.
     *
     * @return the list of entities
     */
    @Override
    public List<ModifiersGroupDTO> findAll() {
        log.debug("Request to get all ModifiersGroups");
        return modifiersGroupRepository.findAll().stream()
            .map(modifiersGroupMapper::toDto)
            .collect(Collectors.toCollection(LinkedList::new));
    }


    /**
     * Get one modifiersGroup by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    public Optional<ModifiersGroupDTO> findOne(String id) {
        log.debug("Request to get ModifiersGroup : {}", id);
        return modifiersGroupRepository.findById(id)
            .map(modifiersGroupMapper::toDto);
    }

    /**
     * Delete the modifiersGroup by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(String id) {
        log.debug("Request to delete ModifiersGroup : {}", id);
        modifiersGroupRepository.deleteById(id);
    }
}
