package com.onyx.app.service;

import com.onyx.app.service.dto.CustomerInfoDTO;

import java.util.List;
import java.util.Optional;

/**
 * Service Interface for managing CustomerInfo.
 */
public interface CustomerInfoService {

    /**
     * Save a customerInfo.
     *
     * @param customerInfoDTO the entity to save
     * @return the persisted entity
     */
    CustomerInfoDTO save(CustomerInfoDTO customerInfoDTO);

    /**
     * Get all the customerInfos.
     *
     * @return the list of entities
     */
    List<CustomerInfoDTO> findAll();


    /**
     * Get the "id" customerInfo.
     *
     * @param id the id of the entity
     * @return the entity
     */
    Optional<CustomerInfoDTO> findOne(String id);

    /**
     * Delete the "id" customerInfo.
     *
     * @param id the id of the entity
     */
    void delete(String id);
}
