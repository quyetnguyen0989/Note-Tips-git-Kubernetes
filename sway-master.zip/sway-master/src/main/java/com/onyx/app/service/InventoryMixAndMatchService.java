package com.onyx.app.service;

import com.onyx.app.service.dto.InventoryMixAndMatchDTO;

import java.util.List;
import java.util.Optional;

/**
 * Service Interface for managing InventoryMixAndMatch.
 */
public interface InventoryMixAndMatchService {

    /**
     * Save a inventoryMixAndMatch.
     *
     * @param inventoryMixAndMatchDTO the entity to save
     * @return the persisted entity
     */
    InventoryMixAndMatchDTO save(InventoryMixAndMatchDTO inventoryMixAndMatchDTO);

    /**
     * Get all the inventoryMixAndMatches.
     *
     * @return the list of entities
     */
    List<InventoryMixAndMatchDTO> findAll();


    /**
     * Get the "id" inventoryMixAndMatch.
     *
     * @param id the id of the entity
     * @return the entity
     */
    Optional<InventoryMixAndMatchDTO> findOne(String id);

    /**
     * Delete the "id" inventoryMixAndMatch.
     *
     * @param id the id of the entity
     */
    void delete(String id);
}
