package com.onyx.app.service.dto;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.Objects;

/**
 * A DTO for the StoreLocal entity.
 */
public class StoreLocalDTO implements Serializable {

    private String id;

    @NotNull
    private Integer storeId;

    private Integer companyId;

    private Integer numStations;

    @NotNull
    @Size(max = 50)
    private String companyName;

    @Size(max = 50)
    private String companyAddress;

    @Size(max = 50)
    private String companyCity;

    @Size(max = 20)
    private String companyState;

    private Integer companyZip;

    private String companyPhone;

    @Size(max = 50)
    private String invoiceNotes;

    @Size(max = 50)
    private String logoLocation;

    private Integer taxId;

    @Size(max = 50)
    private String storeEmail;

    private Integer taxRate;

    private Boolean open;

    private String timeText;


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getStoreId() {
        return storeId;
    }

    public void setStoreId(Integer storeId) {
        this.storeId = storeId;
    }

    public Integer getCompanyId() {
        return companyId;
    }

    public void setCompanyId(Integer companyId) {
        this.companyId = companyId;
    }

    public Integer getNumStations() {
        return numStations;
    }

    public void setNumStations(Integer numStations) {
        this.numStations = numStations;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getCompanyAddress() {
        return companyAddress;
    }

    public void setCompanyAddress(String companyAddress) {
        this.companyAddress = companyAddress;
    }

    public String getCompanyCity() {
        return companyCity;
    }

    public void setCompanyCity(String companyCity) {
        this.companyCity = companyCity;
    }

    public String getCompanyState() {
        return companyState;
    }

    public void setCompanyState(String companyState) {
        this.companyState = companyState;
    }

    public Integer getCompanyZip() {
        return companyZip;
    }

    public void setCompanyZip(Integer companyZip) {
        this.companyZip = companyZip;
    }

    public String getCompanyPhone() {
        return companyPhone;
    }

    public void setCompanyPhone(String companyPhone) {
        this.companyPhone = companyPhone;
    }

    public String getInvoiceNotes() {
        return invoiceNotes;
    }

    public void setInvoiceNotes(String invoiceNotes) {
        this.invoiceNotes = invoiceNotes;
    }

    public String getLogoLocation() {
        return logoLocation;
    }

    public void setLogoLocation(String logoLocation) {
        this.logoLocation = logoLocation;
    }

    public Integer getTaxId() {
        return taxId;
    }

    public void setTaxId(Integer taxId) {
        this.taxId = taxId;
    }

    public String getStoreEmail() {
        return storeEmail;
    }

    public void setStoreEmail(String storeEmail) {
        this.storeEmail = storeEmail;
    }

    public Integer getTaxRate() {
        return taxRate;
    }

    public void setTaxRate(Integer taxRate) {
        this.taxRate = taxRate;
    }

    public Boolean getOpen() {
        return open;
    }

    public void setOpen(Boolean open) {
        this.open = open;
    }

    public String getTimeText() {
        return timeText;
    }

    public void setTimeText(String timeText) {
        this.timeText = timeText;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        StoreLocalDTO storeLocalDTO = (StoreLocalDTO) o;
        if (storeLocalDTO.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), storeLocalDTO.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "StoreLocalDTO{" +
            "id='" + id + '\'' +
            ", storeId=" + storeId +
            ", companyId=" + companyId +
            ", numStations=" + numStations +
            ", companyName='" + companyName + '\'' +
            ", companyAddress='" + companyAddress + '\'' +
            ", companyCity='" + companyCity + '\'' +
            ", companyState='" + companyState + '\'' +
            ", companyZip=" + companyZip +
            ", companyPhone='" + companyPhone + '\'' +
            ", invoiceNotes='" + invoiceNotes + '\'' +
            ", logoLocation='" + logoLocation + '\'' +
            ", taxId=" + taxId +
            ", storeEmail='" + storeEmail + '\'' +
            ", taxRate=" + taxRate +
            ", open=" + open +
            '}';
    }
}
