package com.onyx.app.service.dto;

import java.util.List;

import com.onyx.app.domain.Modifier;

public class CustomerInventory {

	private String id;
	private String itemname;
	private List<Modifier> modifiers;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getItemname() {
		return itemname;
	}

	public void setItemname(String itemname) {
		this.itemname = itemname;
	}

	public List<Modifier> getModifiers() {
		return modifiers;
	}

	public void setModifiers(List<Modifier> modifiers) {
		this.modifiers = modifiers;
	}
}
