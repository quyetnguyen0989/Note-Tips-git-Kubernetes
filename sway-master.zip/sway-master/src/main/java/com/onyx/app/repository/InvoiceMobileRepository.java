package com.onyx.app.repository;

import com.onyx.app.domain.InvoiceMobile;
import org.springframework.stereotype.Repository;

/**
 * Spring Data Couchbase repository for the InvoiceMobile entity.
 */
@SuppressWarnings("unused")
@Repository
public interface InvoiceMobileRepository extends N1qlCouchbaseRepository<InvoiceMobile, String> {

}
