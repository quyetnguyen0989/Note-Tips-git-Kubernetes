package com.onyx.app.service.mapper;

import com.onyx.app.domain.Inventory;
import com.onyx.app.service.dto.InventoryQuick;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring", uses = {})
public interface InventoryQuickMapper extends EntityMapper<InventoryQuick, Inventory>{

    @Override
    Inventory toEntity(InventoryQuick dto);

    @Override
    InventoryQuick toDto(Inventory entity);

    default Inventory fromId(String id){
        if (id == null){
            return null;
        }
        Inventory inventory = new Inventory();
        inventory.setId(id);
        return inventory;
    }
}
