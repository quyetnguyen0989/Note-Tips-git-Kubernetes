package com.onyx.app.service;

import com.onyx.app.service.dto.InvoiceDetailsDTO;

import java.util.List;
import java.util.Optional;

/**
 * Service Interface for managing InvoiceDetails.
 */
public interface InvoiceDetailsService {

    /**
     * Save a invoiceDetails.
     *
     * @param invoiceDetailsDTO the entity to save
     * @return the persisted entity
     */
    InvoiceDetailsDTO save(InvoiceDetailsDTO invoiceDetailsDTO);

    /**
     * Get all the invoiceDetails.
     *
     * @return the list of entities
     */
    List<InvoiceDetailsDTO> findAll();


    /**
     * Get the "id" invoiceDetails.
     *
     * @param id the id of the entity
     * @return the entity
     */
    Optional<InvoiceDetailsDTO> findOne(String id);

    /**
     * Delete the "id" invoiceDetails.
     *
     * @param id the id of the entity
     */
    void delete(String id);
}
