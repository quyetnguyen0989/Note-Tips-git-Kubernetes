package com.onyx.app.service.mapper;

import com.onyx.app.domain.*;
import com.onyx.app.service.dto.CtrxDTO;

import org.mapstruct.*;

/**
 * Mapper for the entity Ctrx and its DTO CtrxDTO.
 */
@Mapper(componentModel = "spring", uses = {})
public interface CtrxMapper extends EntityMapper<CtrxDTO, Ctrx> {


}
