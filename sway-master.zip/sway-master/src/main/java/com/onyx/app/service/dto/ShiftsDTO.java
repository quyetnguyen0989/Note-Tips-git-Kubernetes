package com.onyx.app.service.dto;

import java.time.ZonedDateTime;
import java.io.Serializable;
import java.util.Objects;

/**
 * A DTO for the Shifts entity.
 */
public class ShiftsDTO implements Serializable {

    private String id;

    private Integer shiftId;

    private Integer storeId;

    private ZonedDateTime startDatetime;

    private ZonedDateTime endDatetime;

    private Integer idUsed;

    private Double netSalesTaxed;

    private Double netSalesNonTaxed;

    private Double netSalesTaxExempt;

    private Double tax1;

    private Double tax2;

    private Double tax3;

    private Double taxCustom;

    private Double totalNumTrans;

    private Integer openCashierid;

    private Integer closeCashierid;

    private Double closeOutCount;

    private Double cashbackAmount;

    private Double openAmount;

    private Double closeAmount;

    private Double suggestedOpenAmount;

    private Double overshort;

    private Double cashTotal;

    private Double cTotal;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getShiftId() {
        return shiftId;
    }

    public void setShiftId(Integer shiftId) {
        this.shiftId = shiftId;
    }

    public Integer getStoreId() {
        return storeId;
    }

    public void setStoreId(Integer storeId) {
        this.storeId = storeId;
    }

    public ZonedDateTime getStartDatetime() {
        return startDatetime;
    }

    public void setStartDatetime(ZonedDateTime startDatetime) {
        this.startDatetime = startDatetime;
    }

    public ZonedDateTime getEndDatetime() {
        return endDatetime;
    }

    public void setEndDatetime(ZonedDateTime endDatetime) {
        this.endDatetime = endDatetime;
    }

    public Integer getIdUsed() {
        return idUsed;
    }

    public void setIdUsed(Integer idUsed) {
        this.idUsed = idUsed;
    }

    public Double getNetSalesTaxed() {
        return netSalesTaxed;
    }

    public void setNetSalesTaxed(Double netSalesTaxed) {
        this.netSalesTaxed = netSalesTaxed;
    }

    public Double getNetSalesNonTaxed() {
        return netSalesNonTaxed;
    }

    public void setNetSalesNonTaxed(Double netSalesNonTaxed) {
        this.netSalesNonTaxed = netSalesNonTaxed;
    }

    public Double getNetSalesTaxExempt() {
        return netSalesTaxExempt;
    }

    public void setNetSalesTaxExempt(Double netSalesTaxExempt) {
        this.netSalesTaxExempt = netSalesTaxExempt;
    }

    public Double getTax1() {
        return tax1;
    }

    public void setTax1(Double tax1) {
        this.tax1 = tax1;
    }

    public Double getTax2() {
        return tax2;
    }

    public void setTax2(Double tax2) {
        this.tax2 = tax2;
    }

    public Double getTax3() {
        return tax3;
    }

    public void setTax3(Double tax3) {
        this.tax3 = tax3;
    }

    public Double getTaxCustom() {
        return taxCustom;
    }

    public void setTaxCustom(Double taxCustom) {
        this.taxCustom = taxCustom;
    }

    public Double getTotalNumTrans() {
        return totalNumTrans;
    }

    public void setTotalNumTrans(Double totalNumTrans) {
        this.totalNumTrans = totalNumTrans;
    }

    public Integer getOpenCashierid() {
        return openCashierid;
    }

    public void setOpenCashierid(Integer openCashierid) {
        this.openCashierid = openCashierid;
    }

    public Integer getCloseCashierid() {
        return closeCashierid;
    }

    public void setCloseCashierid(Integer closeCashierid) {
        this.closeCashierid = closeCashierid;
    }

    public Double getCloseOutCount() {
        return closeOutCount;
    }

    public void setCloseOutCount(Double closeOutCount) {
        this.closeOutCount = closeOutCount;
    }

    public Double getCashbackAmount() {
        return cashbackAmount;
    }

    public void setCashbackAmount(Double cashbackAmount) {
        this.cashbackAmount = cashbackAmount;
    }

    public Double getOpenAmount() {
        return openAmount;
    }

    public void setOpenAmount(Double openAmount) {
        this.openAmount = openAmount;
    }

    public Double getCloseAmount() {
        return closeAmount;
    }

    public void setCloseAmount(Double closeAmount) {
        this.closeAmount = closeAmount;
    }

    public Double getSuggestedOpenAmount() {
        return suggestedOpenAmount;
    }

    public void setSuggestedOpenAmount(Double suggestedOpenAmount) {
        this.suggestedOpenAmount = suggestedOpenAmount;
    }

    public Double getOvershort() {
        return overshort;
    }

    public void setOvershort(Double overshort) {
        this.overshort = overshort;
    }

    public Double getCashTotal() {
        return cashTotal;
    }

    public void setCashTotal(Double cashTotal) {
        this.cashTotal = cashTotal;
    }

    public Double getcTotal() {
        return cTotal;
    }

    public void setcTotal(Double cTotal) {
        this.cTotal = cTotal;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        ShiftsDTO shiftsDTO = (ShiftsDTO) o;
        if (shiftsDTO.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), shiftsDTO.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "ShiftsDTO{" +
            "id=" + getId() +
            ", shiftId=" + getShiftId() +
            ", storeId=" + getStoreId() +
            ", startDatetime='" + getStartDatetime() + "'" +
            ", endDatetime='" + getEndDatetime() + "'" +
            ", idUsed=" + getIdUsed() +
            ", netSalesTaxed=" + getNetSalesTaxed() +
            ", netSalesNonTaxed=" + getNetSalesNonTaxed() +
            ", netSalesTaxExempt=" + getNetSalesTaxExempt() +
            ", tax1=" + getTax1() +
            ", tax2=" + getTax2() +
            ", tax3=" + getTax3() +
            ", taxCustom=" + getTaxCustom() +
            ", totalNumTrans=" + getTotalNumTrans() +
            ", openCashierid=" + getOpenCashierid() +
            ", closeCashierid=" + getCloseCashierid() +
            ", closeOutCount=" + getCloseOutCount() +
            ", cashbackAmount=" + getCashbackAmount() +
            ", openAmount=" + getOpenAmount() +
            ", closeAmount=" + getCloseAmount() +
            ", suggestedOpenAmount=" + getSuggestedOpenAmount() +
            ", overshort=" + getOvershort() +
            ", cashTotal=" + getCashTotal() +
            ", cTotal=" + getcTotal() +
            "}";
    }
}
