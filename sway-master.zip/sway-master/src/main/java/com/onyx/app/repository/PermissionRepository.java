package com.onyx.app.repository;

import org.springframework.stereotype.Repository;

import com.onyx.app.domain.Permission;

/**
 * Spring Data MongoDB repository for the Employee entity.
 */
@SuppressWarnings("unused")
@Repository
public interface PermissionRepository extends N1qlCouchbaseRepository<Permission, String> {

}
