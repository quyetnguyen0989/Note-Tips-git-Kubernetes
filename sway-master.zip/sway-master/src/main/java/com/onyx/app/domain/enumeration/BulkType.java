package com.onyx.app.domain.enumeration;

public enum BulkType {
    PERCENT,AMOUNT
}
