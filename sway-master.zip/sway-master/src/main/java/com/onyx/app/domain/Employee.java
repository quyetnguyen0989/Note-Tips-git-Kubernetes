package com.onyx.app.domain;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.data.annotation.Id;
import org.springframework.data.couchbase.core.mapping.Document;
import org.springframework.data.couchbase.core.mapping.id.GeneratedValue;
import org.springframework.data.couchbase.core.mapping.id.GenerationStrategy;

import com.couchbase.client.java.repository.annotation.Field;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

//@Data
//@AllArgsConstructor
//@NoArgsConstructor
@Document
public class Employee implements Serializable {

	private static final long serialVersionUID = 6458133457207586834L;

	@Id
	@GeneratedValue(strategy = GenerationStrategy.UNIQUE)
	private String id;

	@NotNull
	@Field("name")
	private String name;

	@NotNull
	@Field("language")
	private String language;

	@NotNull
	@Field("pin_code")
	private String pinCode;

	@NotNull
	@Size(max = 20)
	@Field("password")
	private String password;

	@NotNull
	@Field("store_id")
	private String storeId;

	@Field("swipe_id")
	private String swipeId;

	@NotNull
	@Field("email")
	@Email
	private String email;

	@Field("phone_number")
	private String phoneNumber;

	private String pic;

	private String bioMetic;

	private String nfc;

	private String accessLevel;

	private String accessLevelId;

	private List<String> roles = new ArrayList<>();

	public Employee() {
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public String getPinCode() {
		return pinCode;
	}

	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getStoreId() {
		return storeId;
	}

	public void setStoreId(String storeId) {
		this.storeId = storeId;
	}

	public String getSwipeId() {
		return swipeId;
	}

	public void setSwipeId(String swipeId) {
		this.swipeId = swipeId;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getPic() {
		return pic;
	}

	public void setPic(String pic) {
		this.pic = pic;
	}

	public String getBioMetic() {
		return bioMetic;
	}

	public void setBioMetic(String bioMetic) {
		this.bioMetic = bioMetic;
	}

	public String getNfc() {
		return nfc;
	}

	public void setNfc(String nfc) {
		this.nfc = nfc;
	}

	public String getAccessLevel() {
		return accessLevel;
	}

	public void setAccessLevel(String accessLevel) {
		this.accessLevel = accessLevel;
	}

	public String getAccessLevelId() {
		return accessLevelId;
	}

	public void setAccessLevelId(String accessLevelId) {
		this.accessLevelId = accessLevelId;
	}

	public List<String> getRoles() {
		return roles;
	}

	public void setRoles(List<String> roles) {
		this.roles = roles;
	}

}
