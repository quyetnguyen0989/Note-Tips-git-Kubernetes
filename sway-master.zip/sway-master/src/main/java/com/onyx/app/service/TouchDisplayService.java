package com.onyx.app.service;

import com.onyx.app.service.dto.TouchDisplayDTO;

import java.util.List;
import java.util.Optional;

/**
 * Service Interface for managing TouchDisplay.
 */
public interface TouchDisplayService {

    /**
     * Save a touchDisplay.
     *
     * @param touchDisplayDTO the entity to save
     * @return the persisted entity
     */
    TouchDisplayDTO save(TouchDisplayDTO touchDisplayDTO);

    /**
     * Get all the touchDisplays.
     *
     * @return the list of entities
     */
    List<TouchDisplayDTO> findAll();


    /**
     * Get the "id" touchDisplay.
     *
     * @param id the id of the entity
     * @return the entity
     */
    Optional<TouchDisplayDTO> findOne(String id);

    /**
     * Delete the "id" touchDisplay.
     *
     * @param id the id of the entity
     */
    void delete(String id);
}
