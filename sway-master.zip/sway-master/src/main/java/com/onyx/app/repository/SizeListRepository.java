package com.onyx.app.repository;

import org.springframework.stereotype.Repository;

import com.onyx.app.domain.SizeList;

/**
 * Spring Data MongoDB repository for the SizeList entity.
 */
@SuppressWarnings("unused")
@Repository
public interface SizeListRepository extends N1qlCouchbaseRepository<SizeList, String> {

}
