package com.onyx.app.service.mapper;

import com.onyx.app.domain.*;
import com.onyx.app.service.dto.InvoiceOnHoldDTO;

import org.mapstruct.*;

/**
 * Mapper for the entity InvoiceOnHold and its DTO InvoiceOnHoldDTO.
 */
@Mapper(componentModel = "spring", uses = {})
public interface InvoiceOnHoldMapper extends EntityMapper<InvoiceOnHoldDTO, InvoiceOnHold> {


}
