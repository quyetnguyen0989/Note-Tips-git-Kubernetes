package com.onyx.app.repository;

import com.onyx.app.domain.Transfers;
import org.springframework.stereotype.Repository;

/**
 * Spring Data Couchbase repository for the Transfers entity.
 */
@SuppressWarnings("unused")
@Repository
public interface TransfersRepository extends N1qlCouchbaseRepository<Transfers, String> {

}
