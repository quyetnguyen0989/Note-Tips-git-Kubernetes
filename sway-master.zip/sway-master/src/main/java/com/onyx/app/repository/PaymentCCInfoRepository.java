package com.onyx.app.repository;

import com.onyx.app.domain.PaymentCCInfo;
import org.springframework.stereotype.Repository;

/**
 * Spring Data Couchbase repository for the PaymentCCInfo entity.
 */
@SuppressWarnings("unused")
@Repository
public interface PaymentCCInfoRepository extends N1qlCouchbaseRepository<PaymentCCInfo, String> {

}
