package com.onyx.app.service.impl;

import com.onyx.app.service.InventoryAttributeService;
import com.onyx.app.domain.InventoryAttribute;
import com.onyx.app.repository.InventoryAttributeRepository;
import com.onyx.app.service.dto.InventoryAttributeDTO;
import com.onyx.app.service.mapper.InventoryAttributeMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.stereotype.Service;

import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
/**
 * Service Implementation for managing InventoryAttribute.
 */
@Service
public class InventoryAttributeServiceImpl implements InventoryAttributeService {

    private final Logger log = LoggerFactory.getLogger(InventoryAttributeServiceImpl.class);

    private final InventoryAttributeRepository inventoryAttributeRepository;

    private final InventoryAttributeMapper inventoryAttributeMapper;

    public InventoryAttributeServiceImpl(InventoryAttributeRepository inventoryAttributeRepository, InventoryAttributeMapper inventoryAttributeMapper) {
        this.inventoryAttributeRepository = inventoryAttributeRepository;
        this.inventoryAttributeMapper = inventoryAttributeMapper;
    }

    /**
     * Save a inventoryAttribute.
     *
     * @param inventoryAttributeDTO the entity to save
     * @return the persisted entity
     */
    @Override
    public InventoryAttributeDTO save(InventoryAttributeDTO inventoryAttributeDTO) {
        log.debug("Request to save InventoryAttribute : {}", inventoryAttributeDTO);
        InventoryAttribute inventoryAttribute = inventoryAttributeMapper.toEntity(inventoryAttributeDTO);
        inventoryAttribute = inventoryAttributeRepository.save(inventoryAttribute);
        return inventoryAttributeMapper.toDto(inventoryAttribute);
    }

    /**
     * Get all the inventoryAttributes.
     *
     * @return the list of entities
     */
    @Override
    public List<InventoryAttributeDTO> findAll() {
        log.debug("Request to get all InventoryAttributes");
        return inventoryAttributeRepository.findAll().stream()
            .map(inventoryAttributeMapper::toDto)
            .collect(Collectors.toCollection(LinkedList::new));
    }


    /**
     * Get one inventoryAttribute by id.
     *
     * @param id the id of the entity
     * @return the entity
     */
    @Override
    public Optional<InventoryAttributeDTO> findOne(String id) {
        log.debug("Request to get InventoryAttribute : {}", id);
        return inventoryAttributeRepository.findById(id)
            .map(inventoryAttributeMapper::toDto);
    }

    /**
     * Delete the inventoryAttribute by id.
     *
     * @param id the id of the entity
     */
    @Override
    public void delete(String id) {
        log.debug("Request to delete InventoryAttribute : {}", id);
        inventoryAttributeRepository.deleteById(id);
    }
}
