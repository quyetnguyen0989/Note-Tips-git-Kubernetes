package com.onyx.app.domain.enumeration;

/**
 * The HardwarePolePort enumeration.
 */
public enum HardwarePolePort {
    USB, COM, VIRTUAL
}
