package com.onyx.app.service.dto;

import java.time.ZonedDateTime;
import java.io.Serializable;
import java.util.Objects;

/**
 * A DTO for the CTrx entity.
 */
public class CTrxDTO implements Serializable {

    private String id;

    private Integer storeId;

    private ZonedDateTime dateTime;

    private String trxType;

    private Double amount;

    private String approval;

    private String reference;

    private Integer invNum;

    private Double tipAmount;

    private String cardType;

    private Double tipApplied;

    private String troutD;

    private String postAuthReferenceNumber;

    private Integer orderId;

    private String language;

    private Integer cardNumber;

    private String paymentMethod;

    private Double cashBack;

    private Integer terminalNumber;

    private String aCI;

    private String cardEntrySource;

    private String traceNumber;

    private Integer sequenceNumber;

    private String isPrePaidCard;

    private Double preAuthAmount;

    private String appLabel;

    private String appPreferredName;

    private String cardPlan;

    private String emvAid;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getStoreId() {
        return storeId;
    }

    public void setStoreId(Integer storeId) {
        this.storeId = storeId;
    }

    public ZonedDateTime getDateTime() {
        return dateTime;
    }

    public void setDateTime(ZonedDateTime dateTime) {
        this.dateTime = dateTime;
    }

    public String getTrxType() {
        return trxType;
    }

    public void setTrxType(String trxType) {
        this.trxType = trxType;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public String getApproval() {
        return approval;
    }

    public void setApproval(String approval) {
        this.approval = approval;
    }

    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    public Integer getInvNum() {
        return invNum;
    }

    public void setInvNum(Integer invNum) {
        this.invNum = invNum;
    }

    public Double getTipAmount() {
        return tipAmount;
    }

    public void setTipAmount(Double tipAmount) {
        this.tipAmount = tipAmount;
    }

    public String getCardType() {
        return cardType;
    }

    public void setCardType(String cardType) {
        this.cardType = cardType;
    }

    public Double getTipApplied() {
        return tipApplied;
    }

    public void setTipApplied(Double tipApplied) {
        this.tipApplied = tipApplied;
    }

    public String getTroutD() {
        return troutD;
    }

    public void setTroutD(String troutD) {
        this.troutD = troutD;
    }

    public String getPostAuthReferenceNumber() {
        return postAuthReferenceNumber;
    }

    public void setPostAuthReferenceNumber(String postAuthReferenceNumber) {
        this.postAuthReferenceNumber = postAuthReferenceNumber;
    }

    public Integer getOrderId() {
        return orderId;
    }

    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public Integer getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(Integer cardNumber) {
        this.cardNumber = cardNumber;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public Double getCashBack() {
        return cashBack;
    }

    public void setCashBack(Double cashBack) {
        this.cashBack = cashBack;
    }

    public Integer getTerminalNumber() {
        return terminalNumber;
    }

    public void setTerminalNumber(Integer terminalNumber) {
        this.terminalNumber = terminalNumber;
    }

    public String getaCI() {
        return aCI;
    }

    public void setaCI(String aCI) {
        this.aCI = aCI;
    }

    public String getCardEntrySource() {
        return cardEntrySource;
    }

    public void setCardEntrySource(String cardEntrySource) {
        this.cardEntrySource = cardEntrySource;
    }

    public String getTraceNumber() {
        return traceNumber;
    }

    public void setTraceNumber(String traceNumber) {
        this.traceNumber = traceNumber;
    }

    public Integer getSequenceNumber() {
        return sequenceNumber;
    }

    public void setSequenceNumber(Integer sequenceNumber) {
        this.sequenceNumber = sequenceNumber;
    }

    public String getIsPrePaidCard() {
        return isPrePaidCard;
    }

    public void setIsPrePaidCard(String isPrePaidCard) {
        this.isPrePaidCard = isPrePaidCard;
    }

    public Double getPreAuthAmount() {
        return preAuthAmount;
    }

    public void setPreAuthAmount(Double preAuthAmount) {
        this.preAuthAmount = preAuthAmount;
    }

    public String getAppLabel() {
        return appLabel;
    }

    public void setAppLabel(String appLabel) {
        this.appLabel = appLabel;
    }

    public String getAppPreferredName() {
        return appPreferredName;
    }

    public void setAppPreferredName(String appPreferredName) {
        this.appPreferredName = appPreferredName;
    }

    public String getCardPlan() {
        return cardPlan;
    }

    public void setCardPlan(String cardPlan) {
        this.cardPlan = cardPlan;
    }

    public String getEmvAid() {
        return emvAid;
    }

    public void setEmvAid(String emvAid) {
        this.emvAid = emvAid;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        CTrxDTO cTrxDTO = (CTrxDTO) o;
        if (cTrxDTO.getId() == null || getId() == null) {
            return false;
        }
        return Objects.equals(getId(), cTrxDTO.getId());
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(getId());
    }

    @Override
    public String toString() {
        return "CTrxDTO{" +
            "id=" + getId() +
            ", storeId=" + getStoreId() +
            ", dateTime='" + getDateTime() + "'" +
            ", trxType='" + getTrxType() + "'" +
            ", amount=" + getAmount() +
            ", approval='" + getApproval() + "'" +
            ", reference='" + getReference() + "'" +
            ", invNum=" + getInvNum() +
            ", tipAmount=" + getTipAmount() +
            ", cardType='" + getCardType() + "'" +
            ", tipApplied=" + getTipApplied() +
            ", troutD='" + getTroutD() + "'" +
            ", postAuthReferenceNumber='" + getPostAuthReferenceNumber() + "'" +
            ", orderId=" + getOrderId() +
            ", language='" + getLanguage() + "'" +
            ", cardNumber=" + getCardNumber() +
            ", paymentMethod='" + getPaymentMethod() + "'" +
            ", cashBack=" + getCashBack() +
            ", terminalNumber=" + getTerminalNumber() +
            ", aCI='" + getaCI() + "'" +
            ", cardEntrySource='" + getCardEntrySource() + "'" +
            ", traceNumber='" + getTraceNumber() + "'" +
            ", sequenceNumber=" + getSequenceNumber() +
            ", isPrePaidCard='" + getIsPrePaidCard() + "'" +
            ", preAuthAmount=" + getPreAuthAmount() +
            ", appLabel='" + getAppLabel() + "'" +
            ", appPreferredName='" + getAppPreferredName() + "'" +
            ", cardPlan='" + getCardPlan() + "'" +
            ", emvAid='" + getEmvAid() + "'" +
            "}";
    }
}
